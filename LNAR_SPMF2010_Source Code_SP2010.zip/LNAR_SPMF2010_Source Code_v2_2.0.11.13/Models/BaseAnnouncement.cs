﻿using System;
using Microsoft.SharePoint.Linq;

namespace DeutscheBank.SharePoint.LNAR.Framework.Models
{
    /// <summary>
    ///   Create a new news item, status or other short piece of information.
    /// </summary>
    [ContentType(Name = "Announcement", Id = "0x0104")]
    public abstract class BaseAnnouncement : BaseItem
    {
        private string body;
        private DateTime? expires;

        [Column(Name = "Body", Storage = "body", FieldType = "Note")]
        public string Body
        {
            get { return body; }
            set
            {
                if ((value != body))
                {
                    OnPropertyChanging("Body", body);
                    body = value;
                    OnPropertyChanged("Body");
                }
            }
        }

        [Column(Name = "Expires", Storage = "expires", FieldType = "DateTime")]
        public DateTime? Expires
        {
            get { return expires; }
            set
            {
                if ((value != expires))
                {
                    OnPropertyChanging("Expires", expires);
                    expires = value;
                    OnPropertyChanged("Expires");
                }
            }
        }
    }
}