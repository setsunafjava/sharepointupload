﻿using Microsoft.SharePoint.Linq;

namespace DeutscheBank.SharePoint.LNAR.Framework.Models
{
    /// <summary>
    ///   Store information about a business or personal contact.
    /// </summary>
    [ContentType(Name = "Contact", Id = "0x0106")]
    public abstract class BaseContact : BaseItem
    {
        private string address;
        private string businessPhone;
        private string city;
        private string comments;
        private string company;
        private string countryRegion;
        private string email;
        private string faxNumber;
        private string firstName;
        private string fullName;
        private string homePhone;
        private string jobTitle;
        private string lastName;
        private string mobileNumber;
        private string stateProvince;
        private string webPage;
        private string zipPostalCode;

        [Column(Name = "FirstName", Storage = "firstName", FieldType = "Text")]
        public string FirstName
        {
            get { return firstName; }
            set
            {
                if ((value != firstName))
                {
                    OnPropertyChanging("FirstName", firstName);
                    firstName = value;
                    OnPropertyChanged("FirstName");
                }
            }
        }

        [Column(Name = "LinkTitle", Storage = "lastName", ReadOnly = true, FieldType = "Computed")]
        public string LastName
        {
            get { return lastName; }
            set
            {
                if ((value != lastName))
                {
                    OnPropertyChanging("LastName", lastName);
                    lastName = value;
                    OnPropertyChanged("LastName");
                }
            }
        }

        [Column(Name = "FullName", Storage = "fullName", FieldType = "Text")]
        public string FullName
        {
            get { return fullName; }
            set
            {
                if ((value != fullName))
                {
                    OnPropertyChanging("FullName", fullName);
                    fullName = value;
                    OnPropertyChanged("FullName");
                }
            }
        }

        [Column(Name = "Email", Storage = "email", FieldType = "Text")]
        public string Email
        {
            get { return email; }
            set
            {
                if ((value != email))
                {
                    OnPropertyChanging("Email", email);
                    email = value;
                    OnPropertyChanged("Email");
                }
            }
        }

        [Column(Name = "Company", Storage = "company", FieldType = "Text")]
        public string Company
        {
            get { return company; }
            set
            {
                if ((value != company))
                {
                    OnPropertyChanging("Company", company);
                    company = value;
                    OnPropertyChanged("Company");
                }
            }
        }

        [Column(Name = "JobTitle", Storage = "jobTitle", FieldType = "Text")]
        public string JobTitle
        {
            get { return jobTitle; }
            set
            {
                if ((value != jobTitle))
                {
                    OnPropertyChanging("JobTitle", jobTitle);
                    jobTitle = value;
                    OnPropertyChanged("JobTitle");
                }
            }
        }

        [Column(Name = "WorkPhone", Storage = "businessPhone", FieldType = "Text")]
        public string BusinessPhone
        {
            get { return businessPhone; }
            set
            {
                if ((value != businessPhone))
                {
                    OnPropertyChanging("BusinessPhone", businessPhone);
                    businessPhone = value;
                    OnPropertyChanged("BusinessPhone");
                }
            }
        }

        [Column(Name = "HomePhone", Storage = "homePhone", FieldType = "Text")]
        public string HomePhone
        {
            get { return homePhone; }
            set
            {
                if ((value != homePhone))
                {
                    OnPropertyChanging("HomePhone", homePhone);
                    homePhone = value;
                    OnPropertyChanged("HomePhone");
                }
            }
        }

        [Column(Name = "CellPhone", Storage = "mobileNumber", FieldType = "Text")]
        public string MobileNumber
        {
            get { return mobileNumber; }
            set
            {
                if ((value != mobileNumber))
                {
                    OnPropertyChanging("MobileNumber", mobileNumber);
                    mobileNumber = value;
                    OnPropertyChanged("MobileNumber");
                }
            }
        }

        [Column(Name = "WorkFax", Storage = "faxNumber", FieldType = "Text")]
        public string FaxNumber
        {
            get { return faxNumber; }
            set
            {
                if ((value != faxNumber))
                {
                    OnPropertyChanging("FaxNumber", faxNumber);
                    faxNumber = value;
                    OnPropertyChanged("FaxNumber");
                }
            }
        }

        [Column(Name = "WorkAddress", Storage = "address", FieldType = "Note")]
        public string Address
        {
            get { return address; }
            set
            {
                if ((value != address))
                {
                    OnPropertyChanging("Address", address);
                    address = value;
                    OnPropertyChanged("Address");
                }
            }
        }

        [Column(Name = "WorkCity", Storage = "city", FieldType = "Text")]
        public string City
        {
            get { return city; }
            set
            {
                if ((value != city))
                {
                    OnPropertyChanging("City", city);
                    city = value;
                    OnPropertyChanged("City");
                }
            }
        }

        [Column(Name = "WorkState", Storage = "stateProvince", FieldType = "Text")]
        public string StateProvince
        {
            get { return stateProvince; }
            set
            {
                if ((value != stateProvince))
                {
                    OnPropertyChanging("StateProvince", stateProvince);
                    stateProvince = value;
                    OnPropertyChanged("StateProvince");
                }
            }
        }

        [Column(Name = "WorkZip", Storage = "zipPostalCode", FieldType = "Text")]
        public string ZipPostalCode
        {
            get { return zipPostalCode; }
            set
            {
                if ((value != zipPostalCode))
                {
                    OnPropertyChanging("ZIPPostalCode", zipPostalCode);
                    zipPostalCode = value;
                    OnPropertyChanged("ZIPPostalCode");
                }
            }
        }

        [Column(Name = "WorkCountry", Storage = "countryRegion", FieldType = "Text")]
        public string CountryRegion
        {
            get { return countryRegion; }
            set
            {
                if ((value != countryRegion))
                {
                    OnPropertyChanging("CountryRegion", countryRegion);
                    countryRegion = value;
                    OnPropertyChanged("CountryRegion");
                }
            }
        }

        [Column(Name = "WebPage", Storage = "webPage", FieldType = "Url")]
        public string WebPage
        {
            get { return webPage; }
            set
            {
                if ((value != webPage))
                {
                    OnPropertyChanging("WebPage", webPage);
                    webPage = value;
                    OnPropertyChanged("WebPage");
                }
            }
        }

        [Column(Name = "Comments", Storage = "comments", FieldType = "Note")]
        public string Comments
        {
            get { return comments; }
            set
            {
                if ((value != comments))
                {
                    OnPropertyChanging("Comments", comments);
                    comments = value;
                    OnPropertyChanged("Comments");
                }
            }
        }
    }
}