﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Microsoft.SharePoint.Linq;

namespace DeutscheBank.SharePoint.LNAR.Framework.Models
{
    /// <summary>
    ///   Create a new list item.
    /// </summary>
    [ContentType(Name = "Item", Id = "0x01")]
    public abstract class BaseItem : ITrackEntityState, ITrackOriginalValues, INotifyPropertyChanged, INotifyPropertyChanging
    {
        private DateTime created;
        private string createdBy;
        private EntityState entityState;
        private int? id;
        private DateTime modified;
        private string modifiedBy;
        private IDictionary<string, object> originalValues;
        private string path;
        private string title;
        private int? version;

        [Column(Name = "ID", Storage = "id", ReadOnly = true, FieldType = "Counter")]
        public int? Id
        {
            get { return id; }
            set
            {
                if ((value != id))
                {
                    OnPropertyChanging("Id", id);
                    id = value;
                    OnPropertyChanged("Id");
                }
            }
        }

        [Column(Name = "owshiddenversion", Storage = "version", ReadOnly = true, FieldType = "Integer")]
        public int? Version
        {
            get { return version; }
            set
            {
                if ((value != version))
                {
                    OnPropertyChanging("Version", version);
                    version = value;
                    OnPropertyChanged("Version");
                }
            }
        }

        [Column(Name = "FileDirRef", Storage = "path", ReadOnly = true, FieldType = "Lookup", IsLookupValue = true)]
        public string Path
        {
            get { return path; }
            set
            {
                if ((value != path))
                {
                    OnPropertyChanging("Path", path);
                    path = value;
                    OnPropertyChanged("Path");
                }
            }
        }

        [Column(Name = "Title", Storage = "title", Required = true, FieldType = "Text")]
        public virtual string Title
        {
            get { return title; }
            set
            {
                if ((value != title))
                {
                    OnPropertyChanging("Title", title);
                    title = value;
                    OnPropertyChanged("Title");
                }
            }
        }

        [Column(Name = "Modified", Storage = "modified", ReadOnly = true, FieldType = "DateTime")]
        public DateTime Modified
        {
            get { return modified; }
            set
            {
                if ((value != modified))
                {
                    OnPropertyChanging("Modified", modified);
                    modified = value;
                    OnPropertyChanged("Modified");
                }
            }
        }

        [Column(Name = "Editor", Storage = "modifiedBy", ReadOnly = true, FieldType = "Text")]
        public string ModifiedBy
        {
            get { return modifiedBy; }
            set
            {
                if ((value != modifiedBy))
                {
                    OnPropertyChanging("ModifiedBy", modifiedBy);
                    modifiedBy = value;
                    OnPropertyChanged("ModifiedBy");
                }
            }
        }

        [Column(Name = "Created", Storage = "created", ReadOnly = true, FieldType = "DateTime")]
        public DateTime Created
        {
            get { return created; }
            set
            {
                if ((value != created))
                {
                    OnPropertyChanging("Created", created);
                    created = value;
                    OnPropertyChanged("Created");
                }
            }
        }

        [Column(Name = "Author", Storage = "createdBy", ReadOnly = true, FieldType = "Text")]
        public string CreatedBy
        {
            get { return createdBy; }
            set
            {
                if ((value != createdBy))
                {
                    OnPropertyChanging("CreatedBy", createdBy);
                    createdBy = value;
                    OnPropertyChanged("CreatedBy");
                }
            }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region INotifyPropertyChanging Members

        public event PropertyChangingEventHandler PropertyChanging;

        #endregion

        #region ITrackEntityState Members

        public EntityState EntityState
        {
            get { return entityState; }
            set
            {
                if (!Equals(entityState, value))
                {
                    entityState = value;
                }
            }
        }

        #endregion

        #region ITrackOriginalValues Members

        IDictionary<string, object> ITrackOriginalValues.OriginalValues
        {
            get { return originalValues ?? (originalValues = new Dictionary<string, object>()); }
        }

        #endregion

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        protected virtual void OnPropertyChanging(string propertyName, object value)
        {
            if (originalValues == null)
            {
                originalValues = new Dictionary<string, object>();
            }

            if (originalValues.ContainsKey(propertyName) == false)
            {
                originalValues.Add(propertyName, value);
            }

            if (PropertyChanging != null)
            {
                PropertyChanging(this, new PropertyChangingEventArgs(propertyName));
            }
        }

        public override string ToString()
        {
            return Title;
        }
    }
}