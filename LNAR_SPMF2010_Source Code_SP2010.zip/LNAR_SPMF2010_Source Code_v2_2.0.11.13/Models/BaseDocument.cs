﻿using Microsoft.SharePoint.Linq;

namespace DeutscheBank.SharePoint.LNAR.Framework.Models
{
    /// <summary>
    ///   Create a new document.
    /// </summary>
    [ContentType(Name = "Document", Id = "0x0101")]
    public abstract class BaseDocument : BaseItem
    {
        private string name;

        [Column(Name = "FileLeafRef", Storage = "name", Required = true, FieldType = "File")]
        public string Name
        {
            get { return name; }
            set
            {
                if ((value != name))
                {
                    OnPropertyChanging("Name", name);
                    name = value;
                    OnPropertyChanged("Name");
                }
            }
        }

        public override string ToString()
        {
            return Name;
        }
    }
}