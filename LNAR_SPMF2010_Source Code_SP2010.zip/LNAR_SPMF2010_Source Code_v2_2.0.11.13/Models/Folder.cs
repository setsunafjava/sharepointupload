﻿using System;
using System.ComponentModel;
using Microsoft.SharePoint.Linq;

namespace DeutscheBank.SharePoint.LNAR.Framework.Models
{
    /// <summary>
    ///   Create a new folder.
    /// </summary>
    [ContentType(Name = "Folder", Id = "0x0120")]
    public class Folder : BaseItem
    {
        private string folderChildCountFolderChildCount;
        private int? itemChildCountId;
        private string itemChildCountItemChildCount;
        private string name;

        [Column(Name = "FileLeafRef", Storage = "name", Required = true, FieldType = "File")]
        public virtual string Name
        {
            get { return name; }
            set
            {
                if ((value != name))
                {
                    OnPropertyChanging("Name", name);
                    name = value;
                    OnPropertyChanged("Name");
                }
            }
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        [RemovedColumn]
        public override string Title
        {
            get { throw new InvalidOperationException("Field Title was removed from content type Folder."); }
            set { throw new InvalidOperationException("Field Title was removed from content type Folder."); }
        }

        [Column(Name = "ItemChildCount", Storage = "itemChildCountId", ReadOnly = true, FieldType = "Lookup",
            IsLookupId = true)]
        public int? ItemChildCountId
        {
            get { return itemChildCountId; }
            set
            {
                if ((value != itemChildCountId))
                {
                    OnPropertyChanging("ItemChildCountId", itemChildCountId);
                    itemChildCountId = value;
                    OnPropertyChanged("ItemChildCountId");
                }
            }
        }

        [Column(Name = "ItemChildCount", Storage = "itemChildCountItemChildCount", ReadOnly = true, FieldType = "Lookup"
            , IsLookupValue = true)]
        public string ItemChildCountItemChildCount
        {
            get { return itemChildCountItemChildCount; }
            set
            {
                if ((value != itemChildCountItemChildCount))
                {
                    OnPropertyChanging("ItemChildCountItemChildCount", itemChildCountItemChildCount);
                    itemChildCountItemChildCount = value;
                    OnPropertyChanged("ItemChildCountItemChildCount");
                }
            }
        }

        [Column(Name = "FolderChildCount", Storage = "folderChildCountFolderChildCount", ReadOnly = true,
            FieldType = "Lookup", IsLookupValue = true)]
        public string FolderChildCountFolderChildCount
        {
            get { return folderChildCountFolderChildCount; }
            set
            {
                if ((value != folderChildCountFolderChildCount))
                {
                    OnPropertyChanging("FolderChildCountFolderChildCount", folderChildCountFolderChildCount);
                    folderChildCountFolderChildCount = value;
                    OnPropertyChanged("FolderChildCountFolderChildCount");
                }
            }
        }
    }
}