﻿using System;
using Microsoft.SharePoint.Linq;

namespace DeutscheBank.SharePoint.LNAR.Framework.Models
{
    /// <summary>
    ///   Create a new meeting, deadline or other event.
    /// </summary>
    [ContentType(Name = "Event", Id = "0x0102")]
    public abstract class BaseCalendarEvent : BaseEvent
    {
        private string description;
        private DateTime? startTime;

        [Column(Name = "EventDate", Storage = "startTime", Required = true, FieldType = "DateTime")]
        public override DateTime? StartTime
        {
            get { return startTime; }
            set
            {
                if ((value != startTime))
                {
                    OnPropertyChanging("StartTime", startTime);
                    startTime = value;
                    OnPropertyChanged("StartTime");
                }
            }
        }

        [Column(Name = "Description", Storage = "description", FieldType = "Note")]
        public override string Description
        {
            get { return description; }
            set
            {
                if ((value != description))
                {
                    OnPropertyChanging("Description", description);
                    description = value;
                    OnPropertyChanged("Description");
                }
            }
        }
    }
}