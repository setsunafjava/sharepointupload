﻿using System;
using Microsoft.SharePoint.Linq;

namespace DeutscheBank.SharePoint.LNAR.Framework.Models
{
    /// <summary>
    ///   Create a new meeting, deadline or other event.
    /// </summary>
    [ContentType(Name = "Event", Id = "0x0102")]
    public abstract class BaseEvent : BaseItem
    {
        private bool? allDayEvent;
        private int? category;
        private string description;
        private DateTime? endTime;
        private string location;
        private bool? recurrence;

        private DateTime? startTime;
        private bool? workspace;

        [Column(Name = "Location", Storage = "location", FieldType = "Text")]
        public string Location
        {
            get { return location; }
            set
            {
                if ((value != location))
                {
                    OnPropertyChanging("Location", location);
                    location = value;
                    OnPropertyChanged("Location");
                }
            }
        }

        [Column(Name = "StartDate", Storage = "startTime", Required = true, FieldType = "DateTime")]
        public virtual DateTime? StartTime
        {
            get { return startTime; }
            set
            {
                if ((value != startTime))
                {
                    OnPropertyChanging("StartTime", startTime);
                    startTime = value;
                    OnPropertyChanged("StartTime");
                }
            }
        }

        [Column(Name = "EndDate", Storage = "endTime", Required = true, FieldType = "DateTime")]
        public DateTime? EndTime
        {
            get { return endTime; }
            set
            {
                if ((value != endTime))
                {
                    OnPropertyChanging("EndTime", endTime);
                    endTime = value;
                    OnPropertyChanged("EndTime");
                }
            }
        }

        [Column(Name = "Comments", Storage = "description", FieldType = "Note")]
        public virtual string Description
        {
            get { return description; }
            set
            {
                if ((value != description))
                {
                    OnPropertyChanging("Description", description);
                    description = value;
                    OnPropertyChanged("Description");
                }
            }
        }

        [Column(Name = "fAllDayEvent", Storage = "allDayEvent", FieldType = "AllDayEvent")]
        public bool? AllDayEvent
        {
            get { return allDayEvent; }
            set
            {
                if ((value != allDayEvent))
                {
                    OnPropertyChanging("AllDayEvent", allDayEvent);
                    allDayEvent = value;
                    OnPropertyChanged("AllDayEvent");
                }
            }
        }

        [Column(Name = "fRecurrence", Storage = "recurrence", FieldType = "Recurrence")]
        public bool? Recurrence
        {
            get { return recurrence; }
            set
            {
                if ((value != recurrence))
                {
                    OnPropertyChanging("Recurrence", recurrence);
                    recurrence = value;
                    OnPropertyChanged("Recurrence");
                }
            }
        }

        [Column(Name = "WorkspaceLink", Storage = "workspace", FieldType = "CrossProjectLink")]
        public bool? Workspace
        {
            get { return workspace; }
            set
            {
                if ((value != workspace))
                {
                    OnPropertyChanging("Workspace", workspace);
                    workspace = value;
                    OnPropertyChanged("Workspace");
                }
            }
        }

        [Column(Name = "Category", Storage = "category", FieldType = "Choice")]
        public int? Category
        {
            get { return category; }
            set
            {
                if ((value != category))
                {
                    OnPropertyChanging("Category", category);
                    category = value;
                    OnPropertyChanged("Category");
                }
            }
        }
    }
}