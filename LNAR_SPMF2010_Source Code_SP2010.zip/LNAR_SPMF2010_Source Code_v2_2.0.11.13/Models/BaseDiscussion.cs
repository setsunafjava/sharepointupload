﻿using System;
using System.ComponentModel;
using Microsoft.SharePoint.Linq;

namespace DeutscheBank.SharePoint.LNAR.Framework.Models
{
    /// <summary>
    ///   Create a new discussion topic.
    /// </summary>
    [ContentType(Name = "Discussion", Id = "0x012002")]
    public abstract class BaseDiscussion : Folder
    {
        private string body;
        private string discussionSubject;
        private string emailSender;
        private DateTime? lastUpdated;
        private int? modifiedById;
        private string modifiedByNameWithPicture;
        private string post;
        private string postedBy;
        private string reply;
        private string threading;
        private string title;

        [Column(Name = "Title", Storage = "title", Required = true, FieldType = "Text")]
        public override string Title
        {
            get { return title; }
            set
            {
                if ((value != title))
                {
                    OnPropertyChanging("Title", title);
                    title = value;
                    OnPropertyChanged("Title");
                }
            }
        }

        [Column(Name = "Title", Storage = "discussionSubject", ReadOnly = true, FieldType = "Computed")]
        public string DiscussionSubject
        {
            get { return discussionSubject; }
            set
            {
                if ((value != discussionSubject))
                {
                    OnPropertyChanging("DiscussionSubject", discussionSubject);
                    discussionSubject = value;
                    OnPropertyChanged("DiscussionSubject");
                }
            }
        }

        [Column(Name = "Body", Storage = "body", FieldType = "Note")]
        public string Body
        {
            get { return body; }
            set
            {
                if ((value != body))
                {
                    OnPropertyChanging("Body", body);
                    body = value;
                    OnPropertyChanged("Body");
                }
            }
        }

        [Column(Name = "ReplyNoGif", Storage = "reply", ReadOnly = true, FieldType = "Computed")]
        public string Reply
        {
            get { return reply; }
            set
            {
                if ((value != reply))
                {
                    OnPropertyChanging("Reply", reply);
                    reply = value;
                    OnPropertyChanged("Reply");
                }
            }
        }

        [Column(Name = "BodyAndMore", Storage = "post", ReadOnly = true, FieldType = "Computed")]
        public string Post
        {
            get { return post; }
            set
            {
                if ((value != post))
                {
                    OnPropertyChanging("Post", post);
                    post = value;
                    OnPropertyChanged("Post");
                }
            }
        }

        [Column(Name = "Threading", Storage = "threading", ReadOnly = true, FieldType = "Computed")]
        public string Threading
        {
            get { return threading; }
            set
            {
                if ((value != threading))
                {
                    OnPropertyChanging("Threading", threading);
                    threading = value;
                    OnPropertyChanged("Threading");
                }
            }
        }

        [Column(Name = "PersonViewMinimal", Storage = "postedBy", ReadOnly = true, FieldType = "Computed")]
        public string PostedBy
        {
            get { return postedBy; }
            set
            {
                if ((value != postedBy))
                {
                    OnPropertyChanging("PostedBy", postedBy);
                    postedBy = value;
                    OnPropertyChanged("PostedBy");
                }
            }
        }

        [Column(Name = "DiscussionLastUpdated", Storage = "lastUpdated", ReadOnly = true, FieldType = "DateTime")]
        public DateTime? LastUpdated
        {
            get { return lastUpdated; }
            set
            {
                if ((value != lastUpdated))
                {
                    OnPropertyChanging("LastUpdated", lastUpdated);
                    lastUpdated = value;
                    OnPropertyChanged("LastUpdated");
                }
            }
        }

        [Column(Name = "EmailSender", Storage = "emailSender", FieldType = "Note")]
        public string EmailSender
        {
            get { return emailSender; }
            set
            {
                if ((value != emailSender))
                {
                    OnPropertyChanging("EmailSender", emailSender);
                    emailSender = value;
                    OnPropertyChanged("EmailSender");
                }
            }
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        [RemovedColumn]
        public override string Name
        {
            get { throw new InvalidOperationException("Field FileLeafRef was removed from content type Discussion."); }
            set { throw new InvalidOperationException("Field FileLeafRef was removed from content type Discussion."); }
        }

        [Column(Name = "MyEditor", Storage = "modifiedById", ReadOnly = true, FieldType = "User", IsLookupId = true)]
        public int? ModifiedById
        {
            get { return modifiedById; }
            set
            {
                if ((value != modifiedById))
                {
                    OnPropertyChanging("ModifiedById", modifiedById);
                    modifiedById = value;
                    OnPropertyChanged("ModifiedById");
                }
            }
        }

        [Column(Name = "MyEditor", Storage = "modifiedByNameWithPicture", ReadOnly = true, FieldType = "User",
            IsLookupValue = true)]
        public string ModifiedByNameWithPicture
        {
            get { return modifiedByNameWithPicture; }
            set
            {
                if ((value != modifiedByNameWithPicture))
                {
                    OnPropertyChanging("ModifiedByNameWithPicture", modifiedByNameWithPicture);
                    modifiedByNameWithPicture = value;
                    OnPropertyChanged("ModifiedByNameWithPicture");
                }
            }
        }
    }
}