﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus
{

    public class MappingFileConfig
    {
        public String MappingFilePath { get; set; }
        public String MappingUsersSheet { get; set; }
        public String MappingDatabaseLinkSheet { get; set; }
        public String MappingViewLinkSheet { get; set; }
        public String MappingDocumentLinkSheet { get; set; }
        
    }
}
