﻿using System.Collections.Generic;
using System.Xml.Serialization;
using DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus
{
    [XmlRoot("Task")]
    public class Task
    {
        public ListSystemFieldPermissionCollection SystemFieldPermissions;
        public FieldPermissionCollection FieldPermissions;

        //Only use to break item permission
        [XmlElement("ItemPermissions")]
        public BreakPermissionCollection ItemPermissions;

        [XmlIgnore]
        public IDictionary<string, string> DatabaseMappings;
        [XmlIgnore]
        public IDictionary<string, string> ViewMappings;
        [XmlIgnore]
        public IDictionary<string, string> DocumentMappings;

        #region Contructor

        public Task()
        {
            this.FieldPermissions = new FieldPermissionCollection();
            this.SystemFieldPermissions = new ListSystemFieldPermissionCollection();
            this.ItemPermissions = new BreakPermissionCollection();
        }

        #endregion
    }
}