using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Jobs
{
    public class FieldMappingCollection : MarshalByRefObject, ICollection<FieldMapping>
    {
        #region Privates

        private readonly Hashtable mappingFields = new Hashtable();
        
        #endregion

        #region Extra Methods
        public FieldMapping this[int index]
        {
            get
            {
                int passIndex = 0;
                foreach (DictionaryEntry pair in mappingFields)
                {
                    if (passIndex++ < index) continue;
                    return (FieldMapping)pair.Value;
                }
                throw new IndexOutOfRangeException();
            }
        }

        public FieldMapping this[string destinationFieldName]
        {
            get
            {
                if (mappingFields.ContainsKey(destinationFieldName))
                    return (FieldMapping)mappingFields[destinationFieldName];

                return null;
            }
        }

        //public bool Contains(string destinationFieldName)
        //{
        //    return mappingFields.ContainsKey(destinationFieldName);
        //}

        //THUTH 2011.01.18
        public bool Contains(string destinationFieldName)
        {
            return
                mappingFields.Keys.Cast<string>()
                .FirstOrDefault(a => a.ToLower().Equals(destinationFieldName.ToLower())) != null;
        }

        public void AddRange(FieldMapping[] fieldMappings)
        {
            for (int i = 0; i < fieldMappings.Length; i++)
            {
                FieldMapping mapping = new FieldMapping();
                mapping.DestinationField = fieldMappings[i].DestinationField;
                //mapping.IsMapUser = fieldMappings[i].IsMapUser;
                mapping.IsKey = fieldMappings[i].IsKey;
                mapping.SourceField = fieldMappings[i].SourceField;
                Add(mapping);
            }
        }
        public void AddRange(FieldMappingCollection fieldMappingCollection)
        {
            foreach (FieldMapping mapping in fieldMappingCollection)
            {
                FieldMapping newMapping = new FieldMapping();
                newMapping.DestinationField = mapping.DestinationField;
                //newMapping.IsMapUser = mapping.IsMapUser;
                newMapping.IsKey = mapping.IsKey;
                newMapping.SourceField = mapping.SourceField;
                Add(newMapping);
            }
        }
        #endregion

        #region ICollection<MappingField> Members

        public void Add(FieldMapping mappingField)
        {
            if (mappingFields.ContainsKey(mappingField.DestinationField.Name))
            {
                return;
            }
            if(mappingField.IsKey && IdentityField != null)
            {
                return;
            }
            mappingFields.Add(mappingField.DestinationField.Name, mappingField);
        }

        public void Clear()
        {
            mappingFields.Clear();
        }

        public bool Contains(FieldMapping mappingField)
        {
            return mappingFields.ContainsValue(mappingField);
        }

        public void CopyTo(FieldMapping[] array, int arrayIndex)
        {
            int index = 0;
            int passIndex = 0;
            IEnumerator<FieldMapping> mappingFields = GetEnumerator();
            while (mappingFields.MoveNext())
            {
                if (passIndex++ < arrayIndex) continue;
                array[index++] = mappingFields.Current;
            }
        }

        public int Count
        {
            get { return mappingFields.Count; }
        }

        [Obsolete("No Use")]
        public bool IsReadOnly
        {
            get { throw new NotImplementedException(); }
        }

        public bool Remove(FieldMapping mappingField)
        {
            if (mappingFields.ContainsKey(mappingField.DestinationField.Name))
            {
                mappingFields.Remove(mappingField.DestinationField.Name);
                return true;
            }
            return false;
        }

        public IEnumerator<FieldMapping> GetEnumerator()
        {
            foreach (DictionaryEntry pair in mappingFields)
            {
                yield return (FieldMapping)pair.Value;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            foreach (DictionaryEntry pair in mappingFields)
            {
                yield return pair.Value;
            }
        }

        #endregion
    
        #region Properties


        /// <summary>
        /// Return key field in collection.
        /// Identity field mark by isKey (property set to true).
        /// Return null if no field is key.
        /// </summary>
        public FieldMapping IdentityField
        {
            get
            {
                IEnumerator<FieldMapping> fields = GetEnumerator();
                while (fields.MoveNext())
                {
                    if (fields.Current.IsKey)
                    {
                        return fields.Current;
                    }
                }
                return null;
            }
        }

        #endregion
    
    }

}