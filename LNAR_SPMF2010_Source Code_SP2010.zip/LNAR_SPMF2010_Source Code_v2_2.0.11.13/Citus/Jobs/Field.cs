using System;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Jobs
{
    /// <summary>
    /// Mapping between external data field with
    /// project readable field, use as field entity.
    /// </summary>
    [Serializable()]
    public class Field
    {
        #region Privates

        private bool isKey;
        private int maxLength;
        private string name;
        private string displayName;
        private string alternativeName;
        private FieldType type;
        private object value;
        private string multiValueSeparator;        

        #endregion

        public Field()
        {
            
        }

        public Field(Field field)
        {
            this.AlternativeName = field.AlternativeName;
            this.DisplayName = field.DisplayName;
            this.IsKey = field.IsKey;
            this.MaxLength = field.MaxLength;
            this.MultivalueSeparator = field.MultivalueSeparator;
            this.Name = field.Name;
            this.Type = field.Type;
            this.Value = field.Value;
        }

        public Field(string internalName)
        {
            Name = internalName;
        }

        #region Properties

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string DisplayName
        {
            get { return displayName; }
            set { displayName = value; }
        }

        public string AlternativeName
        {
            get { return alternativeName; }
            set { alternativeName = value; }
        }

        //[XmlIgnore]
        public FieldType Type
        {
            get { return type; }
            set { type = value; }
        }

        public int MaxLength
        {
            get { return maxLength; }
            set { maxLength = value; }
        }

        public object Value
        {
            get { return value; }
            set { this.value = value; }
        }

        public string MultivalueSeparator
        {
            get
            {
                if (string.IsNullOrEmpty(multiValueSeparator))
                    return string.Empty;
                return multiValueSeparator;
            }
            set { multiValueSeparator = value; }
        }

        /// <summary>
        /// Indicate that this field is primary key of database table.
        /// </summary>
        public bool IsKey
        {
            get { return isKey; }
            set { isKey = value;}
        }
        #endregion     
    }

    /// <summary>
    /// Declaration types of field use in tool.
    /// </summary>
    public enum FieldType
    {
        Text,
        Numeric,
        Choice,
        MultiChoice,
        DateTime,
        DateOnly,
        Lookup,
        MultiLookup,
        People,
        MultiPeople,
        Boolean,
        RichText,
        PlainText,
        Attachments,
        ContentTypeLookupField,
        HyperlinkOrPicture,
        Unknown
    }
}