using System;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Jobs
{
    /// <summary>
    /// Declaration of job's mapping field.
    /// </summary>
    public class FieldMapping : MarshalByRefObject
    {
        #region Privates

        private Field destinationField;
        private Field sourceField;

        #endregion

        #region Properties

        public Field SourceField
        {
            get { return sourceField; }
            set { sourceField = value; }
        }

        public Field DestinationField
        {
            get { return destinationField; }
            set { destinationField = value; }
        }

        /// <summary>
        /// Indicate wether this mapping field is key for migration
        /// relationship
        /// </summary>
        public bool IsKey { set; get; }
        
        #endregion
    }
}