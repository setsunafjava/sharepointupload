namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Jobs
{
    /// <summary>
    /// tool job
    /// </summary> 
    public class Job
    {
        #region Privates

        private readonly FieldMappingCollection fields = new FieldMappingCollection();
        private readonly FieldMappingCollection mappingSystemField = new FieldMappingCollection();

        public string JobName { get; set; }
        public string DestinationTableName { get; set; }
        public bool IsChoice { get; set; }

        #endregion

        #region Properties

        
        /// <summary>
        /// Get mapping templates field
        /// use in migration process.
        /// </summary>
        public FieldMappingCollection FieldMappingCollection
        {
            get { return fields; }
        }

        public FieldMappingCollection MappingSystemFields
        {
            get { return mappingSystemField; }
        }

        #endregion
        
        #region Constructors

        /// <summary>
        /// Use for serialization only.
        /// Do not use this constructor when implement in Batch
        /// or Process.
        /// Must call SetOwnBatch function to set parent batch 
        /// after call this constructor.
        /// </summary>
        public Job()
        {
        }

        #endregion

    }
}