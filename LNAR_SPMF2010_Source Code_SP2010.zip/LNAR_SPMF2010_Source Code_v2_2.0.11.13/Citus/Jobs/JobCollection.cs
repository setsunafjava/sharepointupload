using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;


namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Jobs
{
    public class JobCollection : ICollection<Job>
    {
        #region Privates

        private readonly ListDictionary jobs = new ListDictionary();

        #endregion

        #region Extra Methods

        public Job this[int index]
        {
            get
            {
                int passIndex = 0;
                foreach (DictionaryEntry job in jobs)
                {
                    if (passIndex++ < index) continue;
                    return (Job) job.Value;
                }
                throw new IndexOutOfRangeException();
            }
        }

        public Job this[string name]
        {
            get
            {
                foreach (DictionaryEntry entry in jobs)
                {
                    Job job = (Job) entry.Value;
                    if (job.JobName.Equals(name))
                        return job;
                }
                return null;
            }
        }

        public bool Contains(string name)
        {
            foreach (DictionaryEntry entry in jobs)
            {
                Job job = (Job) entry.Value;
                if (job.JobName.Equals(name))
                    return true;
            }
            return false;
        }

        public void AddRange(Job[] jobs)
        {
            for (int i = 0; i < jobs.Length; i++)
            {
                Add(jobs[i]);
            }
        }
        public void AddRange(JobCollection jobCollection)
        {
            Job[] jobs = new Job[jobCollection.Count];
            jobCollection.CopyTo(jobs, 0);
            AddRange(jobs);
        }
        #endregion

        #region ICollection<Job> Members

        public void Add(Job job)
        {
            if (!Contains(job.JobName))
            {
                jobs.Add(job.GetHashCode(), job);
            }
        }

        public void Clear()
        {
            jobs.Clear();
        }

        public bool Contains(Job job)
        {
            return Contains(job.JobName);
        }

        public void CopyTo(Job[] array, int arrayIndex)
        {
            int index = 0;
            IEnumerator<Job> jobs = GetEnumerator();
            while (jobs.MoveNext())
            {
                arrayIndex--;
                if (arrayIndex > 0) continue;
                array[index++] = jobs.Current;
            }
        }

        public int Count
        {
            get { return jobs.Count; }
        }

        [Obsolete("No Use")]
        public bool IsReadOnly
        {
            get { throw new System.Exception("The method or operation is not implemented."); }
        }

        public bool Remove(Job job)
        {
            if (Contains(job.JobName))
            {
                jobs.Remove(job.GetHashCode());
                return true;
            }
            return false;
        }

        public IEnumerator<Job> GetEnumerator()
        {
            foreach (DictionaryEntry job in jobs)
            {
                yield return (Job) job.Value;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            foreach (DictionaryEntry job in jobs)
            {
                yield return job.Value;
            }
        }

        #endregion

        public void CopyTo(ArrayList array)
        {
            foreach (Job job in this)
            {
                array.Add(job);
            }
        }

        public void RevertFromArray(ArrayList array)
        {
            Clear();
            for (int i = 0; i < array.Count; i++)
            {
                Add((Job) array[i]);
            }
        }
               
        
    }
}