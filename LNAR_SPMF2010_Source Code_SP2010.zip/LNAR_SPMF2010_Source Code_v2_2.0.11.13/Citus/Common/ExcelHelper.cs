﻿using System;
using System.Linq;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Common
{
    public class ExcelHelper
    {
        #region Public method
        public static WorksheetPart GetWorksheetPartByName(SpreadsheetDocument document, string sheetName)
        {
            IEnumerable<Sheet> sheets = document.WorkbookPart.Workbook.GetFirstChild<Sheets>().Elements<Sheet>().Where(s => s.Name == sheetName);

            if (sheets.Count() == 0)
            {
                // The specified worksheet does not exist.
                return null;
            }

            string relationshipId = sheets.First().Id.Value;
            WorksheetPart worksheetPart = (WorksheetPart)document.WorkbookPart.GetPartById(relationshipId);
            return worksheetPart;
        }

        // Given a worksheet, a column name, and a row index, 
        // gets the cell at the specified column and 
        public static Cell GetCell(Worksheet worksheet,string columnName, uint rowIndex)
        {
            try
            {
                Row row = GetRow(worksheet, rowIndex);
                if (row == null && row.Count() < 0) return null;
                
                return row.Elements<Cell>().Where(c => string.Compare(c.CellReference.Value, columnName + rowIndex, true) == 0).First();
            }
            catch (Exception)
            {
                return new Cell();
            }
        }

        // Given a worksheet and a row index, return the row.
        public static Row GetRow(Worksheet worksheet, uint rowIndex)
        {
            return worksheet.GetFirstChild<SheetData>().Elements<Row>().Where(r => r.RowIndex == rowIndex).First();
        }

        public static int FindIndexCell(Worksheet worksheet, SharedStringTablePart stringTablePart, string colummname, string value)
        {
            if (worksheet == null || stringTablePart == null) return -1;
            string ind = worksheet.WorksheetPart.Worksheet.Descendants<Row>().LastOrDefault().RowIndex;
            int limit = -1;
            if(int.TryParse(ind, out limit) && limit != -1)
            {
                for(int i=2; i <= limit; i++)
                {
                    uint uint1 = uint.Parse(i.ToString());
                    Cell cell = GetCell(worksheet.WorksheetPart.Worksheet,colummname,uint1);
                    if (cell != null && cell.ChildElements.Count > 0)
                    {
                        string val = cell.ElementAt(0).InnerText;
                        if ((cell.DataType != null) && (cell.DataType == CellValues.SharedString))
                        {
                            val = stringTablePart.SharedStringTable.ChildElements[Int32.Parse(val)].InnerText;
                            if (val == value) return i;
                        }
                    }
                }
            }
            
            return -1;
        }

        public static string GetCellValue(Cell cell, SharedStringTablePart stringTablePart)
        {
            if (cell == null || cell.ChildElements.Count == 0) return string.Empty;
            string value = cell.ElementAt(0).InnerText;
            if ((cell.DataType != null) && (cell.DataType == CellValues.SharedString))
                value = stringTablePart.SharedStringTable.ChildElements[Int32.Parse(value)].InnerText;
            return value;
        }

        public static string GetCellValue(Row row, string columnName, SharedStringTablePart stringTablePart)
        {
            Cell cell = GetCell(row, columnName);
            if (cell == null || cell.ChildElements.Count == 0) return string.Empty;
            string value = cell.ElementAt(0).InnerText;
            if ((cell.DataType != null) && (cell.DataType == CellValues.SharedString))
                value = stringTablePart.SharedStringTable.ChildElements[Int32.Parse(value)].InnerText;
            return value;
        }

        public static string GetValue(Worksheet worksheet, SharedStringTablePart stringTablePart, string colummName)
        {
            if (!string.IsNullOrEmpty(colummName))
            {
                Cell cell = GetCell(worksheet, GetColumnName(colummName), GetRowIndex(colummName));
                if (cell != null)
                    colummName = GetCellValue(cell, stringTablePart);
                if (!string.IsNullOrEmpty(colummName))
                    return colummName;
            }
            return string.Empty;
        }

        // Given a cell name, parses the specified cell to get the column name.
        public static string GetColumnName(string cellName)
        {
            // Create a regular expression to match the column name portion of the cell name.
            Regex regex = new Regex("[A-Za-z]+");
            Match match = regex.Match(cellName);

            return match.Value;
        }

        // Given a cell name, parses the specified cell to get the row index.
        public static uint GetRowIndex(string cellName)
        {
            //if (string.IsNullOrEmpty(cellName)) return 0;
            // Create a regular expression to match the row index portion the cell name.
            Regex regex = new Regex(@"\d+");
            Match match = regex.Match(cellName);

            return uint.Parse(match.Value);
        }

        public static string SearchValue(Worksheet worksheet, SharedStringTablePart stringTablePart, string value)
        {
            try
            {
                IEnumerable<Row> rows = worksheet.WorksheetPart.Worksheet.Descendants<Row>();
                if (rows != null && rows.Count() > 0)
                {
                    foreach (Row row in rows)
                    {
                        int max = row.Count();
                        if (max < 0) continue;
                        IEnumerable<Cell> cells = row.Descendants<Cell>();
                        foreach (Cell cell in cells)
                        {
                            if (cell != null && cell.ChildElements.Count > 0)
                            {
                                string val = cell.ElementAt(0).InnerText;
                                if ((cell.DataType != null) && (cell.DataType == CellValues.SharedString))
                                {
                                    val = stringTablePart.SharedStringTable.ChildElements[Int32.Parse(val)].InnerText;
                                    if (val == value) return cell.CellReference;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return string.Empty;
        }

        public static Cell SearchCellValue(Worksheet worksheet, SharedStringTablePart stringTablePart, string value)
        {
            try
            {
                IEnumerable<Row> rows = worksheet.WorksheetPart.Worksheet.Descendants<Row>();
                if (rows != null && rows.Count() > 0)
                {
                    foreach (Row row in rows)
                    {
                        int max = row.Count();
                        if (max < 0) continue;
                        IEnumerable<Cell> cells = row.Descendants<Cell>();
                        foreach (Cell cell in cells)
                        {
                            if (cell != null && cell.ChildElements.Count > 0)
                            {
                                string val = cell.ElementAt(0).InnerText;
                                if ((cell.DataType != null) && (cell.DataType == CellValues.SharedString))
                                {
                                    val = stringTablePart.SharedStringTable.ChildElements[Int32.Parse(val)].InnerText;
                                    if (val == value) return cell;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return null;
        }

        public static IEnumerable<Row> GetRows(Worksheet worksheet)
        {
            return worksheet.WorksheetPart.Worksheet.Descendants<Row>();
        }

        public static IEnumerable<Row> GetRows(Worksheet worksheet, int rowIndexStart)
        {
            return worksheet.WorksheetPart.Worksheet.Descendants<Row>().Where(a=>a.RowIndex >= rowIndexStart);
        }

        public static IEnumerable<Cell> GetCells(Worksheet worksheet, string columnName, int rowIndexStart)
        {
            foreach (Row row in GetRows(worksheet))
            {
                yield return GetCell(worksheet, columnName, (uint)rowIndexStart++);
            }
        }
        public static Cell GetCell(Row row, string columnName)
        {
            return row.Descendants<Cell>().Where(a => GetColumnName(a.CellReference).Equals(columnName, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
        }
        public static string NextColummn(string currentColumn)
        {
            currentColumn = currentColumn.ToUpper();
            string result = string.Empty;
            int len = currentColumn.Length - 1;
            int i = 1;
            while (len >= 0)
            {
                char c = currentColumn[len];
                int j = c + i;

                if (j > 90)
                {
                    j = 65;
                    result = ((char)j).ToString() + result;
                    i = 1;
                    if (len == 0)
                    {
                        result = ((char)65).ToString() + result;
                        break;
                    }
                }
                else
                {
                    result = ((char)j).ToString() + result;
                    if (len > 0)
                    {
                        result = currentColumn.Substring(0, len) + result;
                        break;
                    }
                    i = 0;
                }
                len--;
            }
            return result;
        }
        
        #endregion

        #region Get Field

        public static Cell GetFieldColumnName(Worksheet worksheet, string columnName, uint indexRow)
        {
            Cell dataTypeCell = GetCell(worksheet, columnName, indexRow);
            return dataTypeCell;
        }

        #endregion
        
    }
}
