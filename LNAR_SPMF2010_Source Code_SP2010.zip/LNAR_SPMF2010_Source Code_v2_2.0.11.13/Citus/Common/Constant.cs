﻿using System;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Common
{
    public class Constant
    {
        public class Settings
        {

        }

        public class ExcelMapping
        {
            //Column name of DB Sheet
            public const string DB_LINK_ID = @"Database ReplicaID";
            public const string DB_LINK_LINK = @"Link";

            //Column name of View link sheet
            public const string VIEW_LINK_ID = @"Database ReplicaID";
            public const string VIEW_LINK_UNID = @"View UNID";
            public const string VIEW_LINK_LINK = @"Link";

            //Column name of Database sheet
            public const string DOCUMENT_LINK_DATABSE_ID = @"Database ReplicaID";
            public const string DOCUMENT_LINK_DESTINATION_UNID = @"Destination ID";
            public const string DOCUMENT_LINK_LINK = @"Link";

            //Sheet name of user mapping
            public const string NOTES_USER = @"Notes User";
            public const string MAP_USER = @"Map User";

        }

        public class RichText
        {

            //parttern of links in richtext
            public const string DOC_LINK_PATTERN = @"http://{Citus_DocumentLink}/(?<unid>\w{32});(?<dbid>\w{16})";
            public const string VIEW_LINK_PATTERN = @"http://{Citus_ViewLink}/(?<unid>\w{32});(?<dbid>\w{16})";
            public const string DB_LINK_PATTERN = @"http://{Citus_DatabaseLink}/(?<dbid>\w{16})";
            public const string ATTACHMENT_LINK_PATTERN = @"http://{Citus_AttachmentLink}/";
        }

        public class SystemFields
        {
            public const string UNID = "COM_FSOFT_Citus_UNID";

            public const string RICHTEXT_FIELDS_UPDATED = "COM_FSOFT_Citus_P_RichText";
            public const string SYSTEM_FIELDS_UPDATED = "COM_FSOFT_Citus_P_System";
            public const string ALL_UPDATED = "COM_FSOFT_Citus_P_All";

            public const string CITUS_CREATED = "COM_FSOFT_Citus_Created";
            public const string CITUS_CREATED_BY = "COM_FSOFT_Citus_CreatedBy";
            public const string CITUS_MODIFIED = "COM_FSOFT_Citus_LastUpdated";
            public const string CITUS_MODIFIED_BY = "COM_FSOFT_Citus_LastUpdatedBy";

            public const string CREATED = "Created";
            public const string MODIFIED = "Modified";
            public const string LAST_UPDATED = "Last Updated";
            public const string MODIFIED_BY = "Modified By";
            public const string CREATED_BY = "Created By";
            public const string EDITOR = "Editor";
        }

        public class General
        {
            public const string MULTI_VALUE_SEPARATOR = ";#";
            public const string LINE_SEPARATOR = "----------------------------------------------------------------------";
        }

        public class Message
        {

            public const string ERROR_BREAKPERMISSIONS_ITEM = "Error caught when break permissions for Item [{0}] of list [{1}] with user or group name [{2}], Detail: [{3}]";
            public static readonly string ERROR_GENERIC_EXCEPTION_FORMAT = string.Concat(
                    "Error message as follows:",
                    Environment.NewLine,
                    "{0}",
                    Environment.NewLine,
                    General.LINE_SEPARATOR);
            public const string ERROR_BREAKPERMISSIONS_LIST = "Error caught when break permissions for List [{0}], Detail: [{1}]";
        }
    }
}
