﻿using System;
using System.IO;
using System.Web;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Common
{
    public static class GeneralUtils
    {
        public static string NormalizeURL(string url)
        {
            url = url.ToLowerInvariant();
            if (url.IndexOf(".aspx", StringComparison.OrdinalIgnoreCase) > 0)
            {
                url = url.Substring(0, url.LastIndexOf("/",
                    StringComparison.OrdinalIgnoreCase));
            }
            if (url.IndexOf("/lists/", StringComparison.OrdinalIgnoreCase) > 0)
            {
                url = url.Substring(0, url.IndexOf("/lists/",
                    StringComparison.OrdinalIgnoreCase));
            }
            return url;
        }

        public static string GetSPWebName(string siteUrl)
        {
            string webUrl = siteUrl;
            if (webUrl.Contains("localhost"))
            {
                webUrl = webUrl.Replace("localhost", Environment.MachineName).ToLowerInvariant();
            }

            using (SPSite siteCollection = new SPSite(siteUrl))
            {
                webUrl = webUrl.ToLowerInvariant().Replace(siteCollection.Url.ToLowerInvariant(), string.Empty);
            }
            webUrl = webUrl.Trim('/');
            return webUrl;
        }
        public static string GetSPWebName(string siteUrl, SPSite siteCollection)
        {
            string webUrl = siteUrl;
            if (webUrl.Contains("localhost"))
            {
                webUrl = webUrl.Replace("localhost", Environment.MachineName).ToLowerInvariant();
            }

            //using (SPSite siteCollection = new SPSite(siteUrl))
            //{
            //     webUrl = webUrl.ToLowerInvariant().Replace(siteCollection.Url.ToLowerInvariant(), string.Empty);
            //}
            webUrl = webUrl.ToLowerInvariant().Replace(siteCollection.Url.ToLowerInvariant(), string.Empty);
            webUrl = webUrl.Trim('/');
            return webUrl;
        }
     

        public static bool In<T>(this T t, params T[] items)
        {
            foreach (T item in items)
            {
                if (item.Equals(t))
                { return true; }
            }
            return false;
        }

        public static string HtmlEncode(this string s)
        {
            return HttpUtility.HtmlEncode(s);
        }

        /// <summary>
        /// Checks Whether The Given SPListItem Contains A Value
        /// And If So, Returns The Valus As A String. Otherwise
        /// Returns An Empty String
        /// </summary>
        /// <param name="listItem">The SPListItem To Check</param>
        /// <param name="field">The Field Whose Value To Try Get</param>
        /// <returns>Field Value Or Empty String</returns>
        public static string GetFieldValue(this SPListItem listItem, string field)
        {
            if (listItem.Fields.ContainsFieldWithStaticName(field))
            {
                //If There Is A Value
                if (listItem[field] != null)
                {
                    //Return It As A String
                    return listItem[field].ToString();
                }
                else { return string.Empty; }
            }
            else { return string.Empty; }
        }
    }
}