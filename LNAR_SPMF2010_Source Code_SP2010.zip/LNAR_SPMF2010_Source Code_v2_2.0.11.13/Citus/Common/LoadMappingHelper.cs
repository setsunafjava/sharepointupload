﻿using System;
using System.Collections.Generic;
using System.IO;
using DeutscheBank.SharePoint.LNAR.Framework.Citus.Common;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Common
{
    public class LoadMappingHelper
    {
        private SpreadsheetDocument spreadSheet;
        public LoadMappingHelper(Stream excellContent)
        {
           spreadSheet = SpreadsheetDocument.Open(excellContent, true);
        }
        public LoadMappingHelper(string excellFilePath)
        {
            spreadSheet = SpreadsheetDocument.Open(excellFilePath, true);
        }

        public IDictionary<string, string> GetDBMappings(string sheetName)
        {
            Dictionary<string, string> dbMapping = new Dictionary<string, string>();

            if (spreadSheet != null && !string.IsNullOrEmpty(sheetName))
            {
                string colDbId = string.Empty, colDbLink = string.Empty;
                int rowStart = -1;
                try
                {
                    WorksheetPart WorkSheet = ExcelHelper.GetWorksheetPartByName(spreadSheet, sheetName);

                    string dbIdCellName = ExcelHelper.SearchValue(WorkSheet.Worksheet,
                                                                  spreadSheet.WorkbookPart.SharedStringTablePart,
                                                                  Constant.ExcelMapping.DB_LINK_ID);
                    if (!string.IsNullOrEmpty(dbIdCellName))
                    {
                        colDbId = ExcelHelper.GetColumnName(dbIdCellName);
                        rowStart = (int) ExcelHelper.GetRowIndex(dbIdCellName);
                    }

                    string dbLinkCellName = ExcelHelper.SearchValue(WorkSheet.Worksheet,
                                                                    spreadSheet.WorkbookPart.SharedStringTablePart,
                                                                    Constant.ExcelMapping.DB_LINK_LINK);

                    if (!string.IsNullOrEmpty(dbLinkCellName))
                    {
                        colDbLink = ExcelHelper.GetColumnName(dbLinkCellName);
                        int rowDbLink = (int) ExcelHelper.GetRowIndex(dbLinkCellName);
                        if (rowStart != rowDbLink) rowStart = -1;
                    }

                    if (!string.IsNullOrEmpty(colDbId)
                        && !string.IsNullOrEmpty(colDbLink)
                        && rowStart > 0)
                    {
                        rowStart++;
                        bool isFinish = false;
                        IEnumerator<Row> rows = ExcelHelper.GetRows(WorkSheet.Worksheet, rowStart).GetEnumerator();
                        while (!isFinish && rows.MoveNext())
                        {
                            string dbId = string.Empty, dbLink = string.Empty;
                            dbId = ExcelHelper.GetCellValue(rows.Current, colDbId,
                                                            spreadSheet.WorkbookPart.SharedStringTablePart);
                            dbLink = ExcelHelper.GetCellValue(rows.Current, colDbLink,
                                                              spreadSheet.WorkbookPart.SharedStringTablePart);
                            isFinish = string.IsNullOrEmpty(dbLink) && string.IsNullOrEmpty(dbId);
                            if (!string.IsNullOrEmpty(dbId) && !dbMapping.ContainsKey(dbId))
                                dbMapping.Add(dbId, dbLink);
                        }

                    }
                }
                catch (Exception exception)
                {
                    throw exception;
                }
            }
            return dbMapping;
        }

        public IDictionary<string, string> GetViewMapping(string sheetName)
        {
            IDictionary<string, string> viewMapping = new Dictionary<string, string>();

            if (spreadSheet != null && !string.IsNullOrEmpty(sheetName))
            {
                string ColViewId = string.Empty, ColViewUnid = string.Empty, ColViewLink = string.Empty;
                int rowStart = -1;
                try
                {
                    WorksheetPart WorkSheet = ExcelHelper.GetWorksheetPartByName(spreadSheet, sheetName);

                    string viewIdCellName = ExcelHelper.SearchValue(WorkSheet.Worksheet,
                                                                    spreadSheet.WorkbookPart.SharedStringTablePart,
                                                                    Constant.ExcelMapping.VIEW_LINK_ID);
                    if (!string.IsNullOrEmpty(viewIdCellName))
                    {
                        ColViewId = ExcelHelper.GetColumnName(viewIdCellName);
                        rowStart = (int) ExcelHelper.GetRowIndex(viewIdCellName);
                    }

                    string viewUnidCellName = ExcelHelper.SearchValue(WorkSheet.Worksheet,
                                                                      spreadSheet.WorkbookPart.SharedStringTablePart,
                                                                      Constant.ExcelMapping.VIEW_LINK_UNID);

                    if (!string.IsNullOrEmpty(viewUnidCellName))
                    {
                        ColViewUnid = ExcelHelper.GetColumnName(viewUnidCellName);
                        int a = (int) ExcelHelper.GetRowIndex(viewUnidCellName);
                        if (rowStart != a) rowStart = -1;
                    }

                    string viewLinkCellName = ExcelHelper.SearchValue(WorkSheet.Worksheet,
                                                                      spreadSheet.WorkbookPart.SharedStringTablePart,
                                                                      Constant.ExcelMapping.VIEW_LINK_UNID);

                    if (!string.IsNullOrEmpty(viewLinkCellName))
                    {
                        ColViewLink = ExcelHelper.GetColumnName(viewLinkCellName);
                        int a = (int) ExcelHelper.GetRowIndex(viewLinkCellName);
                        if (rowStart != a) rowStart = -1;
                    }

                    if (!string.IsNullOrEmpty(ColViewId)
                        && !string.IsNullOrEmpty(ColViewUnid)
                        && !string.IsNullOrEmpty(ColViewLink)
                        && rowStart > 0)
                    {
                        rowStart++;
                        bool isFinish = false;
                        IEnumerator<Row> rows = ExcelHelper.GetRows(WorkSheet.Worksheet, rowStart).GetEnumerator();
                        while (!isFinish && rows.MoveNext())
                        {
                            string viewId = ExcelHelper.GetCellValue(rows.Current, ColViewId,
                                                                     spreadSheet.WorkbookPart.SharedStringTablePart);
                            string viewUnid = ExcelHelper.GetCellValue(rows.Current, ColViewUnid,
                                                                       spreadSheet.WorkbookPart.SharedStringTablePart);
                            string viewLink = ExcelHelper.GetCellValue(rows.Current, ColViewLink,
                                                                       spreadSheet.WorkbookPart.SharedStringTablePart);
                            isFinish = string.IsNullOrEmpty(viewId) && string.IsNullOrEmpty(viewUnid);
                            viewId = string.Concat(viewUnid, ";", viewId);

                            if (!string.IsNullOrEmpty(viewId) && !viewMapping.ContainsKey(viewId))
                                viewMapping.Add(viewId, viewLink);
                        }

                    }
                }catch(Exception exception)
                {
                    throw exception;
                }
            }
            return viewMapping;
        }

        public IDictionary<string, string> GetDocumentMapping(string sheetName)
        {
            IDictionary<string, string> DocumentMapping = new Dictionary<string, string>();

            if (spreadSheet != null && !string.IsNullOrEmpty(sheetName))
            {
                string colDocId = string.Empty, colDocDestinationUnid = string.Empty, colDocLink = string.Empty;
                int rowStart = -1;

                try
                {
                    WorksheetPart WorkSheet = ExcelHelper.GetWorksheetPartByName(spreadSheet, sheetName);

                    string docIdCellName = ExcelHelper.SearchValue(WorkSheet.Worksheet,
                                                                   spreadSheet.WorkbookPart.SharedStringTablePart,
                                                                   Constant.ExcelMapping.DOCUMENT_LINK_DATABSE_ID);
                    if (!string.IsNullOrEmpty(docIdCellName))
                    {
                        colDocId = ExcelHelper.GetColumnName(docIdCellName);
                        rowStart = (int) ExcelHelper.GetRowIndex(docIdCellName);
                    }

                    string docDesUnidCellName = ExcelHelper.SearchValue(WorkSheet.Worksheet,
                                                                        spreadSheet.WorkbookPart.SharedStringTablePart,
                                                                        Constant.ExcelMapping.
                                                                            DOCUMENT_LINK_DESTINATION_UNID);

                    if (!string.IsNullOrEmpty(docDesUnidCellName))
                    {
                        colDocDestinationUnid = ExcelHelper.GetColumnName(docDesUnidCellName);
                        int a = (int) ExcelHelper.GetRowIndex(docDesUnidCellName);
                        if (rowStart != a) rowStart = -1;
                    }

                    string docLinkCellName = ExcelHelper.SearchValue(WorkSheet.Worksheet,
                                                                     spreadSheet.WorkbookPart.SharedStringTablePart,
                                                                     Constant.ExcelMapping.DOCUMENT_LINK_LINK);

                    if (!string.IsNullOrEmpty(docLinkCellName))
                    {
                        colDocLink = ExcelHelper.GetColumnName(docLinkCellName);
                        int a = (int) ExcelHelper.GetRowIndex(docLinkCellName);
                        if (rowStart != a) rowStart = -1;
                    }

                    if (!string.IsNullOrEmpty(colDocId)
                        && !string.IsNullOrEmpty(colDocDestinationUnid)
                        && !string.IsNullOrEmpty(colDocLink)
                        && rowStart > 0)
                    {
                        rowStart++;
                        bool isFinish = false;
                        IEnumerator<Row> rows = ExcelHelper.GetRows(WorkSheet.Worksheet, rowStart).GetEnumerator();
                        while (!isFinish && rows.MoveNext())
                        {
                            string docId = ExcelHelper.GetCellValue(rows.Current, colDocId,
                                                                    spreadSheet.WorkbookPart.SharedStringTablePart);
                            string docLink = ExcelHelper.GetCellValue(rows.Current, colDocLink,
                                                                      spreadSheet.WorkbookPart.SharedStringTablePart);
                            string docDestinationUnid = ExcelHelper.GetCellValue(rows.Current, colDocDestinationUnid,
                                                                                 spreadSheet.WorkbookPart.
                                                                                     SharedStringTablePart);
                            isFinish = string.IsNullOrEmpty(docId) || string.IsNullOrEmpty(docDestinationUnid);
                            docId = string.Concat(docDestinationUnid, ";", docId);

                            if (!string.IsNullOrEmpty(docId) && !DocumentMapping.ContainsKey(docId))
                                DocumentMapping.Add(docId, docLink);
                        }

                    }
                }catch(Exception exception)
                {
                    throw exception;
                }
            }
            
            return DocumentMapping;
        }

        public Dictionary<string, string> GetUsersMapping(string sheetName)
        {
            Dictionary<string, string> userMapping = new Dictionary<string, string>();
            if (spreadSheet != null && !string.IsNullOrEmpty(sheetName))
            {
                string colNotesUser = string.Empty, colMapUser = string.Empty;
                int rowStart = -1;

                try
                {

                    WorksheetPart WorkSheet = ExcelHelper.GetWorksheetPartByName(spreadSheet, sheetName);

                    string colNoteCellName = ExcelHelper.SearchValue(WorkSheet.Worksheet,
                                                                     spreadSheet.WorkbookPart.SharedStringTablePart,
                                                                     Constant.ExcelMapping.NOTES_USER);
                    if (!string.IsNullOrEmpty(colNoteCellName))
                    {
                        colNotesUser = ExcelHelper.GetColumnName(colNoteCellName);
                        rowStart = (int) ExcelHelper.GetRowIndex(colNoteCellName);
                    }

                    string colMapCellName = ExcelHelper.SearchValue(WorkSheet.Worksheet,
                                                                    spreadSheet.WorkbookPart.SharedStringTablePart,
                                                                    Constant.ExcelMapping.MAP_USER);

                    if (!string.IsNullOrEmpty(colMapCellName))
                    {
                        colMapUser = ExcelHelper.GetColumnName(colMapCellName);
                        int rowDbLink = (int) ExcelHelper.GetRowIndex(colMapCellName);
                        if (rowStart != rowDbLink) rowStart = -1;
                    }

                    if (!string.IsNullOrEmpty(colNotesUser)
                        && !string.IsNullOrEmpty(colMapUser)
                        && rowStart > 0)
                    {
                        rowStart++;
                        bool isFinish = false;
                        IEnumerator<Row> rows = ExcelHelper.GetRows(WorkSheet.Worksheet, rowStart).GetEnumerator();
                        while (!isFinish && rows.MoveNext())
                        {
                            string notesUser = string.Empty, mapUser = string.Empty;
                            notesUser = ExcelHelper.GetCellValue(rows.Current, colNotesUser,
                                                                 spreadSheet.WorkbookPart.SharedStringTablePart);
                            mapUser = ExcelHelper.GetCellValue(rows.Current, colMapUser,
                                                               spreadSheet.WorkbookPart.SharedStringTablePart);
                            isFinish = string.IsNullOrEmpty(notesUser) && string.IsNullOrEmpty(mapUser);
                            if (!string.IsNullOrEmpty(notesUser) && !userMapping.ContainsKey(notesUser))
                                userMapping.Add(notesUser, mapUser);
                        }

                    }
                }catch(Exception exception)
                {
                    throw exception;
                }
            }

            return userMapping;
        }

        public void Close()
        {
            if (spreadSheet != null)
            {
                spreadSheet.Close();
                spreadSheet.Dispose();
            }
        }
    }
}
