﻿using System;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Serialization;
using DeutscheBank.SharePoint.DSpace.Diagnostics;
using DeutscheBank.SharePoint.LNAR.Framework.Citus.Jobs;
using DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission;
using DeutscheBank.SharePoint.LNAR.Framework.Common;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Common
{
    public class LoadConfigHelper
    {
        private const string XML_FORMAT = @"<?xml version=""1.0"" encoding=""utf-8""?>
                                            <{1} xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
                                            {0}
                                           </{1}>";
        public string FilePath
        {
            get; private set;
        }

        public LoadConfigHelper(string filePath)
        {
            FilePath = filePath;
        }

        public LoadConfigHelper()
        {
           
        }


        public JobCollection GetJobs(Stream fileContent)
        {
            JobCollection jobs = new JobCollection();
            String xmlContent = GetFirstValueByTagName(fileContent, "CitusTranformerConfiguration");
            XmlDocument xmlDocument = new XmlDocument();
            if (!string.IsNullOrEmpty(xmlContent))
            {
                xmlDocument.LoadXml(HttpUtility.HtmlDecode(xmlContent));
                XmlElement xmlElement =
                    (xmlDocument.SelectNodes(@"Batch/Jobs")).Cast<XmlElement>().FirstOrDefault();

                if (xmlElement != null)
                {
                    jobs = XmlDeserialize<JobCollection>(
                        string.Format(XML_FORMAT, xmlElement.InnerXml,"ArrayOfJob"));
                }

            }
            return jobs;
        }

        public BreakPermissionCollection GetBreakPermissionsObject(Stream fileContent)
        {
            BreakPermissionCollection breakPermissions = new BreakPermissionCollection();
            String xmlContent = GetFirstValueByTagName(fileContent, "CitusTranformerConfiguration");
            XmlDocument xmlDocument = new XmlDocument();

            if (!string.IsNullOrEmpty(xmlContent))
            {
                xmlDocument.LoadXml(HttpUtility.HtmlDecode(xmlContent));
                XmlElement xmlBPElement =
                    (xmlDocument.SelectNodes(@"Batch/BreakPermission")).Cast<XmlElement>().FirstOrDefault();

                if (xmlBPElement != null)
                {
                    breakPermissions = XmlDeserialize<BreakPermissionCollection>(
                        string.Format(XML_FORMAT, xmlBPElement.InnerXml, "ArrayOfBreakPermission"));
                }
                
            }
            return breakPermissions;
        }

        public MappingFileConfig GetMappingFileConfig(Stream fileContent)
        {
            MappingFileConfig mappingFileConfig = new MappingFileConfig();
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(fileContent);
            XmlElement xmlBPElement =
                    (xmlDocument.SelectNodes(@"ConfigurationManager/MappingFile")).Cast<XmlElement>().FirstOrDefault();
            
            if (xmlBPElement != null)
            {
                mappingFileConfig = XmlDeserialize<MappingFileConfig>(
                    string.Format(XML_FORMAT, xmlBPElement.InnerXml, "MappingFileConfig"));
            }
            return mappingFileConfig;
        }

        public Task GetTaskObject(Stream fileContent)
        {
            Task task = new Task();
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(fileContent);
            XmlElement xmlElement =
                    (xmlDocument.SelectNodes(@"ConfigurationManager/CitusPostProcessorConfiguration")).Cast<XmlElement>().FirstOrDefault();

            if (xmlElement != null)
            {
                xmlElement.InnerXml = HttpUtility.HtmlDecode(xmlElement.InnerXml);
                XmlElement xmlElementChild = (xmlElement.SelectNodes("Tasks/Task")).Cast<XmlElement>().FirstOrDefault();
                if (xmlElementChild != null)
                {
                    task = XmlDeserialize<Task>(
                        string.Format(XML_FORMAT, xmlElementChild.InnerXml,"Task"));
                }

            }
            return task;
        }

        private String GetFirstValueByTagName(Stream fileContent, string tagName)
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(fileContent);
            XmlElement[] xmlElements = xmlDocument.GetElementsByTagName(tagName).Cast<XmlElement>().ToArray();
            if (xmlElements != null && xmlElements.Length > 0)
            {
               return xmlElements[0].InnerXml;
            }
            return string.Empty;
        }

        private String GetFirstValueByTagName(string filePath, string tagName)
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(filePath);
            XmlElement[] xmlElements = xmlDocument.GetElementsByTagName(tagName).Cast<XmlElement>().ToArray();
            if (xmlElements != null && xmlElements.Length > 0)
            {
                return xmlElements[0].InnerXml;
            }
            return string.Empty;
        }
        
        private T XmlDeserialize<T>(string s)
        {
            object o = new object();
            StringReader stringReader = new StringReader(s);
            XmlReader xmlReader = XmlReader.Create(stringReader);
            try
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
                lock (o)
                {
                    T obj = (T)xmlSerializer.Deserialize(xmlReader);
                    xmlReader.Close();
                    return obj;
                }
            }
            catch (Exception ex)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
            }
            finally
            {
                if (xmlReader != null)
                { xmlReader.Close(); }
            }

            return default(T);
        }

    }
}
