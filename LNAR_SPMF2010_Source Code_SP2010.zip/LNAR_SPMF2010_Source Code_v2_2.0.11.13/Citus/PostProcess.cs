﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using DeutscheBank.SharePoint.LNAR.Framework.Citus.Jobs;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using DeutscheBank.SharePoint.LNAR.Framework.Citus.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using SPUser = Microsoft.SharePoint.SPUser;
using SPGroup = Microsoft.SharePoint.SPGroup;
using System.Net;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.DSpace.Diagnostics;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus
{

    public sealed class PostProcess
    {
        #region Private Fields

        //static System.Text.StringBuilder listUnid = new System.Text.StringBuilder(); 
        private Guid currentListID = Guid.Empty;

        private BreakPermissionCollection BreakPermissions = new BreakPermissionCollection();
        // User login name as Key for SPUser and use GroupName as key for SPGroup
        private Dictionary<string, object> siteUserGroup = new Dictionary<string, object>();

        private Task currentTask = new Task();
        private MappingFileConfig mappingFileConfig = null;
        private JobCollection jobs = null;
        private Guid SiteId;
        private Guid WebId;
        private bool IsRePostProcess = false;
        private long TotalItems = 0, PostProcessedItems = 0;
        private string CurrentJobName;
        #region Batch Update

        private int BatchUpdateSize = 10;
        private Dictionary<int, List<string>> batchData = new Dictionary<int, List<string>>();

        // The format of the batch method (this holds many update methods)
        private const string batchFormat =
@"<?xml version=""1.0"" encoding=""UTF-8""?>
<ows:Batch RootFolder=""{0}"" OnError=""Continue"">
    {1}
</ows:Batch>";

        // The format of one update method
        private const string methodFormat =
@"<Method ID=""{0}"">
    <SetList>{1}</SetList>
    <SetVar Name=""Cmd"">Save</SetVar>
    <SetVar Name=""ID"">{2}</SetVar>
{3}
</Method>";

        private const string fieldFormat =
@"    <SetVar Name=""urn:schemas-microsoft-com:office:office#{0}"">{1}</SetVar>";

        // A unique ID to use for each update method
        private int methodID = 0;

        #endregion

        private SPUserToken adminToken = null;
        #endregion

        #region Correct Fields

        private enum UpdateType
        {
            RichText,
            SystemFields,
            Permission,
            All
        }


        public bool RunPostProcess(SPSite site, SPWeb web, string configName, string mappingName, bool isRePostProcess)
        {
            IsRePostProcess = isRePostProcess;
            bool isSuccess = true;
            SiteId = site.ID;
            WebId = web.ID;
            if (LoadConfig(configName, web) && LoadMappings(mappingName, web))
            {
                if (jobs != null && jobs.Count > 0)
                    foreach (Job job in jobs.Where(a => a.IsChoice))
                    {
                        try
                        {
                            CurrentJobName = job.JobName;
                            Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium,
                                             string.Format("Start Post-Process list [{0}] ....",
                                                           job.DestinationTableName));
                            IEnumerable<string> richTextFields =
                                job.FieldMappingCollection.Where(b => b.DestinationField.Type == FieldType.RichText).
                                    Select(
                                        a => a.DestinationField.AlternativeName);

                            CorrectFieldsByListName(job.DestinationTableName, richTextFields, true, true,
                                                    BreakPermissions);
                            Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium,
                                             string.Format("End Post-Process list [{0}].", job.DestinationTableName));

                        }
                        catch (Exception exception)
                        {
                            isSuccess = false;
                        }
                    }
            }
            else isSuccess = false;

            return isSuccess;
        }


        /// <summary>
        /// Run post processing for all list items in provided list
        /// </summary>
        /// <param name="listID">The ID of the list to update</param>
        /// <param name="richTextFields">The RichText fields to update</param>
        /// <param name="updateSystemFields">Set to true if you want the system fields updated</param>
        /// <param name="updateRichTextFields">Set to true if you want the rich text fields updated</param>
        private void CorrectFieldsByListID(
            Guid listID, IEnumerable<string> richTextFields, bool updateSystemFields, bool updateRichTextFields)
        {
            using (SPSite siteCollection = new SPSite(SiteId))
            {
                bool AllowUnsafeUpdates = siteCollection.AllowUnsafeUpdates;
                try
                {

                    siteCollection.AllowUnsafeUpdates = true;
                    using (SPWeb web = siteCollection.OpenWeb(WebId))
                    {
                        try
                        {
                            adminToken = web.SiteAdministrators[0].UserToken;
                        }
                        catch
                        {
                            adminToken = SPUserToken.SystemAccount;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                    throw ex;
                }
                finally
                {
                    siteCollection.AllowUnsafeUpdates = AllowUnsafeUpdates;
                }
            }

            using (SPSite siteCollection = new SPSite(SiteId, adminToken))
            {
                bool AllowUnsafeUpdates = siteCollection.AllowUnsafeUpdates;
                try
                {
                    siteCollection.AllowUnsafeUpdates = true;
                    using (SPWeb site = siteCollection.OpenWeb(WebId))
                    {
                        currentListID = listID;

                        //Check break permission with this list in BreakPermissionsCollection
                        BreakPermission breakPermission = this.BreakPermissions.GetBreakPermission(site.Lists[listID].Title);

                        SPList thisList = site.Lists[currentListID];
                        if (!thisList.HasUniqueRoleAssignments)
                        {
                            if (breakPermission != null && breakPermission.IsBreak)
                            {
                                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Format("Start Break permission for List [{0}].",
                                                            breakPermission.ListName));
                                BreakPermissionList(site, breakPermission);

                                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "End Break permission for list");
                            }
                        }

                        if (updateRichTextFields && updateSystemFields)
                        {
                            CorrectListItemFields(site, richTextFields, UpdateType.All);
                        }
                        else if (updateRichTextFields)
                        {
                            CorrectListItemFields(site, richTextFields, UpdateType.RichText);
                        }
                        else if (updateSystemFields)
                        {
                            CorrectListItemFields(site, null, UpdateType.SystemFields);
                        }
                        else
                        {
                            Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Only update permission for item.");
                            CorrectListItemFields(site, null, UpdateType.Permission);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                    throw ex;
                }
                finally
                {
                    siteCollection.AllowUnsafeUpdates = AllowUnsafeUpdates;
                }
            }

        }

        /// <summary>
        /// This one is for Transformer tool
        /// </summary>
        /// <param name="listName"></param>
        /// <param name="richTextFields"></param>
        /// <param name="updateSystemFields"></param>
        /// <param name="updateRichTextFields"></param>
        private void CorrectFieldsByListName(
            string listName,
            IEnumerable<string> richTextFields,
            bool updateSystemFields,
            bool updateRichTextFields,
            BreakPermissionCollection breakPermissions)
        {
            this.BreakPermissions = breakPermissions;
            Guid listID = Guid.Empty;

            using (var siteCollection = new SPSite(SiteId))
            {
                bool AllowUnsafeUpdates = siteCollection.AllowUnsafeUpdates;
                try
                {
                    siteCollection.AllowUnsafeUpdates = true;
                    using (SPWeb web = siteCollection.OpenWeb(WebId))
                    {
                        listID = web.Lists[listName].ID;
                    }
                }
                catch (Exception ex)
                {
                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                    throw ex;
                }
                finally
                {
                    siteCollection.AllowUnsafeUpdates = AllowUnsafeUpdates;
                }
            }

            CorrectFieldsByListID(listID, richTextFields, updateSystemFields, updateRichTextFields);
        }

        private void CorrectListItemFields(SPWeb site, IEnumerable<string> richTextFields, UpdateType updateType)
        {
            SPList list = site.Lists[currentListID];

            //Check break permission with items of this list
            FieldPermissionCollection fieldPermissionCollection = null;
            FieldPermissionCollection fieldPermissionCollectionOfThisList = new FieldPermissionCollection();

            //Update Permission for items with Users or Groups
            BreakPermission itemsPermissionOfList = new BreakPermission();
            if (currentTask != null && currentTask.ItemPermissions != null && currentTask.ItemPermissions.Count > 0)
            {
                itemsPermissionOfList = currentTask.ItemPermissions.GetBreakPermission(list.Title);
            }

            if (currentTask != null && currentTask.FieldPermissions != null && currentTask.FieldPermissions.Count > 0)
            {
                fieldPermissionCollection = currentTask.FieldPermissions.Get(list.Title);
            }

            if (fieldPermissionCollection != null && fieldPermissionCollection.Count > 0)
            {
                //Get all fieldPermission of this list
                foreach (FieldPermission fieldPermission in fieldPermissionCollection)
                {
                    if (fieldPermission.ListName == list.Title)
                    {
                        fieldPermissionCollectionOfThisList.Add(fieldPermission);
                    }
                }
            }

            switch (updateType)
            {
                case UpdateType.All:
                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Updating Permissions, Rich Text and System Fields...");
                    break;
                case UpdateType.SystemFields:
                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Updating System Field...");
                    break;
                case UpdateType.RichText:
                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Updating Rich Text...");
                    break;
                case UpdateType.Permission:
                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Updating permission...");
                    break;
                default:
                    return;
            }

            string folderurl = string.Empty;
            SPQuery query = new SPQuery();
            query.RowLimit = (uint)BatchUpdateSize;
            query.Query = "<Where></Where>";

            string queryViewAttribute = string.Empty;

            if (list.BaseTemplate == SPListTemplateType.DiscussionBoard)
                queryViewAttribute = "Scope='RecursiveAll'";
            else
                queryViewAttribute = "Scope='Recursive'";

            query.ViewAttributes = queryViewAttribute;

            TotalItems = list.Items.Count;

            //Update status
            UpdateStatus(site, TotalItems, PostProcessedItems);

            SPListItemCollection allItems;
            try
            {
                do
                {
                    IList<SPListItem> unprocessedItems = new List<SPListItem>();

                    //for item permission
                    IList<SPListItem> itemsPermission = new List<SPListItem>();
                    allItems = list.GetItems(query);
                    foreach (SPListItem item in allItems)
                    {
                        //Check post-processed status: Compare value of field [SystemFields.ALL_UPDATED] ??
                        if (updateType == UpdateType.All)
                        {
                            if (IsRePostProcess
                                || item[Constant.SystemFields.RICHTEXT_FIELDS_UPDATED].ToString().Equals("False")
                                || item[Constant.SystemFields.SYSTEM_FIELDS_UPDATED].ToString().Equals("False"))
                            {
                                unprocessedItems.Add(item);
                            }
                        }
                        else if (updateType == UpdateType.RichText)
                        {
                            if (IsRePostProcess || item[Constant.SystemFields.RICHTEXT_FIELDS_UPDATED].ToString().Equals("False"))
                            {
                                unprocessedItems.Add(item);
                            }
                        }
                        else if (updateType == UpdateType.SystemFields)
                        {
                            if (IsRePostProcess || item[Constant.SystemFields.SYSTEM_FIELDS_UPDATED].ToString().Equals("False"))
                            {
                                unprocessedItems.Add(item);
                            }
                        }

                    }
                    if (unprocessedItems.Count > 0)
                    {
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Start update rich text and system fiels");
                        UpdateItems(site, unprocessedItems, updateType, richTextFields, folderurl, new FieldPermissionCollection(), new BreakPermission());
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "End update rich text and system fiels");
                    }

                    //for item permission, with user and group in field
                    if (fieldPermissionCollectionOfThisList.Count > 0
                        || (itemsPermissionOfList != null && itemsPermissionOfList.Permissions.Count > 0))
                    {
                        foreach (SPListItem item in allItems)
                        {
                            SPQuery queryItem = new SPQuery();
                            queryItem.Query = string.Format("<Where><Eq><FieldRef Name ='ID'/><Value Type='Counter'>{0}</Value></Eq></Where>", item.ID);
                            queryItem.ViewAttributes = queryViewAttribute;
                            SPListItemCollection itemCollection = list.GetItems(queryItem);
                            if (itemCollection.Count > 0)
                                itemsPermission.Add(itemCollection[0]);
                        }

                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Start update permission.");
                        UpdateItems(site, itemsPermission, UpdateType.Permission, null, folderurl, fieldPermissionCollectionOfThisList, itemsPermissionOfList);
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "End update permission");
                    }

                    //Update PostProcessed count
                    PostProcessedItems += unprocessedItems.Count;
                    //Update status
                    UpdateStatus(site, TotalItems, PostProcessedItems);

                    if (allItems.ListItemCollectionPosition != null)
                        query.ListItemCollectionPosition = allItems.ListItemCollectionPosition;

                    unprocessedItems.Clear();
                    itemsPermission.Clear();
                } while (allItems.ListItemCollectionPosition != null);
            }
            catch (Exception ex)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "CorrectListItemFields:CustomList: " + ex.Message + " --- Trace : " + ex.StackTrace);
                throw ex;
            }
        }

        private void UpdateItems(SPWeb site,
            IList<SPListItem> unprocessedItems,
            UpdateType updateFields,
            IEnumerable<string> richTextFields,
            string folderurl, FieldPermissionCollection
            fieldPermissionCollectionOfThisList,
            BreakPermission itemsPermission)
        {
            #region Update richtext and system field

            try
            {
                foreach (SPListItem listItem in unprocessedItems)
                {
                    try
                    {
                        //if (cancelPending) return;

                        switch (updateFields)
                        {
                            case UpdateType.All:
                                CorrectListItemRichTextFields(site, listItem, richTextFields, string.Empty);
                                CorrectListItemSystemFields(site, listItem, Constant.SystemFields.ALL_UPDATED);
                                break;
                            case UpdateType.RichText:
                                CorrectListItemRichTextFields(site, listItem, richTextFields,
                                                              Constant.SystemFields.RICHTEXT_FIELDS_UPDATED);
                                break;
                            case UpdateType.SystemFields:
                                CorrectListItemSystemFields(site, listItem, Constant.SystemFields.SYSTEM_FIELDS_UPDATED);
                                break;
                            case UpdateType.Permission:
                                UpdatePermissionsForUserOrGroupInField(site, listItem, fieldPermissionCollectionOfThisList, itemsPermission);
                                break;
                            default:
                                return;
                        }
                    }
                    catch (Exception exception)
                    {
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Error when postprocess: Message \r\n" + exception.Message + "\r\n Trace:" + exception.StackTrace);
                    }

                }
            }
            catch (Exception ex)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "UpdateItems: \r\n Message: \r\n" + ex.Message + " \r\n Trace : \r\n" + ex.StackTrace);
            }
            try
            {
                RunBatchUpdate(site, folderurl);
            }
            catch (Exception exception)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Postprocess error when run batch update: " + exception.InnerException + " RunBatchUpdate(site, folderurl);");
            }

            #endregion
        }

        private void CorrectListItemSystemFields(SPWeb site, SPListItem listItem, string processedFieldName)
        {
            //if (cancelPending)
            //{
            //    return;
            //}

            Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Format("Updating system fields for list item: {0}", listItem.ID));
            Dictionary<string, FieldDefinition> fields = new Dictionary<string, FieldDefinition>();

            //Created field
            FieldDefinition createdField = new FieldDefinition();
            createdField.Value = listItem.GetFieldValue(Constant.SystemFields.CITUS_CREATED);
            createdField.DestinationColumn = Constant.SystemFields.CREATED;
            fields.Add(createdField.DestinationColumn, createdField);

            //Author field
            FieldDefinition createdByField = new FieldDefinition();
            createdByField.Value = listItem.GetFieldValue(Constant.SystemFields.CITUS_CREATED_BY);
            createdByField.DestinationColumn = Constant.SystemFields.CREATED_BY;
            fields.Add(createdByField.DestinationColumn, createdByField);

            //Modified field
            FieldDefinition modifiedField = new FieldDefinition();
            modifiedField.Value = listItem.GetFieldValue(Constant.SystemFields.CITUS_MODIFIED);
            modifiedField.DestinationColumn = Constant.SystemFields.MODIFIED;
            fields.Add(modifiedField.DestinationColumn, modifiedField);

            //Editor field
            FieldDefinition modifiedByField = new FieldDefinition();
            modifiedByField.Value = listItem.GetFieldValue(Constant.SystemFields.CITUS_MODIFIED_BY);
            modifiedByField.DestinationColumn = Constant.SystemFields.MODIFIED_BY;
            fields.Add(modifiedByField.DestinationColumn, modifiedByField);

            BuildBatchUpdate(listItem, fields, processedFieldName);

            fields.Clear();

        }

        private void CorrectListItemRichTextFields(SPWeb site, SPListItem listItem, IEnumerable<string> richTextFields, string processedFieldName)
        {
            Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Format("Updating rich text fields for list item: {0}", listItem.ID));

            List<FieldDefinition> richTextFieldDefinitions = new List<FieldDefinition>();

            foreach (string field in richTextFields)
            {

                FieldDefinition richTextField = new FieldDefinition();
                richTextField.DestinationColumn = field;
                richTextField.Value = listItem.GetFieldValue(field);
                richTextFieldDefinitions.Add(richTextField);
            }


            bool resuiltOk = false;

            Dictionary<string, FieldDefinition> fields = new Dictionary<string, FieldDefinition>();
            foreach (FieldDefinition field in richTextFieldDefinitions)
            {
                if (string.IsNullOrEmpty(field.Value))
                { continue; }

                string retData;
                resuiltOk = UpdateRichText(listItem, field.Value, out retData);
                if (resuiltOk)
                {
                    field.Value = retData;
                    fields.Add(field.DestinationColumn, field);
                }
            }

            BuildBatchUpdate(listItem, fields, processedFieldName);

            fields.Clear();

        }

        #endregion

        #region Batch Update

        private void AddFieldToBatch(int listItemID, string fieldName, string fieldValue)
        {
            if (!batchData.ContainsKey(listItemID))
            {
                batchData.Add(listItemID, new List<string>());
            }
            batchData[listItemID].Add(string.Format(
                fieldFormat,
                fieldName,
                fieldValue));
        }

        /// <summary>
        /// Add the specified updates to the batch update buffer
        /// </summary>
        /// <param name="site"></param>
        /// <param name="listItem"></param>
        /// <param name="listID"></param>
        /// <param name="fields"></param>
        private void BuildBatchUpdate(
            SPListItem listItem,
            IDictionary<string, FieldDefinition> fields,
            string processedFieldName)
        {
            if (fields != null)
            {
                //Don't run this code, but still run processed column code (Permissions update only needs processed column update)
                foreach (KeyValuePair<string, FieldDefinition> entry in fields)
                {
                    if (string.IsNullOrEmpty(entry.Value.Value))
                    { continue; }

                    if (IsSystemField(entry.Value.DestinationColumn))
                    {
                        #region Created / Modified

                        if (entry.Value.DestinationColumn.In(Constant.SystemFields.CREATED,
                                                             Constant.SystemFields.MODIFIED))
                        {
                            DateTime date = DateTime.Parse(entry.Value.Value, CultureInfo.CurrentCulture);

                            //We want to make sure Modified fields go last in update, so keep separate
                            if (entry.Value.DestinationColumn == Constant.SystemFields.MODIFIED)
                            {
                                AddFieldToBatch(
                                    listItem.ID,
                                    listItem.Fields[entry.Value.DestinationColumn].InternalName,
                                    SPUtility.CreateISO8601DateTimeFromSystemDateTime(date));

                                //Extra (for Discussions)
                                if (listItem.ContentType.Name.Equals("Discussion"))
                                {

                                    try
                                    {
                                        SPQuery query = new SPQuery();
                                        query.ViewAttributes = "Scope='Recursive'";
                                        query.ViewFields = "<FieldRef Name=\"" + Constant.SystemFields.CITUS_CREATED +
                                                           "\"/>";
                                        StringBuilder queryString = new StringBuilder();
                                        queryString.Append("<Where>");
                                        queryString.Append("     <And>");
                                        queryString.Append("         <Eq>");
                                        queryString.Append("            <FieldRef Name=\"ContentType\" />");
                                        queryString.Append("            <Value Type=\"Text\">Message</Value>");
                                        queryString.Append("         </Eq>");
                                        queryString.Append("         <Eq>");
                                        queryString.Append("            <FieldRef Name=\"ParentFolderId\" />");
                                        queryString.Append("            <Value Type=\"Number\">" + listItem.ID + "</Value>");
                                        queryString.Append("         </Eq>");
                                        queryString.Append("     </And>");
                                        queryString.Append("</Where>");
                                        query.Query = queryString.ToString();
                                        SPListItemCollection replies = listItem.ParentList.GetItems(query);

                                        SPListItem reply = replies.Cast<SPListItem>().OrderBy(
                                                a =>
                                                Convert.ToDateTime(a[Constant.SystemFields.CITUS_CREATED].ToString())).
                                                LastOrDefault();

                                        if (reply != null && reply[Constant.SystemFields.CITUS_CREATED] != null)
                                        {
                                            DateTime lastDate =
                                                DateTime.Parse(reply[Constant.SystemFields.CITUS_CREATED].ToString(),
                                                               CultureInfo.CurrentCulture);
                                            if (lastDate != DateTime.MinValue)
                                            {
                                                AddFieldToBatch(
                                                    listItem.ID,
                                                    listItem.Fields[Constant.SystemFields.LAST_UPDATED].InternalName,
                                                    SPUtility.CreateISO8601DateTimeFromSystemDateTime(lastDate));
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                                    }

                                }

                            }
                            else
                            {
                                if (listItem.ContentType.Name.Equals("Discussion"))
                                {
                                    try
                                    {
                                        SPQuery query = new SPQuery();
                                        query.ViewAttributes = "Scope='Recursive'";
                                        query.ViewFields = "<FieldRef Name=\"" + Constant.SystemFields.CITUS_CREATED +
                                                           "\"/>";
                                        StringBuilder queryString = new StringBuilder();
                                        queryString.Append("<Where>");
                                        queryString.Append("     <And>");
                                        queryString.Append("         <Eq>");
                                        queryString.Append("            <FieldRef Name=\"ContentType\" />");
                                        queryString.Append("            <Value Type=\"Text\">Message</Value>");
                                        queryString.Append("         </Eq>");
                                        queryString.Append("         <Eq>");
                                        queryString.Append("            <FieldRef Name=\"ParentFolderId\" />");
                                        queryString.Append("            <Value Type=\"Number\">" + listItem.ID + "</Value>");
                                        queryString.Append("         </Eq>");
                                        queryString.Append("     </And>");
                                        queryString.Append("</Where>");
                                        query.Query = queryString.ToString();
                                        SPListItemCollection replies = listItem.ParentList.GetItems(query);

                                        if (replies.Count == 0)
                                        {
                                            AddFieldToBatch(
                                                    listItem.ID,
                                                    listItem.Fields[Constant.SystemFields.LAST_UPDATED].InternalName,
                                                    SPUtility.CreateISO8601DateTimeFromSystemDateTime(date));
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                                    }

                                }
                                AddFieldToBatch(
                                    listItem.ID,
                                    listItem.Fields[entry.Value.DestinationColumn].InternalName,
                                    SPUtility.CreateISO8601DateTimeFromSystemDateTime(date));
                            }
                        }

                        #endregion

                        #region Created By / Modified By

                        else if (entry.Value.DestinationColumn.In(Constant.SystemFields.CREATED_BY,
                                                                  Constant.SystemFields.MODIFIED_BY))
                        {
                            bool AllowUnsafeUpdates = listItem.Web.AllowUnsafeUpdates;
                            try
                            {
                                //TODO: Change this to get from temp user column
                                listItem.Web.AllowUnsafeUpdates = true;
                                SPUser user = (SPUser)EnsureUserGroup(listItem.Web, entry.Value.Value);
                                if (user != null)
                                {
                                    int id = user.ID;
                                    string displayName = user.Name;

                                    if (entry.Value.DestinationColumn == Constant.SystemFields.MODIFIED_BY)
                                    {
                                        AddFieldToBatch(
                                            listItem.ID,
                                            Constant.SystemFields.EDITOR,
                                            string.Concat(id, ";#", displayName));
                                    }
                                    else
                                    {
                                        AddFieldToBatch(
                                            listItem.ID,
                                            listItem.Fields[entry.Value.DestinationColumn].InternalName,
                                            string.Concat(id, ";#", displayName));
                                    }
                                }
                            }
                            catch (Exception x)
                            {
                                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, x.InnerException.ToString());
                                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Could not create users: " + entry.Value.Value);
                            }
                            finally
                            {
                                listItem.Web.AllowUnsafeUpdates = AllowUnsafeUpdates;
                            }
                        }
                        #endregion
                    }
                    else
                    {
                        AddFieldToBatch(listItem.ID, entry.Value.DestinationColumn, entry.Value.Value.HtmlEncode());
                    }
                }
            }

            //Update field processed
            if (!string.IsNullOrEmpty(processedFieldName))
            {
                AddFieldToBatch(listItem.ID, processedFieldName, "1");

                if (Constant.SystemFields.ALL_UPDATED.Equals(processedFieldName))
                {
                    AddFieldToBatch(listItem.ID, Constant.SystemFields.RICHTEXT_FIELDS_UPDATED, "1");
                    AddFieldToBatch(listItem.ID, Constant.SystemFields.SYSTEM_FIELDS_UPDATED, "1");
                }
            }
        }

        private bool IsSystemField(string destinationColumn)
        {
            return !string.IsNullOrEmpty(destinationColumn) && (destinationColumn.Equals(Constant.SystemFields.CREATED_BY)
                    || destinationColumn.Equals(Constant.SystemFields.MODIFIED_BY)
                    || destinationColumn.Equals(Constant.SystemFields.CREATED)
                    || destinationColumn.Equals(Constant.SystemFields.MODIFIED));
        }

        /// <summary>
        /// Run a batch update.
        /// </summary>
        /// <param name="site"></param>
        private void RunBatchUpdate(SPWeb site, string folderPath)
        {
            // Put the pieces together.
            //Debugger.Break();
            StringBuilder methodBuilder = new StringBuilder();
            StringBuilder fieldBuilder = null;
            foreach (KeyValuePair<int, List<string>> kv in batchData)
            {
                fieldBuilder = new StringBuilder();
                foreach (string field in kv.Value)
                {
                    fieldBuilder.Append(field);
                    fieldBuilder.Append(Environment.NewLine);
                }
                methodBuilder.AppendFormat(methodFormat, methodID++, currentListID, kv.Key, fieldBuilder.ToString());
                methodBuilder.Append(Environment.NewLine);
            }

            string batch = string.Format(batchFormat, folderPath, methodBuilder.ToString());

            SPSecurity.RunWithElevatedPrivileges(
                delegate
                {
                    WindowsImpersonationContext impersonationContext;
                    string result = string.Empty;
                    bool AllowUnsafeUpdates = site.AllowUnsafeUpdates;
                    try
                    {
                        impersonationContext = WindowsIdentity.GetCurrent().Impersonate();
                        site.AllowUnsafeUpdates = true;
                        result = site.ProcessBatchData(batch);
                        impersonationContext.Undo();
                    }
                    catch (Exception ex)
                    {
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                    }
                    finally
                    {
                        site.AllowUnsafeUpdates = AllowUnsafeUpdates;
                    }

                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Format("Update data result of batch:\r\n{0}", result));

                });

            batchData.Clear();
        }

        #endregion

        #region Security / Permissions

        //for break permission of list
        private void BreakPermissionList(SPWeb site, BreakPermission breakPermission)
        {
            SPSecurity.RunWithElevatedPrivileges(
                delegate
                {
                    WindowsImpersonationContext impersonationContext;
                    string result = string.Empty;
                    bool AllowUnsafeUpdates = site.AllowUnsafeUpdates;
                    try
                    {
                        impersonationContext = WindowsIdentity.GetCurrent().Impersonate();

                        string listName = breakPermission.ListName;
                        SPList thisList = null;
                        try
                        {
                            thisList = site.Lists[listName];
                            thisList.BreakRoleInheritance(false, true);
                        }
                        catch (Exception exception)
                        {
                            string message = string.Concat(
                                        string.Format(Constant.Message.ERROR_BREAKPERMISSIONS_LIST, listName,
                                                      exception.Message),
                                        Environment.NewLine,
                                        string.Format(Constant.Message.ERROR_GENERIC_EXCEPTION_FORMAT,
                                                      exception.Message));

                            Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, message);

                        }

                        List<string> users = new List<string>();
                        List<string> groups = new List<string>();

                        foreach (Permissions permissions in breakPermission.Permissions)
                        {
                            if (!permissions.IsGroup)
                            {
                                users.Add(permissions.UserOrGroupName);
                            }
                            else
                            {
                                groups.Add(permissions.UserOrGroupName);
                            }
                        }

                        #region permissions of user

                        if (users.Count > 0)
                        {
                            foreach (string user in users)
                            {
                                try
                                {
                                    SPUser spUser = site.EnsureUser(user);
                                    List<SPRoleDefinition> roleDefinitions = new List<SPRoleDefinition>();
                                    foreach (Permissions permissions in breakPermission.Permissions)
                                    {
                                        if (user.Equals(permissions.UserOrGroupName))
                                        {
                                            foreach (string per in permissions.Permission)
                                            {
                                                SPRoleDefinition roleDef = site.RoleDefinitions[per];
                                                roleDefinitions.Add(roleDef);
                                            }
                                        }
                                    }
                                    roleDefinitions = roleDefinitions.Distinct().ToList();
                                    SPRoleAssignment roleAssignment = new SPRoleAssignment(spUser);
                                    foreach (SPRoleDefinition roleDefinition in roleDefinitions)
                                    {
                                        roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                    }
                                    thisList.RoleAssignments.Add(roleAssignment);
                                    thisList.Update();
                                }
                                catch (Exception exception)
                                {
                                    string message = string.Concat(
                                        string.Format(Constant.Message.ERROR_BREAKPERMISSIONS_LIST, listName,
                                                      exception.Message),
                                        Environment.NewLine,
                                        string.Format(Constant.Message.ERROR_GENERIC_EXCEPTION_FORMAT,
                                                      exception.Message));

                                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, message);

                                }

                            }
                        }

                        #endregion

                        #region permissions of Group

                        if (groups.Count > 0)
                        {
                            foreach (string group in groups)
                            {
                                try
                                {
                                    SPGroup spGroup = site.Groups[group];

                                    List<SPRoleDefinition> roleDefinitions = new List<SPRoleDefinition>();
                                    foreach (Permissions permissions in breakPermission.Permissions)
                                    {
                                        if (group.Equals(permissions.UserOrGroupName))
                                            foreach (string per in permissions.Permission)
                                            {
                                                SPRoleDefinition roleDef = site.RoleDefinitions[per];
                                                roleDefinitions.Add(roleDef);
                                            }
                                    }
                                    roleDefinitions = roleDefinitions.Distinct().ToList();
                                    SPRoleAssignment roleAssignment = new SPRoleAssignment(spGroup);
                                    foreach (SPRoleDefinition roleDefinition in roleDefinitions)
                                    {
                                        roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                    }

                                    thisList.RoleAssignments.Add(roleAssignment);
                                    thisList.Update();
                                }
                                catch (Exception exception)
                                {
                                    string message = string.Concat(
                                        string.Format(Constant.Message.ERROR_BREAKPERMISSIONS_LIST, listName,
                                                      exception.Message),
                                        Environment.NewLine,
                                        string.Format(Constant.Message.ERROR_GENERIC_EXCEPTION_FORMAT,
                                                      exception.Message));

                                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, message);

                                }

                            }
                        }

                        #endregion

                        impersonationContext.Undo();
                    }
                    catch (Exception ex)
                    {
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                    }
                    finally
                    {
                        site.AllowUnsafeUpdates = AllowUnsafeUpdates;
                    }

                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Format("Update data result of batch:\r\n{0}", result));

                });


        }

        //for update permission of user or group in fields and in object chosen from post-process setting
        private void UpdatePermissionsForUserOrGroupInField(SPWeb site,
            SPListItem item,
            FieldPermissionCollection fieldPermissionCollection,
            BreakPermission itemsPermissionOfList
            )
        {
            SPSecurity.RunWithElevatedPrivileges(

                delegate
                {
                    WindowsImpersonationContext impersonationContext = WindowsIdentity.GetCurrent().Impersonate();


                    if (fieldPermissionCollection.Count <= 0 && itemsPermissionOfList.Permissions.Count <= 0)
                        return;

                    string fieldname = string.Empty;
                    string unid = string.Empty;

                    try
                    {
                        item.ResetRoleInheritance();
                        item.BreakRoleInheritance(false, true);
                        for (int i = 0; i < item.RoleAssignments.Count; i++)
                        {
                            item.RoleAssignments.Remove(i);
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());

                    }

                    bool allowUnsafeUpdatesStatus = site.AllowUnsafeUpdates;
                    try
                    {
                        site.AllowUnsafeUpdates = true;

                        #region For fields

                        if (fieldPermissionCollection.Count > 0)
                        {
                            try
                            {
                                foreach (FieldPermission fieldPermission in fieldPermissionCollection)
                                {
                                    fieldname = fieldPermission.FieldName;
                                    string[] usersOrGroupsInField = new string[0];
                                    List<SPUser> isUsers = new List<SPUser>();
                                    List<SPGroup> isGroups = new List<SPGroup>();

                                    try
                                    {
                                        if (item[fieldname] != null)
                                            usersOrGroupsInField = item[fieldPermission.FieldName].ToString().Split(
                                                new[] { Constant.General.MULTI_VALUE_SEPARATOR },
                                                StringSplitOptions.RemoveEmptyEntries);

                                        if (item[Constant.SystemFields.UNID] != null)
                                            unid = item[Constant.SystemFields.UNID].ToString();

                                    }
                                    catch (Exception ex)
                                    {
                                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                                        continue;
                                    }

                                    if (usersOrGroupsInField.Length > 0)
                                    {
                                        foreach (string userOrGroup in usersOrGroupsInField)
                                        {
                                            #region Get user or group in SharePoint site with corresponding username

                                            try
                                            {
                                                object temUser = EnsureUserGroup(site, userOrGroup);

                                                if (temUser != null)
                                                {
                                                    if (temUser.GetType() == typeof(SPUser))
                                                    {
                                                        isUsers.Add((SPUser)temUser);
                                                    }
                                                    else if (temUser.GetType() == typeof(SPGroup))
                                                    {
                                                        isGroups.Add((SPGroup)temUser);
                                                    }
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                string message =
                                                    string.Format(
                                                        "Error when update permission for users or groups in field {0} of Item [{1}], User or group [{2}] not found",
                                                        fieldname, unid, userOrGroup);
                                                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, message);
                                            }

                                            #endregion
                                        }
                                    }

                                    for (int i = 0; i < isUsers.Count; i++)
                                    {
                                        AddUserToItems(site, item, isUsers[i], fieldPermission);
                                    }
                                    for (int i = 0; i < isGroups.Count; i++)
                                    {
                                        AddUserToItems(site, item, isGroups[i], fieldPermission);

                                    }
                                }
                                item.SystemUpdate(false);

                            }
                            catch (Exception exception)
                            {
                                string message =
                                    string.Format(
                                        "Error when update permission for users or groups in field {0} of Item {1}",
                                        fieldname,
                                        item.ID);
                                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, message);
                                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium,
                                                 exception.InnerException.ToString());
                            }
                        }

                        #endregion

                        #region For ItemsPermission

                        //Update permission for Users or groups to items
                        if (itemsPermissionOfList.Permissions.Count > 0)
                        {
                            try
                            {
                                //TraceService.Service.Trace("Start update permission of Users and Groups to Item.");
                                //Logger.WriteLog("Start update permission of Users and Groups to Item.");

                                AddUserToItemsForUserOrGroup(site, item, itemsPermissionOfList);

                                //TraceService.Service.Trace("End of update permission of Users and Groups to Item.");
                                //Logger.WriteLog("End of update permission of Users and Groups to Item.");

                            }
                            catch (Exception exception)
                            {
                                string message =
                                    string.Format(
                                        "Error when update permission for users or groups to Item [{0}], detail: {1}",
                                        item.ID,
                                        exception.Message);
                                //TraceService.Service.Trace(message);
                                //Logger.WriteLog(message, exception);
                            }
                        }

                        #endregion
                    }
                    catch (Exception exception)
                    {
                        string message =
                                    string.Format(
                                        "Error when update permission for users or groups to Item [{0}], detail: {1}",
                                        item.ID,
                                        exception.Message);
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, message);
                    }
                    finally
                    {
                        site.AllowUnsafeUpdates = allowUnsafeUpdatesStatus;
                    }

                    impersonationContext.Undo();
                });

        }

        //for update users and groups to items from ItemsPermission
        private void AddUserToItemsForUserOrGroup(SPWeb site, SPListItem item, BreakPermission itemsPermissionOfList)
        {
            List<string> users = new List<string>();
            List<string> groups = new List<string>();

            foreach (Permissions permissions in itemsPermissionOfList.Permissions)
            {
                if (!permissions.IsGroup)
                {
                    users.Add(permissions.UserOrGroupName);
                }
                else
                {
                    groups.Add(permissions.UserOrGroupName);
                }
            }

            #region permissions of user

            if (users.Count > 0)
            {
                foreach (string user in users)
                {
                    try
                    {
                        SPUser spUser = site.EnsureUser(user);
                        List<SPRoleDefinition> roleDefinitions = new List<SPRoleDefinition>();
                        foreach (Permissions permissions in itemsPermissionOfList.Permissions)
                        {
                            if (user.Equals(permissions.UserOrGroupName))
                            {
                                foreach (string per in permissions.Permission)
                                {
                                    SPRoleDefinition roleDef = site.RoleDefinitions[per];
                                    roleDefinitions.Add(roleDef);
                                }
                            }
                        }
                        roleDefinitions = roleDefinitions.Distinct().ToList();
                        SPRoleAssignment roleAssignment = new SPRoleAssignment(spUser);
                        foreach (SPRoleDefinition roleDefinition in roleDefinitions)
                        {
                            roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                        }
                        item.RoleAssignments.Add(roleAssignment);
                        item.SystemUpdate(false);
                    }
                    catch (Exception exception)
                    {
                        string message = string.Concat(
                            string.Format(Constant.Message.ERROR_BREAKPERMISSIONS_ITEM, item.ID,
                                          item.ParentList.Title, user,
                                          exception.Message));

                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, message);
                    }

                }
            }

            #endregion

            #region permissions of Group

            if (groups.Count > 0)
            {
                foreach (string group in groups)
                {
                    try
                    {
                        SPGroup spGroup = site.Groups[group];

                        List<SPRoleDefinition> roleDefinitions = new List<SPRoleDefinition>();
                        foreach (Permissions permissions in itemsPermissionOfList.Permissions)
                        {
                            if (group.Equals(permissions.UserOrGroupName))
                                foreach (string per in permissions.Permission)
                                {
                                    SPRoleDefinition roleDef = site.RoleDefinitions[per];
                                    roleDefinitions.Add(roleDef);
                                }
                        }
                        roleDefinitions = roleDefinitions.Distinct().ToList();
                        SPRoleAssignment roleAssignment = new SPRoleAssignment(spGroup);
                        foreach (SPRoleDefinition roleDefinition in roleDefinitions)
                        {
                            roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                        }

                        item.RoleAssignments.Add(roleAssignment);
                        item.SystemUpdate(false);
                    }
                    catch (Exception exception)
                    {
                        string message = string.Concat(
                            string.Format(Constant.Message.ERROR_BREAKPERMISSIONS_ITEM, item.ID,
                                          item.ParentList.Title, group,
                                          exception.Message));

                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, message);
                    }

                }
            }

            #endregion
        }

        //for add user or group with permissions of them to Items
        private void AddUserToItems(SPWeb site, SPListItem item, Object userGroup, FieldPermission listPermission)
        {
            List<SPRoleDefinition> roleDefinitions = new List<SPRoleDefinition>();
            foreach (string permissions in listPermission.Permissions)
            {
                try
                {
                    SPRoleDefinition roleDef = site.RoleDefinitions[permissions];
                    roleDefinitions.Add(roleDef);
                }
                catch (Exception ex)
                {
                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                }
            }
            roleDefinitions = roleDefinitions.Distinct().ToList();

            SPRoleAssignment roleAssignment = null;

            if (userGroup.GetType() == typeof(SPUser))
                roleAssignment = new SPRoleAssignment((SPUser)userGroup);
            else
                roleAssignment = new SPRoleAssignment((SPGroup)userGroup);

            foreach (SPRoleDefinition roleDefinition in roleDefinitions)
            {
                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);

            }
            item.RoleAssignments.Add(roleAssignment);
        }

        #endregion

        #region Update Links

        private bool UpdateRichText(SPListItem listItem, string richText, out string retData)
        {
            string temp = richText;

            List<string> matchValues;
            if (!string.IsNullOrEmpty(temp))
            {
                if (Regex.IsMatch(temp, Constant.RichText.DOC_LINK_PATTERN, RegexOptions.IgnoreCase))
                {
                    matchValues = new List<string>();
                    foreach (Match match in Regex.Matches(temp, Constant.RichText.DOC_LINK_PATTERN, RegexOptions.IgnoreCase))
                    {
                        matchValues.Add(match.Value);
                    }
                    if (currentTask.DocumentMappings != null)
                    {
                        temp = UpdateDocLinks(listItem, temp, matchValues);
                    }
                }
                if (Regex.IsMatch(temp, Constant.RichText.VIEW_LINK_PATTERN, RegexOptions.IgnoreCase))
                {
                    matchValues = new List<string>();
                    foreach (Match match in Regex.Matches(temp, Constant.RichText.VIEW_LINK_PATTERN, RegexOptions.IgnoreCase))
                    {
                        matchValues.Add(match.Value);
                    }
                    if (currentTask.ViewMappings != null)
                    {
                        temp = UpdateViewLinks(temp, matchValues);
                    }
                }
                if (Regex.IsMatch(temp, Constant.RichText.DB_LINK_PATTERN, RegexOptions.IgnoreCase))
                {
                    matchValues = new List<string>();
                    foreach (Match match in Regex.Matches(temp, Constant.RichText.DB_LINK_PATTERN, RegexOptions.IgnoreCase))
                    {
                        matchValues.Add(match.Value);
                    }
                    if (currentTask.DatabaseMappings != null)
                    {
                        temp = UpdateDatabaseLinks(temp, matchValues);
                    }
                }

                if (Regex.IsMatch(temp, Constant.RichText.ATTACHMENT_LINK_PATTERN, RegexOptions.IgnoreCase))
                {
                    matchValues = new List<string>();
                    foreach (Match match in Regex.Matches(temp, Constant.RichText.ATTACHMENT_LINK_PATTERN, RegexOptions.IgnoreCase))
                    {
                        matchValues.Add(match.Value);
                    }
                    temp = UpdateAttachmentLinks(listItem, temp, matchValues);
                }
            }

            if (string.Compare(richText, temp, false) != 0)
            {
                retData = temp;
                return true;
            }
            retData = string.Empty;
            return false;
        }

        private string UpdateAttachmentLinks(SPListItem listItem, string richText, IEnumerable<string> matches)
        {
            for (int i = 0; i < matches.Count(); i++)
            {
                Uri url = new Uri(listItem.Attachments.UrlPrefix);
                string replaceText = url.AbsolutePath;
                richText = Regex.Replace(richText, Constant.RichText.ATTACHMENT_LINK_PATTERN, replaceText, RegexOptions.IgnoreCase);
                url = null;
            }

            return richText;
        }
        private string UpdateDatabaseLinks(string richText, IEnumerable<string> matches)
        {
            string replaceText = string.Empty;
            string pattern = @"}/\w{16}";
            foreach (string match in matches)
            {
                string databaseID = Regex.Match(match, pattern).Value.Substring(2);
                if (currentTask.DatabaseMappings.ContainsKey(databaseID))
                {
                    replaceText = currentTask.DatabaseMappings[databaseID];
                    richText = Regex.Replace(richText, match, replaceText, RegexOptions.IgnoreCase);
                }
            }
            return richText;
        }
        private string UpdateDocLinks(SPListItem listItem, string richText, IEnumerable<string> matches)
        {

            string pattern = @"\w{32};\w{16}";
            string replaceText = string.Empty;
            bool isInternalLink = false;
            bool isDocLinkFound = true;
            Guid mappingAppGuid = Guid.NewGuid();

            foreach (string match in matches)
            {
                string result = Regex.Match(match, pattern).Value;
                string[] split = result.Split(';');
                string unid = split[0];
                string dbid = split[1];

                if (dbid.Contains("#"))
                    dbid = dbid.Substring(0, dbid.IndexOf("#"));

                Uri internalUri = null;
                Uri mappingUri = null;
                IPAddress internalIP;

                SPQuery query = new SPQuery();
                query.ViewFields = "<FieldRef Name=\"" + Constant.SystemFields.UNID + "\"/>";
                query.Query = string.Format(
                    @"<Where>
                        <Eq>
                            <FieldRef Name=""{0}""/>
                            <Value Type=""Text"">{1}</Value>
                        </Eq>
                    </Where>", Constant.SystemFields.UNID, unid);

                query.ViewAttributes = "Scope='RecursiveAll'";

                SPSite siteCollection = null;
                string mappingUrl = string.Empty;
                if (Regex.IsMatch(dbid, @"[0]{16}"))
                {
                    siteCollection = listItem.Web.Site;
                    mappingUrl = listItem.Web.Url;
                    isInternalLink = true;
                }
                else
                {
                    if (currentTask.DocumentMappings.Count == 0)
                    {
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "No database mappings supplied!");
                        return richText;
                    }
                    if (currentTask.DocumentMappings.ContainsKey(result))
                    {
                        isDocLinkFound = true;
                        try
                        {
                            mappingUrl = currentTask.DocumentMappings[result].TrimEnd('/').ToLower();
                            internalUri = new Uri(listItem.Web.Url);
                            IPAddress.TryParse(internalUri.Host, out internalIP);

                            mappingUri = BuildMappingUri(internalUri, mappingUrl);
                            if (mappingUri == null)
                                isInternalLink = true;

                            else
                            {
                                try
                                {
                                    using (SPSite spSite = new SPSite(mappingUri.ToString()))
                                    {
                                        using (SPWeb web = spSite.OpenWeb())
                                        {
                                            mappingAppGuid = web.ID;
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Does not exist SharePoint Site or Web: " + ex.InnerException.ToString());
                                }
                                if (mappingAppGuid.Equals(listItem.Web.ID))
                                {
                                    isInternalLink = true;

                                }
                                else
                                {
                                    isInternalLink = false;
                                }
                            }
                        }
                        catch (Exception x)
                        {
                            Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Concat("Could not connect to site: ", currentTask.DatabaseMappings[dbid]));

                        }
                    }
                    else
                    {
                        isDocLinkFound = false;
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Could not find a matching URL in database mappings list!");
                    }
                }

                if (isInternalLink && isDocLinkFound)
                {

                    mappingUrl = internalUri.AbsoluteUri;
                    siteCollection = new SPSite(mappingUrl);

                    mappingUrl = GeneralUtils.GetSPWebName(mappingUrl);

                    using (SPWeb site = siteCollection.OpenWeb(mappingUrl, true))
                    {
                        SPList list = null;
                        if (mappingUri != null)
                        {
                            try
                            {
                                list = site.GetList(mappingUri.AbsolutePath);
                            }
                            catch (Exception ex)
                            {
                                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                            }
                        }

                        if (list == null)
                        {
                            try
                            {
                                list =
                                    site.Lists.Cast<SPList>().Where(
                                        a => a.Fields.ContainsField(Constant.SystemFields.UNID)
                                             && a.GetItems(query).Count > 0).FirstOrDefault();
                            }
                            catch (Exception ex)
                            {
                                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                            }
                        }

                        if (list != null)
                        {
                            SPListItemCollection listItems = list.GetItems(query);
                            if (listItems != null && listItems.Count > 0)
                            {
                                string listItemUrl = string.Concat(list.Forms[PAGETYPE.PAGE_DISPLAYFORM].Url, "?ID=", listItems[0].ID);
                                listItemUrl = listItemUrl.Trim('/');
                                replaceText = string.Concat(site.ServerRelativeUrl.TrimEnd('/'), "/", listItemUrl);
                                richText = Regex.Replace(richText, match, replaceText, RegexOptions.IgnoreCase);
                            }
                        }
                        else
                        {
                            Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Format("UNID [{0}] could not be found in all list of site [{1}]", unid, internalUri.AbsoluteUri));

                        }

                    }
                }
                // replace text for external links.
                else if (!isInternalLink && isDocLinkFound)
                {
                    richText = Regex.Replace(richText, match, mappingUrl, RegexOptions.IgnoreCase);
                }
                if (siteCollection != null)
                    siteCollection.Dispose();
            }

            return richText;
        }
        private Uri BuildMappingUri(Uri internalUri, string mappingUrl)
        {
            if (string.IsNullOrEmpty(mappingUrl))
                return internalUri;
            Uri mappingUri = null;
            try
            {
                mappingUri = new Uri(mappingUrl);
            }
            catch (Exception ex)
            {
                mappingUri = null;
            }
            if (mappingUri != null)
                return mappingUri;
            if (mappingUrl.StartsWith(@"/lists/") || mappingUrl.StartsWith(@"lists/") || mappingUrl.Contains(@"/lists/"))
            {
                try
                {
                    mappingUri = new Uri(string.Concat(internalUri.OriginalString.Substring(0, internalUri.OriginalString.Length - internalUri.AbsolutePath.Length), "/", mappingUrl.TrimStart('/')));
                }
                catch
                {
                    return null;
                }
            }
            return mappingUri;
        }


        private string UpdateViewLinks(string richText, IEnumerable<string> matches)
        {
            string replaceText = string.Empty;
            string pattern = @"\w{32};\w{16}";
            foreach (string match in matches)
            {
                string result = Regex.Match(match, pattern).Value;
                if (currentTask.ViewMappings.ContainsKey(result))
                {
                    replaceText = currentTask.ViewMappings[result];
                    richText = Regex.Replace(richText, match, replaceText, RegexOptions.IgnoreCase);
                }
            }


            return richText;
        }

        #endregion

        #region Project and Mapping files

        public bool LoadConfig(string configName, SPWeb web)
        {
            string excelPath = string.Concat(web.Url.TrimEnd('/'), "/DeutscheBankSharePointLNARCitus/", configName);
            SPFile xFile = web.GetFile(excelPath);
            Stream fileContent = xFile.OpenBinaryStream();
            try
            {
                LoadConfigHelper loadConfigHelper = new LoadConfigHelper();

                BreakPermissions = loadConfigHelper.GetBreakPermissionsObject(fileContent);
                fileContent = xFile.OpenBinaryStream();
                currentTask = loadConfigHelper.GetTaskObject(fileContent);
                fileContent = xFile.OpenBinaryStream();
                mappingFileConfig = loadConfigHelper.GetMappingFileConfig(fileContent);
                fileContent = xFile.OpenBinaryStream();
                jobs = loadConfigHelper.GetJobs(fileContent);

                return true;
            }
            catch (Exception exception)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, exception.InnerException.ToString());
                return false;
            }

        }



        public bool LoadMappings(string mappingName, SPWeb web)
        {
            string excelPath = string.Concat(web.Url.TrimEnd('/'), "/DeutscheBankSharePointLNARCitus/", mappingName);
            SPFile xFile = web.GetFile(excelPath);
            Stream fileContent = xFile.OpenBinaryStream();
            LoadMappingHelper loadMappingHelper = null;
            try
            {
                loadMappingHelper = new LoadMappingHelper(fileContent);

                //Load database mapping
                currentTask.DatabaseMappings = loadMappingHelper.GetDBMappings(mappingFileConfig.MappingDatabaseLinkSheet);
                //Load view mapping
                currentTask.ViewMappings = loadMappingHelper.GetViewMapping(mappingFileConfig.MappingViewLinkSheet);
                //Load document mapping
                currentTask.DocumentMappings = loadMappingHelper.GetDocumentMapping(mappingFileConfig.MappingDocumentLinkSheet);
                //Load user mapping
                GetUsersMapping(loadMappingHelper.GetUsersMapping(mappingFileConfig.MappingUsersSheet));
                return true;

            }
            catch (Exception ex)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                return false;
            }
            finally
            {
                if (loadMappingHelper != null)
                    loadMappingHelper.Close();
            }
        }

        private void GetUsersMapping(Dictionary<string, string> userMapping)
        {
            if (userMapping == null || userMapping.Count <= 0) return;

            try
            {
                using (SPSite site = new SPSite(SiteId))
                {
                    using (SPWeb web = site.OpenWeb(WebId))
                    {
                        foreach (KeyValuePair<string, string> keyValuePair in userMapping)
                        {
                            string mapUser = keyValuePair.Value;
                            if (!string.IsNullOrEmpty(mapUser))
                                EnsureUserGroup(web, mapUser);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
            }

        }

        #endregion

        private void UpdateStatus(SPWeb web, long total, long current)
        {
            try
            {
                SPList statusList =
                    web.Lists["DeutscheBankSharePointLNARAsyncStatus"];

                if (statusList.Items.Count > 0)
                {
                    SPListItem statusItem = statusList.Items[0];
                    statusItem["Title"] = string.Format("Post-Process [{2}]: {0}/{1}", current, total, CurrentJobName);
                    statusItem.Update();
                }

            }
            catch (Exception ex)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Concat("UpdateStatus:", ex.Message));
            }

        }

        private SPUser GetCatcheUser(string loginName)
        {
            if (siteUserGroup.ContainsKey(loginName))
                return (SPUser)siteUserGroup[loginName];
            return null;
        }

        private object GetCatcheUserGroup(string key)
        {
            if (siteUserGroup.ContainsKey(key))
                return siteUserGroup[key];
            return null;
        }

        private bool CatcheUser(SPUser user)
        {
            if (siteUserGroup.ContainsKey(user.LoginName))
                return false;
            siteUserGroup.Add(user.LoginName, user);
            return true;
        }

        private bool CatcheGroup(SPGroup group)
        {
            if (siteUserGroup.ContainsKey(group.Name))
                return false;
            siteUserGroup.Add(group.Name, group);
            return true;
        }

        private object EnsureUserGroup(SPWeb site, string loginName)
        {
            object userGroup = GetCatcheUserGroup(loginName);
            SPUser spUser = null;
            SPGroup spGroup = null;

            if (userGroup != null)
                return userGroup;
            try
            {
                spGroup = site.Groups[loginName];
            }
            catch (Exception ex)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Concat("[", loginName, "]", ex.Message));
            }

            if (spGroup == null)
            {
                try
                {
                    spUser = GetCatcheUser(loginName);
                    if (spUser == null)
                        spUser = site.Users[loginName];
                }
                catch (Exception ex)
                {
                    Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Concat("[", loginName, "]", ex.Message));
                }

                if (spUser == null)
                {
                    try
                    {
                        SPGroup temGroup = site.Groups.Cast<SPGroup>().Where(
                                                                a => a.Users.Cast<SPUser>().Where(
                                                                b => b.LoginName.ToUpper().Equals(loginName.ToUpper())).
                                                                     FirstOrDefault() != null)
                                                            .FirstOrDefault();
                        if (temGroup != null)
                        {
                            spUser = temGroup.Users.Cast<SPUser>().Where(
                                b => b.LoginName.ToUpper().Equals(loginName.ToUpper())).
                                FirstOrDefault();
                        }
                        if (spUser == null)
                        {
                            Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Format("Use or Group [{0}] not found.", loginName));
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, ex.InnerException.ToString());
                    }
                }
            }

            if (spGroup != null)
            {
                CatcheGroup(spGroup);
                return spGroup;
            }
            if (spUser != null)
            {
                CatcheUser(spUser);
                return spUser;
            }

            return null;
        }
    }
}