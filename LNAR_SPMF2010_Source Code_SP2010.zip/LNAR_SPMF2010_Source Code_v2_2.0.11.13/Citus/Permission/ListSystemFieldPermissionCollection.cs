﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission
{
    public class ListSystemFieldPermissionCollection: ICollection<ListSystemFieldPermission>
    {
        #region Properties
        private ListDictionary ListSystemFieldPermissions = new ListDictionary();

        #endregion

        public ListSystemFieldPermission Get(string listName)
        {
            foreach (ListSystemFieldPermission listSystemFieldPermission in this)
            {
                if(listSystemFieldPermission.ListName.Equals(listName))
                    return listSystemFieldPermission;
            }
            return null;
        }

        public IEnumerator<ListSystemFieldPermission> GetEnumerator()
        {
            foreach (DictionaryEntry fieldPermission in ListSystemFieldPermissions)
            {
                yield return (ListSystemFieldPermission)fieldPermission.Value;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            foreach (DictionaryEntry fieldPermission in ListSystemFieldPermissions)
            {
                yield return fieldPermission.Value;
            }
        }

        public void Add(ListSystemFieldPermission item)
        {
            if (item != null)
            {
                foreach (ListSystemFieldPermission listSystemFieldPermission in this)
                {
                    if (listSystemFieldPermission.ListName.Equals(item.ListName))
                        Remove(listSystemFieldPermission);
                }
                ListSystemFieldPermissions.Add(item.GetHashCode(), item);   
            }
        }

        public void Clear()
        {
            ListSystemFieldPermissions.Clear();
        }

        public bool Contains(ListSystemFieldPermission item)
        {
            return Contains(item);
        }

        public void CopyTo(ListSystemFieldPermission[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public bool Remove(ListSystemFieldPermission item)
        {
            if (ListSystemFieldPermissions.Contains(item.GetHashCode()))
            {
                ListSystemFieldPermissions.Remove(item.GetHashCode());
                return true;
            }
            return false;
        }

        public int Count
        {
            get { return ListSystemFieldPermissions.Count;}
        }

        public bool IsReadOnly
        {
            get { throw new NotImplementedException(); }
        }
    }
}
