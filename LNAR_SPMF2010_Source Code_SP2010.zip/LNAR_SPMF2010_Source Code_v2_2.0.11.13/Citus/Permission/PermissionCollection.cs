﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission
{
    public class PermissionCollection: ICollection<Permissions>
    {
        #region Properties
        private ListDictionary ListPermission = new ListDictionary();
        #endregion

        public void Add(Permissions item)
        {
            if (item != null)
                ListPermission.Add(item.GetHashCode(), item);
        }

        public void Clear()
        {
            ListPermission.Clear();
        }

        public bool Contains(Permissions item)
        {
            return Contains(item);
        }

        public void CopyTo(Permissions[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public int Count
        {
            get { return ListPermission.Count; }
        }

        public bool IsReadOnly
        {
            get { throw new NotImplementedException(); }
        }

        public bool Remove(Permissions item)
        {
            if (ListPermission.Contains(item))
            {
                ListPermission.Remove(item.GetHashCode());
                return true;
            }
            return false;
        }

        public ArrayList GetPermissionByName(string groupOrUserName)
        {
            foreach(Permissions permission in this)
            {
                if(permission.UserOrGroupName.Equals(groupOrUserName))
                    return permission.Permission;
            }
            return new ArrayList();
        }


        public IEnumerator<Permissions> GetEnumerator()
        {
            foreach (DictionaryEntry permission in ListPermission)
            {
                yield return (Permissions)permission.Value;
            }
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            foreach (DictionaryEntry permission in ListPermission)
            {
                yield return permission.Value;
            }
        }
    }
}
