﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission
{
    public class BreakPermissionCollection:ICollection<BreakPermission>
    {
        private ListDictionary BreakPermission = new ListDictionary();

        public void Add(BreakPermission item)
        {
            if (item != null)
                BreakPermission.Add(item.GetHashCode(), item);
        }

        public void Clear()
        {
            BreakPermission.Clear();
        }

        public bool Contains(BreakPermission item)
        {
            return item.Contain(item.ListName);
        }

        public bool Contains(string listName)
        {
            return this.Cast<BreakPermission>().Where(a => a.ListName.Equals(listName)).Count() > 0;
        }

        public void CopyTo(BreakPermission[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public int Count
        {
            get { return BreakPermission.Count; }
        }

        public bool IsReadOnly
        {
            get { throw new NotImplementedException(); }
        }

        public bool Remove(BreakPermission item)
        {
            if (item.Contain(item.ListName))
            {
                BreakPermission.Remove(item.GetHashCode());
                return true;
            }
            return false;
        }
        public bool Remove(string ListName)
        {
            foreach (BreakPermission breakPermission in this)
            {
                if (breakPermission.ListName.Equals(ListName))
                {
                    BreakPermission.Remove(breakPermission.GetHashCode());
                    return true;
                }
            }
            return false;
            
        }
        public IEnumerator<BreakPermission> GetEnumerator()
        {
            foreach (DictionaryEntry breakPermission in BreakPermission)
            {
                yield return (BreakPermission)breakPermission.Value;
            }
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            foreach (DictionaryEntry breakPermission in BreakPermission)
            {
                yield return breakPermission.Value;
            }
        }
        public BreakPermission GetBreakPermission(string listName)
        {
            foreach (BreakPermission breakPermission in this)
            {
                if(breakPermission.Contain(listName))
                    return breakPermission;
            }

            return null;
        }
    
    }
}
