﻿namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission
{
    public class SystemFieldPermission
    {
        #region Properties
        public string FieldName { get; set;}
        public string GroupName { get; set;}
        //public string ListName { get; set; }
        #endregion

        #region Constructor
        public SystemFieldPermission()
        {
        }
        #endregion
    }
}
