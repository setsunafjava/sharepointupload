﻿namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission
{
    public class BreakPermission
    {
        #region Private

        private string listName;
        private PermissionCollection permissions=new PermissionCollection();
        private bool isBreak;
        #endregion
        #region Properties
        
        public bool IsBreak
        {
            get { return isBreak; }
            set { isBreak = value; }
        }

        public PermissionCollection Permissions
        {
            get { return permissions; }
            set { permissions = value; }
        }

        public string ListName
        {
            get { return listName; }
            set { listName = value; }
        }

        #endregion
        #region Constructor
        public BreakPermission()
        {
            isBreak = false;
        }
        #endregion
        #region Method
        public bool Contain(string name)
        {
            if (listName.Equals(name))
            {
                return true;
            }
            return false;
        }
        #endregion
    }
}
