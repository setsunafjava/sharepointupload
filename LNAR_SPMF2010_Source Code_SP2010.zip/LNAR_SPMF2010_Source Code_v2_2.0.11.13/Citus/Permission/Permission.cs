﻿using System.Collections;
using System.Linq;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission
{
    public class Permissions
    {
        private bool isGroup = false;
        private ArrayList permission = new ArrayList();
        private string userOrGroupName;

        public bool IsGroup
        {
            get{ return isGroup;}
            set{ isGroup = value;}
        }

        public ArrayList Permission
        {
            get{ return permission;}
            set
            {
                if(value != null) permission = value;
            }
        }

        public string UserOrGroupName
        {
            get { return userOrGroupName; }
            set { userOrGroupName = value; }
        }
        
        public bool CheckPermission(string permission)
        {
            return Permission.Cast<string>().Where(a => a.Equals(permission)).Count() > 0;
        }
    }
}
