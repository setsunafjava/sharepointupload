﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission
{
    public class SystemFieldPermissionCollection : ICollection<SystemFieldPermission>
    {
        #region Properties
        private ListDictionary SystemFieldPermission = new ListDictionary();
        
        #endregion

        #region Method
        public SystemFieldPermission Get(string fieldName)
        {
            foreach (SystemFieldPermission fieldPermission in this)
            {
                if (fieldPermission .Equals(fieldName))
                    return fieldPermission;
            }
            return null;
        }
        
        public IEnumerator<SystemFieldPermission> GetEnumerator()
        {
            foreach (DictionaryEntry fieldPermission in SystemFieldPermission)
            {
                yield return (SystemFieldPermission)fieldPermission.Value;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            foreach (DictionaryEntry fieldPermission in SystemFieldPermission)
            {
                yield return fieldPermission.Value;
            }
        }

        public void Add(SystemFieldPermission item)
        {
            if(item != null)
                SystemFieldPermission.Add(item.GetHashCode(),item);
        }

        public void Clear()
        {
            SystemFieldPermission.Clear();
        }

        public bool Contains(SystemFieldPermission item)
        {
            return Contains(item);
        }

        public void CopyTo(SystemFieldPermission[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public bool Remove(SystemFieldPermission item)
        {
            if (SystemFieldPermission.Contains(item))
            {
                SystemFieldPermission.Remove(item.GetHashCode());
                return true;
            }
            return false;
        }

        public int Count
        {
            get { return SystemFieldPermission.Count; }
        }

        public bool IsReadOnly
        {
            get { throw new NotImplementedException(); }
        }

        #endregion
    }
}
