﻿namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission
{
    public class ListSystemFieldPermission
    {
        public SystemFieldPermissionCollection SystemFieldPermissions;
        public string ListName { get; set;}

        public ListSystemFieldPermission()
        {
            SystemFieldPermissions = new SystemFieldPermissionCollection();
        }
    }
}
