﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission
{
    public class FieldPermissionCollection : ICollection<FieldPermission>
    {
        #region Properties
        private ListDictionary FieldPermissions = new ListDictionary();

        #endregion

        public FieldPermission Get(string listName, string fieldName)
        {
            foreach (FieldPermission fieldPermission in this)
            {
                if (fieldPermission.ListName.Equals(listName) && fieldPermission.FieldName.Equals(fieldName))
                    return fieldPermission;
            }
            return null;
        }
        public void Remove(string listName,string fieldName)
        {
            if(this.FieldPermissions.Count <=0) return;
            FieldPermission fieldPermission = Get(listName, fieldName);
            if(fieldPermission != null)
                FieldPermissions.Remove(fieldPermission.GetHashCode());

        }
        public FieldPermissionCollection Get(string listName)
        {
            FieldPermissionCollection fieldPermissionCollection = new FieldPermissionCollection();
            foreach (FieldPermission fieldPermission in this)
            {
                if (fieldPermission.ListName.Equals(listName))
                    fieldPermissionCollection.Add(fieldPermission);
            }
            if (fieldPermissionCollection.Count > 0)
                return fieldPermissionCollection;
            return null;
        }
        
        public IEnumerator<FieldPermission> GetEnumerator()
        {
            
            foreach (DictionaryEntry fieldPermission in FieldPermissions)
            {
                yield return (FieldPermission) fieldPermission.Value;
            }
           
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            foreach (DictionaryEntry fieldPermission in FieldPermissions)
            {
                yield return fieldPermission.Value;
            }
        }

        public void Add(FieldPermission item)
        {
            if (item != null)
            {

                for(int i=this.FieldPermissions.Count-1; i>=0; i--)
                {
                    FieldPermission fieldPermission = (FieldPermission)FieldPermissions[i];

                    if ((fieldPermission!=null)&&(fieldPermission.ListName.Equals(item.ListName))
                        && fieldPermission.FieldName.Equals(item.FieldName))
                        Remove(fieldPermission);
                }
                FieldPermissions.Add(item.GetHashCode(), item);
            }
        }

        public void Clear()
        {
            FieldPermissions.Clear();
        }

        public bool Contains(FieldPermission item)
        {
            return Contains(item);
        }

        public void CopyTo(FieldPermission[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public bool Remove(FieldPermission item)
        {
            if (FieldPermissions.Contains(item.GetHashCode()))
            {
                FieldPermissions.Remove(item.GetHashCode());
                return true;
            }
            return false;
        }

        public int Count
        {
            get { return FieldPermissions.Count; }
        }

        public bool IsReadOnly
        {
            get { throw new NotImplementedException(); }
        }
    }
}
