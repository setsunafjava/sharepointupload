﻿using System.Collections;

namespace DeutscheBank.SharePoint.LNAR.Framework.Citus.Permission
{
    public class FieldPermission
    {
        public string ListName{get;set;}
        public string FieldName { get; set; }
        private ArrayList permissions;

        public FieldPermission()
        {
            permissions = new ArrayList();
        }

        public ArrayList Permissions
        {
            get { return permissions; }
            set
            {
                if (value != null) permissions = value;
            }
        }
    }
}
