﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;

namespace DeutscheBank.SharePoint.LNAR.Framework.Calendar
{
    public class MeetingMessage : MailMessage
    {
        private readonly bool allDayEvent;

        private readonly RecurrenceBase recurrence;

        private readonly DateTime startTime;
        private readonly DateTime endTime;

        private string Location { get; set; }

        public MeetingMessage(string location, DateTime startTime, DateTime endTime,
                              bool allDayEvent)
        {
            Location = location;
            this.startTime = startTime;
            this.endTime = endTime;
            this.allDayEvent = allDayEvent;
        }

        public MeetingMessage(RecurrenceBase recurrence, string location, DateTime startTime, DateTime endTime)
        {
            Location = location;
            this.startTime = startTime;
            this.endTime = endTime;
            this.recurrence = recurrence;
        }

        internal void AddCalendarView(string currentUser, string currentEmail)
        {
            var calendarType = new ContentType("text/calendar");
            calendarType.Parameters.Add("method", "REQUEST");
            calendarType.Parameters.Add("name", "meeting.ics");

            #region Construct a Ics File;
            const string dateFormat = "yyyyMMdd";
            const string dateTimeFormat = "yyyyMMddTHHmmssZ";



            var icsBuilder = new StringBuilder();
            icsBuilder.AppendLine("BEGIN:VCALENDAR");
            icsBuilder.AppendLine("PRODID:-//Microsoft Corporation//Outlook 12.0 MIMEDIR//EN");
            icsBuilder.AppendLine("VERSION:2.0");
            icsBuilder.AppendLine("METHOD:REQUEST");
            icsBuilder.AppendLine("X-MS-OLK-FORCEINSPECTOROPEN:TRUE");
            icsBuilder.AppendLine("BEGIN:VEVENT");

            foreach (var mailAddress in To)
            {
                icsBuilder.AppendLine(string.Format("ATTENDEE;CN=\"{0}\";RSVP=TRUE:mailto:{1}", mailAddress.DisplayName, mailAddress.Address));
            }

            if (CC != null)
            {
                foreach (var mailAddress in CC)
                {
                    icsBuilder.AppendLine(string.Format("ATTENDEE;CN=\"{0}\";ROLE=OPT-PARTICIPANT;RSVP=TRUE:mailto:{1}", mailAddress.DisplayName, mailAddress.Address));
                }
            }

            icsBuilder.AppendLine("CLASS:PUBLIC");
            icsBuilder.AppendLine(string.Format("CREATED:{0}", DateTime.UtcNow.ToString(dateFormat)));
            icsBuilder.AppendLine(string.Format("DESCRIPTION:{0}", ""));

            if (recurrence == null)
            {
                if (allDayEvent)
                {
                    icsBuilder.AppendLine(string.Format("DTSTART;VALUE=DATE:{0}", startTime.ToUniversalTime().ToString(dateFormat)));
                    icsBuilder.AppendLine(string.Format("DTEND;VALUE=DATE:{0}", endTime.ToUniversalTime().ToString(dateFormat)));
                }
                else
                {
                    icsBuilder.AppendLine(string.Format("DTSTART:{0}", startTime.ToUniversalTime().ToString(dateTimeFormat)));
                    icsBuilder.AppendLine(string.Format("DTEND:{0}", endTime.ToUniversalTime().ToString(dateTimeFormat)));
                }
            }
            else
            {
                icsBuilder.AppendLine(string.Format("DTSTART:{0}", recurrence.StartDate.ToUniversalTime().ToString(dateTimeFormat)));
              if (recurrence.GetEndDate() != DateTime.MaxValue)
                icsBuilder.AppendLine(string.Format("DTEND:{0}", recurrence.GetEndDate().ToUniversalTime().ToString(dateTimeFormat)));
            }


            icsBuilder.AppendLine(string.Format("DTSTAMP:{0}", DateTime.UtcNow.ToString(dateFormat)));
            icsBuilder.AppendLine(string.Format("LAST-MODIFIED:{0}", DateTime.UtcNow.ToString(dateFormat)));
            icsBuilder.AppendLine(string.Format("LOCATION:{0}", Location));

            icsBuilder.AppendLine(From == null
                                      ? string.Format("ORGANIZER;CN=\"{0}\":mailto:{1}", currentUser, currentEmail)
                                      : string.Format("ORGANIZER;CN=\"{0}\":mailto:{1}", From.DisplayName, From.Address));
            icsBuilder.AppendLine(string.Format("PRIORITY:{0}", GetMessagePriority(Priority)));

            if (recurrence != null)
            {
                recurrence.BuildIcs(icsBuilder);
            }

            icsBuilder.AppendLine("SEQUENCE:0");
            icsBuilder.AppendLine(string.Format("SUMMARY:{0}", Subject));
            icsBuilder.AppendLine("TRANSP:OPAQUE");
            icsBuilder.AppendLine(string.Format("UID:{0}", Guid.NewGuid().ToString("N").ToUpperInvariant()));
            icsBuilder.AppendLine(string.Format("X-ALT-DESC;FMTTYPE=text/html:{0}", ""));
            icsBuilder.AppendLine("X-MS-OLK-CONFTYPE:0");
            icsBuilder.AppendLine("X-MICROSOFT-DISALLOW-COUNTER:FALSE");
            icsBuilder.AppendLine("BEGIN:VALARM");
            icsBuilder.AppendLine("TRIGGER:-PT15M");
            icsBuilder.AppendLine("ACTION:DISPLAY");
            icsBuilder.AppendLine("DESCRIPTION:Reminder");
            icsBuilder.AppendLine("END:VALARM");
            icsBuilder.AppendLine("END:VEVENT");
            icsBuilder.AppendLine("END:VCALENDAR");

            #endregion

            string bodyCalendar = icsBuilder.ToString();
            var calendarView = AlternateView.CreateAlternateViewFromString(bodyCalendar, calendarType);
            calendarView.TransferEncoding = TransferEncoding.SevenBit;

            AlternateViews.Add(calendarView);
        }

        private static int GetMessagePriority(MailPriority mailPriority)
        {
            switch (mailPriority)
            {
                case MailPriority.Normal:
                    return 0;
                case MailPriority.Low:
                    return -1;
                case MailPriority.High:
                    return 1;
                default:
                    return 0;
            }
        }

        #region Nested type: RecurrenceBase

        public abstract class RecurrenceBase
        {
  
            protected Recurrence recurrentObject;

            protected RecurrenceBase()
            {

            }

            protected RecurrenceBase(RecurrenceBase recurrenceBase)
            {
                Duration = recurrenceBase.Duration;
                StartDate = recurrenceBase.StartDate;
                NumberOfOccurrences = recurrenceBase.NumberOfOccurrences;
                EndDate = recurrenceBase.EndDate;
            }

            public const string DateFormat = "yyyyMMddTHHmmssZ";

            /// <summary>
            ///   Gets or sets the minutes for which this meeting plays.
            /// </summary>
            public int Duration { get; set; }

            /// <summary>
            ///   Gets or sets the date for which this meeting start.
            /// </summary>
            public DateTime StartDate { get; set; }

            #region require properties of Recurrence Event 

            /// <summary>
            ///   Gets or sets the number of occurrences for which this meeting plays.
            /// </summary>
            public int? NumberOfOccurrences { get; set; }

            /// <summary>
            /// Gets or set time-unit between two occurences
            /// </summary>
            public int Interval { get; set; }

            #region Until Date
            #endregion

            /// <summary>
            ///   Gets or sets the date for which this meeting end.
            /// </summary>
            public DateTime? EndDate { get; set; }

            #endregion

            internal abstract void BuildIcs(StringBuilder icsBuilder);

            internal abstract DateTime GetEndDate();
        }

        #endregion

        #region Nested type: DailyRecurrence

        public class DailyRecurrence : RecurrenceBase
        {
            public int EveryDays { get; set; }

            public bool EveryInWeekdays { get; set; }

            internal override void BuildIcs(StringBuilder icsBuilder)
            {
                if (EveryInWeekdays)
                {
                    var weeklyRecurrence = new WeeklyRecurrence(this);
                    weeklyRecurrence.Days.Add(DayOfWeek.Monday);
                    weeklyRecurrence.Days.Add(DayOfWeek.Tuesday);
                    weeklyRecurrence.Days.Add(DayOfWeek.Wednesday);
                    weeklyRecurrence.Days.Add(DayOfWeek.Thursday);
                    weeklyRecurrence.Days.Add(DayOfWeek.Friday);
                    weeklyRecurrence.BuildIcs(icsBuilder);
                }
                else
                {
                    recurrentObject = new Recurrence {Interval = EveryDays};

                    if (EndDate.HasValue)
                        recurrentObject.UntilDate = (DateTime) EndDate;
                    else
                    {
                        if (NumberOfOccurrences.HasValue)
                            recurrentObject.Count = Convert.ToInt32(NumberOfOccurrences);
                       
                    }

                    
                    icsBuilder.Append(recurrentObject.ToString());
                    icsBuilder.Append(Environment.NewLine);
                }
            }

            internal override DateTime GetEndDate()
            {
                if (EndDate.HasValue)
                {
                    return (DateTime) EndDate;
                }

                return NumberOfOccurrences.HasValue ? StartDate.AddDays(Convert.ToDouble(NumberOfOccurrences)*Interval) : DateTime.MaxValue;
            }
        }

        #endregion

        #region Nested type: WeeklyRecurrence

        public class WeeklyRecurrence : RecurrenceBase
        {
            public WeeklyRecurrence()
            {
                EveryWeeks = 1;
                Days = new List<DayOfWeek>();
            }

            public WeeklyRecurrence(RecurrenceBase recurrenceBase)
                : base(recurrenceBase)
            {

            }

            public int EveryWeeks { get; set; }

            public IList<DayOfWeek> Days { get;  set; }

            internal override void BuildIcs(StringBuilder icsBuilder)
            {

                recurrentObject = new Recurrence();
                if (Days.Count >0)
                {
                  var byDay = new Recurrence.ByDay[Days.Count];
                    for (int i=0; i<Days.Count; i++)
                    {
                      byDay[i] = new Recurrence.ByDay(Days[i],1); 
                    }
                    recurrentObject.ByDayList = byDay;
                }
                
              
                 
                recurrentObject.Interval = EveryWeeks;

                if (EndDate.HasValue)
                    recurrentObject.UntilDate = (DateTime)EndDate;
                else
                {
                    if (NumberOfOccurrences.HasValue)
                        recurrentObject.Count = Convert.ToInt32(NumberOfOccurrences);
                   
                }

                icsBuilder.Append(recurrentObject.ToString());
                icsBuilder.Append(Environment.NewLine);
            }

            internal override DateTime GetEndDate()
            {
                if (EndDate.HasValue)
                {
                    return (DateTime) EndDate;
                }

                return NumberOfOccurrences.HasValue ? StartDate.AddDays(Convert.ToDouble(NumberOfOccurrences) * Interval*7) : DateTime.MaxValue;
            }
        }

        #endregion

        #region Nested type: MonthlyRecurrence

        public class MonthlyRecurrence : RecurrenceBase
        {
            public MonthlyRecurrence()
            {
                EveryMonths = 1;
                OffSet = 1;
                Day = DateTime.Now.DayOfWeek;
            }
            public int EveryMonths { get; set; }

            #region SetDay
            public int? EveryInDay { get; set; }
            public int OffSet{ get; set; }
            public DayOfWeek Day{ get; set; }
            #endregion


            internal override void BuildIcs(StringBuilder icsBuilder)
            {
                recurrentObject = new Recurrence {Interval = EveryMonths};

                if (EveryInDay.HasValue)
                    recurrentObject.ByMonthDay = new[]{Convert.ToInt32(EveryInDay)} ;
                else
                {
                    recurrentObject.ByDayList = new[]{new Recurrence.ByDay(Day,1)};
                    recurrentObject.BySetPosition = new[]{OffSet};
                }

                icsBuilder.Append(recurrentObject.ToString());
                icsBuilder.Append(Environment.NewLine);

            }

            internal override DateTime GetEndDate()
            {
                if (EndDate.HasValue)
                    return (DateTime)EndDate;
                if (NumberOfOccurrences.HasValue)
                    return StartDate.AddMonths(Convert.ToInt32(NumberOfOccurrences)*EveryMonths);
                return DateTime.MaxValue;
            }
        }

        #endregion

        #region Nested type: YearlyRecurrence

        public class YearlyRecurrence : RecurrenceBase
        {
            public int? EveryInDay { get; set; }

            public int EveryInMonth { get; set; }

            public DayOfWeek Day { get; set; }

            public int OffSet { get; set; }

            internal override void BuildIcs(StringBuilder icsBuilder)
            {
                recurrentObject = new Recurrence();

                if (EveryInDay.HasValue)
                   
                {
                    recurrentObject.ByMonthDay = new [] { Convert.ToInt32(EveryInDay) };
                    recurrentObject.ByMonth = new [] { Convert.ToInt32(EveryInMonth) };
                }
                else
                {
                    recurrentObject.ByDayList = new[] { new Recurrence.ByDay(Day, 1) };
                    recurrentObject.BySetPosition = new[] { OffSet };
                    recurrentObject.ByMonth = new [] { Convert.ToInt32(EveryInMonth) };
                }

                icsBuilder.Append(recurrentObject.ToString());
                icsBuilder.Append(Environment.NewLine);

            }

            internal override DateTime GetEndDate()
            {
                if (EndDate.HasValue)
                    return (DateTime)EndDate;
                if (NumberOfOccurrences.HasValue)
                    return StartDate.AddYears(Convert.ToInt32(NumberOfOccurrences));
                return DateTime.MaxValue;
            }
        }

        #endregion
    }
}