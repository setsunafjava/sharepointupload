﻿using System;

namespace DeutscheBank.SharePoint.LNAR.Framework.Calendar
{
    [Flags]
    public enum CalendarComplianceStatus
    {
        Compliant = 0,
        ComponentNameMismatch = 0x400,
        EmptyComponentName = 0x4000,
        EmptyParameterName = 0x1000,
        EmptyPropertyName = 0x2000,
        EndTagWithoutBegin = 0x200,
        InvalidCharacterInParameterName = 8,
        InvalidCharacterInParameterText = 0x10,
        InvalidCharacterInPropertyName = 4,
        InvalidCharacterInPropertyValue = 0x40,
        InvalidCharacterInQuotedString = 0x20,
        InvalidParameterValue = 0x10000,
        InvalidValueFormat = 0x800,
        NotAllComponentsClosed = 0x80,
        ParametersOnComponentTag = 0x100,
        PropertyOutsideOfComponent = 0x8000,
        PropertyTruncated = 2,
        StreamTruncated = 1
    }
}
