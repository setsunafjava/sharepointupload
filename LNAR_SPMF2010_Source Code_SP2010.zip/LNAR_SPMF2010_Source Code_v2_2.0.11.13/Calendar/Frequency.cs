﻿namespace DeutscheBank.SharePoint.LNAR.Framework.Calendar
{
    public enum Frequency
    {
        Unknown,
        Secondly,
        Minutely,
        Hourly,
        Daily,
        Weekly,
        Monthly,
        Yearly
    }
}
