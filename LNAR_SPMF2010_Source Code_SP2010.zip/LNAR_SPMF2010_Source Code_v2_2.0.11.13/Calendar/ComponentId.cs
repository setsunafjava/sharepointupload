﻿using System;

namespace DeutscheBank.SharePoint.LNAR.Framework.Calendar
{
    [Flags]
    public enum ComponentId
    {
        Daylight = 0x200,
        None = 0,
        Standard = 0x100,
        Unknown = 1,
        VAlarm = 0x80,
        VCalendar = 2,
        VEvent = 4,
        VFreeBusy = 0x20,
        VJournal = 0x10,
        VTimeZone = 0x40,
        VTodo = 8
    }
}
