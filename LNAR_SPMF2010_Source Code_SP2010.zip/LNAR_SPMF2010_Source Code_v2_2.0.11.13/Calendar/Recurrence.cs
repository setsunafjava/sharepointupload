﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace DeutscheBank.SharePoint.LNAR.Framework.Calendar
{
    public class Recurrence
    {
        private static readonly Dictionary<string, Frequency> FrequencyToEnumTable;
        private static readonly Dictionary<string, RecurrenceProperties> RecurPropToEnumTable;
        private ByDay[] byDay;
        private int[] byHour;
        private int[] byMinute;
        private int[] byMonth;
        private int[] byMonthDay;
        private int[] bySecond;
        private int[] bySetPos;
        private int[] byWeekNumber;
        private int[] byYearDay;
        private int count;
        private Frequency freq;
        private int interval;
        private RecurrenceProperties props;
        private DateTime untilDate;
        private DateTime untilDateTime;
        private DayOfWeek workWeekStart;

        static Recurrence()
        {
            FrequencyToEnumTable = new Dictionary<string, Frequency>();
            RecurPropToEnumTable = new Dictionary<string, RecurrenceProperties>();
            FrequencyToEnumTable.Add("SECONDLY", Frequency.Secondly);
            FrequencyToEnumTable.Add("MINUTELY", Frequency.Minutely);
            FrequencyToEnumTable.Add("HOURLY", Frequency.Hourly);
            FrequencyToEnumTable.Add("DAILY", Frequency.Daily);
            FrequencyToEnumTable.Add("WEEKLY", Frequency.Weekly);
            FrequencyToEnumTable.Add("MONTHLY", Frequency.Monthly);
            FrequencyToEnumTable.Add("YEARLY", Frequency.Yearly);
            RecurPropToEnumTable.Add("FREQ", RecurrenceProperties.Frequency);
            RecurPropToEnumTable.Add("UNTIL", RecurrenceProperties.UntilDate);
            RecurPropToEnumTable.Add("COUNT", RecurrenceProperties.Count);
            RecurPropToEnumTable.Add("INTERVAL", RecurrenceProperties.Interval);
            RecurPropToEnumTable.Add("BYSECOND", RecurrenceProperties.BySecond);
            RecurPropToEnumTable.Add("BYMINUTE", RecurrenceProperties.ByMinute);
            RecurPropToEnumTable.Add("BYHOUR", RecurrenceProperties.ByHour);
            RecurPropToEnumTable.Add("BYDAY", RecurrenceProperties.ByDay);
            RecurPropToEnumTable.Add("BYMONTHDAY", RecurrenceProperties.ByMonthDay);
            RecurPropToEnumTable.Add("BYYEARDAY", RecurrenceProperties.ByYearDay);
            RecurPropToEnumTable.Add("BYWEEKNO", RecurrenceProperties.ByWeek);
            RecurPropToEnumTable.Add("BYMONTH", RecurrenceProperties.ByMonth);
            RecurPropToEnumTable.Add("BYSETPOS", RecurrenceProperties.BySetPosition);
            RecurPropToEnumTable.Add("WKST", RecurrenceProperties.WeekStart);
        }

        public Recurrence()
        {
            interval = 1;
            workWeekStart = DayOfWeek.Monday;
        }

        public RecurrenceProperties AvailableProperties
        {
            get { return props; }
            set { props = value; }
        }

        public ByDay[] ByDayList
        {
            get { return byDay; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException();
                }
                props |= RecurrenceProperties.ByDay;
                byDay = value;
            }
        }

        public int[] ByHour
        {
            get { return byHour; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException();
                }
                props |= RecurrenceProperties.ByHour;
                byHour = value;
            }
        }

        public int[] ByMinute
        {
            get { return byMinute; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException();
                }
                props |= RecurrenceProperties.ByMinute;
                byMinute = value;
            }
        }

        public int[] ByMonth
        {
            get { return byMonth; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException();
                }
                props |= RecurrenceProperties.ByMonth;
                byMonth = value;
            }
        }

        public int[] ByMonthDay
        {
            get { return byMonthDay; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException();
                }
                props |= RecurrenceProperties.ByMonthDay;
                byMonthDay = value;
            }
        }

        public int[] BySecond
        {
            get { return bySecond; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException();
                }
                props |= RecurrenceProperties.BySecond;
                bySecond = value;
            }
        }

        public int[] BySetPosition
        {
            get { return bySetPos; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException();
                }
                props |= RecurrenceProperties.BySetPosition;
                bySetPos = value;
            }
        }

        public int[] ByWeek
        {
            get { return byWeekNumber; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException();
                }
                props |= RecurrenceProperties.ByWeek;
                byWeekNumber = value;
            }
        }

        public int[] ByYearDay
        {
            get { return byYearDay; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException();
                }
                props |= RecurrenceProperties.ByYearDay;
                byYearDay = value;
            }
        }

        public int Count
        {
            get { return count; }
            set
            {
                props |= RecurrenceProperties.Count;
                count = value;
            }
        }

        public Frequency Frequency
        {
            get { return freq; }
            set
            {
                props |= RecurrenceProperties.Frequency;
                freq = value;
            }
        }

        public int Interval
        {
            get { return interval; }
            set
            {
                props |= RecurrenceProperties.Interval;
                interval = value;
            }
        }

        public DateTime UntilDate
        {
            get { return untilDate; }
            set
            {
                props &= ~RecurrenceProperties.UntilDateTime;
                props |= RecurrenceProperties.UntilDate;
                untilDate = value;
            }
        }

        public DateTime UntilDateTime
        {
            get { return untilDateTime; }
            set
            {
                props &= ~RecurrenceProperties.UntilDate;
                props |= RecurrenceProperties.UntilDateTime;
                untilDateTime = value;
            }
        }

        public DayOfWeek WorkWeekStart
        {
            get { return workWeekStart; }
            set
            {
                props |= RecurrenceProperties.WeekStart;
                workWeekStart = value;
            }
        }

        private static string GetDayOfWeekString(DayOfWeek d)
        {
            switch (d)
            {
                case DayOfWeek.Sunday:
                    return "SU";

                case DayOfWeek.Monday:
                    return "MO";

                case DayOfWeek.Tuesday:
                    return "TU";

                case DayOfWeek.Wednesday:
                    return "WE";

                case DayOfWeek.Thursday:
                    return "TH";

                case DayOfWeek.Friday:
                    return "FR";

                case DayOfWeek.Saturday:
                    return "SA";
            }
            return string.Empty;
        }

        private static string GetFrequencyString(Frequency f)
        {
            switch (f)
            {
                case Frequency.Secondly:
                    return "SECONDLY";

                case Frequency.Minutely:
                    return "MINUTELY";

                case Frequency.Hourly:
                    return "HOURLY";

                case Frequency.Daily:
                    return "DAILY";

                case Frequency.Weekly:
                    return "WEEKLY";

                case Frequency.Monthly:
                    return "MONTHLY";

                case Frequency.Yearly:
                    return "YEARLY";
            }
            return "";
        }

        private static void OutputList(int[] list, StringBuilder s)
        {
            var length = list.Length;
            if (length > 0)
            {
                s.Append(list[0]);
            }
            for (var i = 1; i < length; i++)
            {
                s.Append(',');
                s.Append(list[i].ToString());
            }
        }

        public override string ToString()
        {
            var s = new StringBuilder();
            if ((props & RecurrenceProperties.Frequency) != RecurrenceProperties.None)
            {
                s.Append("FREQ");
                s.Append('=');
                s.Append(GetFrequencyString(freq));
            }
            if ((props & RecurrenceProperties.UntilDate) != RecurrenceProperties.None)
            {
                s.Append(";UNTIL");
                s.Append('=');
                s.Append(CalendarCommon.FormatDate(untilDate));
            }
            if ((props & RecurrenceProperties.UntilDateTime) != RecurrenceProperties.None)
            {
                s.Append(";UNTIL");
                s.Append('=');
                s.Append(CalendarCommon.FormatDateTime(untilDateTime));
            }
            if ((props & RecurrenceProperties.Count) != RecurrenceProperties.None)
            {
                s.Append(";COUNT");
                s.Append('=');
                s.Append(count);
            }
            if ((props & RecurrenceProperties.Interval) != RecurrenceProperties.None)
            {
                s.Append(";INTERVAL");
                s.Append('=');
                s.Append(interval);
            }
            if ((props & RecurrenceProperties.BySecond) != RecurrenceProperties.None)
            {
                s.Append(";BYSECOND");
                s.Append('=');
                OutputList(bySecond, s);
            }
            if ((props & RecurrenceProperties.ByMinute) != RecurrenceProperties.None)
            {
                s.Append(";BYMINUTE");
                s.Append('=');
                OutputList(byMinute, s);
            }
            if ((props & RecurrenceProperties.ByHour) != RecurrenceProperties.None)
            {
                s.Append(";BYHOUR");
                s.Append('=');
                OutputList(byHour, s);
            }
            if ((props & RecurrenceProperties.ByDay) != RecurrenceProperties.None)
            {
                s.Append(";BYDAY");
                s.Append('=');
                var length = byDay.Length;
                if (length > 0)
                {
                    s.Append(byDay[0]);
                }
                for (var i = 1; i < length; i++)
                {
                    s.Append(',');
                    s.Append(byDay[i].ToString());
                }
            }
            if ((props & RecurrenceProperties.ByMonthDay) != RecurrenceProperties.None)
            {
                s.Append(";BYMONTHDAY");
                s.Append('=');
                OutputList(byMonthDay, s);
            }
            if ((props & RecurrenceProperties.ByYearDay) != RecurrenceProperties.None)
            {
                s.Append(";BYYEARDAY");
                s.Append('=');
                OutputList(byYearDay, s);
            }
            if ((props & RecurrenceProperties.ByWeek) != RecurrenceProperties.None)
            {
                s.Append(";BYWEEKNO");
                s.Append('=');
                OutputList(byWeekNumber, s);
            }
            if ((props & RecurrenceProperties.ByMonth) != RecurrenceProperties.None)
            {
                s.Append(";BYMONTH");
                s.Append('=');
                OutputList(byMonth, s);
            }
            if ((props & RecurrenceProperties.BySetPosition) != RecurrenceProperties.None)
            {
                s.Append(";BYSETPOS");
                s.Append('=');
                OutputList(bySetPos, s);
            }
            if ((props & RecurrenceProperties.WeekStart) != RecurrenceProperties.None)
            {
                s.Append(";WKST");
                s.Append('=');
                s.Append(GetDayOfWeekString(workWeekStart));
            }
            return s.ToString();
        }

        #region Nested type: ByDay

        [StructLayout(LayoutKind.Sequential)]
        public struct ByDay
        {
            private int occurrenceNumber;
            private DayOfWeek day;

            public ByDay(DayOfWeek day, int occurrenceNumber)
            {
                this.day = day;
                this.occurrenceNumber = occurrenceNumber;
            }

            public int OccurrenceNumber
            {
                get { return occurrenceNumber; }
                set { occurrenceNumber = value; }
            }

            public DayOfWeek Day
            {
                get { return day; }
                set { day = value; }
            }

            public override string ToString()
            {
                var dayOfWeekString = GetDayOfWeekString(day);
                if (occurrenceNumber != 0)
                {
                    return (occurrenceNumber + dayOfWeekString);
                }
                return dayOfWeekString;
            }
        }

        #endregion
    }
}