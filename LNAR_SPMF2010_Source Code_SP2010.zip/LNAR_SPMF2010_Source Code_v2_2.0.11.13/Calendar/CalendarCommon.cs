﻿using System;

namespace DeutscheBank.SharePoint.LNAR.Framework.Calendar
{
    internal class CalendarCommon
    {
        public static string FormatDate(DateTime s)
        {
            return s.ToString("yyyyMMdd");
        }

        public static string FormatDateTime(DateTime s)
        {
            return s.ToString((s.Kind == DateTimeKind.Utc) ? @"yyyyMMdd\THHmmss\Z" : @"yyyyMMdd\THHmmss");
        }
    }
}