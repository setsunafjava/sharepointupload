﻿using System;

namespace DeutscheBank.SharePoint.LNAR.Framework.Calendar
{
    [Flags]
    public enum CalendarValueType
    {
        Binary = 2,
        Boolean = 4,
        CalAddress = 8,
        Date = 0x10,
        DateTime = 0x20,
        Duration = 0x40,
        Float = 0x80,
        Integer = 0x100,
        Period = 0x200,
        Recurrence = 0x400,
        Text = 0x800,
        Time = 0x1000,
        Unknown = 1,
        Uri = 0x2000,
        UtcOffset = 0x4000
    }
}
