﻿using System;
using System.Runtime.Serialization;

namespace DeutscheBank.SharePoint.LNAR.Framework.Calendar
{
    [Serializable]
    public class InvalidCalendarDataException : Exception
    {
        public InvalidCalendarDataException(string message)
            : base(message)
        {
        }

        protected InvalidCalendarDataException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public InvalidCalendarDataException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
