﻿using System;

namespace DeutscheBank.SharePoint.LNAR.Framework.Calendar
{
    [Flags]
    public enum ParameterId
    {
        AlternateRepresentation = 2,
        CalendarUserType = 8,
        CommonName = 4,
        Delegatee = 0x20,
        Delegator = 0x10,
        Directory = 0x40,
        Encoding = 0x80,
        FormatType = 0x100,
        FreeBusyType = 0x200,
        Language = 0x400,
        Membership = 0x800,
        ParticipationRole = 0x10000,
        ParticipationStatus = 0x1000,
        RecurrenceRange = 0x2000,
        RelationshipType = 0x8000,
        RsvpExpectation = 0x20000,
        SentBy = 0x40000,
        TimeZoneId = 0x80000,
        TriggerRelationship = 0x4000,
        Unknown = 1,
        ValueType = 0x100000
    }
}
