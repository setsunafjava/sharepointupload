﻿using System;

namespace DeutscheBank.SharePoint.LNAR.Framework.Calendar
{
    [Flags]
    public enum RecurrenceProperties
    {
        ByDay = 0x80,
        ByHour = 0x40,
        ByMinute = 0x20,
        ByMonth = 0x800,
        ByMonthDay = 0x100,
        BySecond = 0x10,
        BySetPosition = 0x1000,
        ByWeek = 0x400,
        ByYearDay = 0x200,
        Count = 4,
        Frequency = 1,
        Interval = 8,
        None = 0,
        UntilDate = 2,
        UntilDateTime = 0x4000,
        WeekStart = 0x2000
    }
}
