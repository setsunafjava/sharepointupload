﻿using System.Text;
using System.Threading;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class RestoreItemsRibbonButton : RibbonButton
    {
        private IRibbonCommand command;
        private bool hasCommand;

        public RestoreItemsRibbonButton()
            : base("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.RestoreListItems")
        {
            LabelText = LocalizationHelper.GetString("ListDataView_MS007");
            Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", Thread.CurrentThread.CurrentUICulture.LCID);
            Image32By32Top = -160;
            Image32By32Left = -224;
            ToolTipTitle = "";
            ToolTipDescription = "";

            CheckSecurity = true;
        }

        internal bool CheckSecurity { get; set; }

        public override IRibbonCommand Command
        {
            get
            {
                if (hasCommand)
                {
                    return command;
                }

                if (command == null)
                {
                    var web = SPContext.Current.Web;
                    var context = SPContext.Current;
                    if (!CheckSecurity || SecurityHelper.DoesUserHavePermissions(web, FrameworkConstants.ArchiveRoleDefinition))
                    {
                        var commandBuilder = new StringBuilder();
                        commandBuilder.Append("var ids = [];");
                        commandBuilder.Append("if(typeof getSelectedItems == 'function'){");
                        // View Framework
                        commandBuilder.Append("var items = getSelectedItems();");
                        commandBuilder.Append("$.each(items, function(i, item){ids.push( item.refId );});");
                        commandBuilder.Append("}else{");
                        // View Standard
                        commandBuilder.Append("var ctx = SP.ClientContext.get_current();");
                        commandBuilder.Append("var items = SP.ListOperation.Selection.getSelectedItems(ctx);");
                        commandBuilder.Append("for (k in items){ids.push(items[k].id);}");
                        commandBuilder.Append("}");

                        commandBuilder.AppendFormat("var url = '{0}/ArchiveList.aspx?ListId={1}&IsRestore=True&Items=';", context.Web.Url, SPContext.Current.ListId.ToString("B"));
                        commandBuilder.Append("url = url + ids.join(',');");
                        commandBuilder.Append("window.location = url;");

                        var enabledCommandBuilder = new StringBuilder();
                        enabledCommandBuilder.Append("eval(\"");
                        enabledCommandBuilder.Append("if(typeof getSelectedItems == 'function'){getSelectedItems().length > 0}else{");
                        enabledCommandBuilder.Append("var ctx = SP.ClientContext.get_current(); SP.ListOperation.Selection.getSelectedItems(ctx).length > 0;");
                        enabledCommandBuilder.Append("}");
                        enabledCommandBuilder.Append("\");");

                        command = new SPRibbonCommand("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Commands.RestoreListItems", commandBuilder.ToString(), enabledCommandBuilder.ToString());
                    }

                    hasCommand = true;
                }
                return command;
            }

            set { base.Command = value; }
        }
    }
}
