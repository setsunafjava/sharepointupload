﻿using System.Text;
using System.Threading;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class RestoreRibbonButton : RibbonButton
    {
        private IRibbonCommand command;
        private bool hasCommand;

        public RestoreRibbonButton()
            : base("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.RestoreList")
        {
            LabelText = LocalizationHelper.GetString("ListDataView_MS005");
            Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", Thread.CurrentThread.CurrentUICulture.LCID);
            Image32By32Top = -160;
            Image32By32Left = -224;
            ToolTipTitle = "";
            ToolTipDescription = "";

            CheckSecurity = true;
        }

        internal bool CheckSecurity { get; set; }

        public override IRibbonCommand Command
        {
            get
            {
                if (hasCommand)
                {
                    return command;
                }

                if (command == null)
                {
                    var web = SPContext.Current.Web;
                    if (!CheckSecurity || SecurityHelper.DoesUserHavePermissions(web, FrameworkConstants.ArchiveRoleDefinition))
                    {
                        var commandBuilder = string.Format("window.location = '{0}/ArchiveList.aspx?ListId={1}&IsRestore=True';", web.Url, SPContext.Current.ListId);
                        command = new SPRibbonCommand("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Commands.RestoreList", commandBuilder, "true");
                    }

                    hasCommand = true;
                }
                return command;
            }
            set
            {
                command = value;
                hasCommand = true;
            }
        }
    }
}