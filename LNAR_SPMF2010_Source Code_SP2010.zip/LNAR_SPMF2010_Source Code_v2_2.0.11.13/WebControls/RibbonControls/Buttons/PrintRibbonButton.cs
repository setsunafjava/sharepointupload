﻿using System;
using System.Text;
using System.Web.UI;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    /// <summary>
    ///   Represents a Print ribbon button control.
    /// </summary>
    /// <remarks>
    ///   If in form context, print current item. Otherwise, print selected items in view context.
    /// </remarks>
    public class PrintRibbonButton : RibbonButton
    {
        private IRibbonCommand command;

        public PrintRibbonButton(Page page, string id) : base(id)
        {
            LabelText = LocalizationHelper.GetString("ListDataView_MS003");
            Image32By32 = page.ClientScript.GetWebResourceUrl(GetType(), FrameworkConstants.WebResources.Images.Print);
            Image32By32Top = 0;
            Image32By32Left = 0;
            ToolTipTitle = "";
            ToolTipDescription = "";
        }

        public override IRibbonCommand Command
        {
            get
            {
                if (command == null)
                {
                    var context = SPContext.Current;
                    var builder = new StringBuilder();

                    string enabledStatement;

                    if (context.FormContext != null && context.FormContext.FormMode != SPControlMode.Invalid)
                    {
                        // Form mode
                        builder.AppendFormat("var url = '{0}/PrintPreview.aspx?Items=[{1}:{2}]';", context.Web.Url,
                                             context.ListId, context.ItemId);
                        enabledStatement = "true";
                    }
                    else if (context.ViewContext != null && context.ViewContext.View != null)
                    {
                        if (IsCustomDataView)
                        {
                            builder.Append("var items = getSelectedItems();");
                            builder.AppendFormat("var url = '{0}/PrintPreview.aspx?Items=';", context.Web.Url);
                            builder.Append("var arr = [];");
                            builder.Append(
                                "$.each(items, function(i, item){arr.push('[' + item.refListId + ':' + item.refId + ']');});");
                            builder.Append("url = url + arr.join(',');");

                            enabledStatement = "(getSelectedItems().length > 0)";
                        }
                        else
                        {
                            var listId = context.ListId;

                            builder.Append("var ctx = SP.ClientContext.get_current();");
                            builder.Append("var items = SP.ListOperation.Selection.getSelectedItems(ctx);");
                            builder.AppendFormat("var url = '{0}/PrintPreview.aspx?Items=';", context.Web.Url);
                            builder.Append("var arr = [];");
                            builder.AppendFormat(
                                "$.each(items, function(i, item){{arr.push('[' + {0} + ':' + item.id + ']');}});",
                                listId);
                            builder.Append("url = url + arr.join(',');");

                            enabledStatement = "(SP.ListOperation.Selection.getSelectedItems(SP.ClientContext.get_current()) > 0)";
                        }
                    }
                    else
                    {
                        throw new ArgumentException("The context is not support print preview.");
                    }

                    if (PrintTemplate != null)
                    {
                        builder.AppendFormat("url = url + '&{0}';", PrintTemplate);
                    }

                    builder.Append(
                        "window.open(url, 'PrintPreview', 'toolbar=no,menubar=no,location=yes,scrollbars=yes,resizable=yes');");

                    command = new SPRibbonCommand("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Commands.PrintItems",
                                                  builder.ToString(), enabledStatement);
                }
                return command;
            }
            set { base.Command = value; }
        }

        /// <summary>
        ///   Gets or sets a value indicating whether the current view is custom data view.
        /// </summary>
        public bool IsCustomDataView { get; set; }

        public DataViewTemplateOption PrintTemplate { get; set; }
    }
}