﻿using System;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    [Serializable]
    [Obsolete]
    public class RibbonPostBackEventArgs : EventArgs
    {
        public string Id;
        public object[] Args;
    }
}
