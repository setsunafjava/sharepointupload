﻿namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public enum RibbonSectionType
    {
        OneRow,
        TwoRow,
        ThreeRow,
    }
}