﻿namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public enum RibbonAlignment
    {
        Top,
        Middle,
    }
}