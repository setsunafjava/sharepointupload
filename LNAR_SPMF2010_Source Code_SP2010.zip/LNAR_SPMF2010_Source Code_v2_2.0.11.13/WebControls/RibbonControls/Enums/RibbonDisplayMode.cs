﻿namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public enum RibbonDisplayMode
    {
        Small,
        Medium,
        Large,
    }
}