﻿namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public enum RibbonSize
    {
        Large,
        LargeLarge,
        LargeMedium,
        LargeSmall,
        Medium,
        MediumSmall,
        MediumMedium,
        Small,
        Popup,
        OneLargeTwoMedium,
    }
}