﻿using System.Collections.Generic;
using System.Web.UI;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class PropertySheetSection : Control
    {
        public PropertySheetSection()
        {
            SectionControls = new List<PropertySheetControl>();
        }

        public string Header { get; set; }

        public string Description { get; set; }

        public event PropertySheetSectionEventHandler SectionRender;

        public IList<PropertySheetControl> SectionControls { get; private set; }

        protected virtual void OnSectionRender(HtmlTextWriter writer)
        {
            if (SectionRender != null)
            {
                SectionRender(writer);
            }
        }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-descriptiontext");
            writer.AddAttribute(HtmlTextWriterAttribute.Valign, "top");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            RenderLeftSection(writer);
            writer.RenderEndTag(); // td

            writer.AddAttribute(HtmlTextWriterAttribute.Align, "left");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols ms-inputformcontrols");
            writer.AddAttribute(HtmlTextWriterAttribute.Valign, "top");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            RenderRightSection(writer);
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr
        }

        private void RenderRightSection(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            // Row #1
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "9");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"9\" height=\"7\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"150\" height=\"7\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
            writer.RenderEndTag(); // td

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "10");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"10\" height=\"1\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            // Row #2
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.RenderEndTag(); // td

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            // Render table from here
            if (SectionRender != null)
            {
                OnSectionRender(writer);    
            }
            else
            {
                RenderChildren(writer);
            }

            writer.RenderEndTag(); // td

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "10");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"10\" height=\"1\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            // Row #3
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"150\" height=\"13\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            writer.RenderEndTag(); // table
        }

        private void RenderLeftSection(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "1");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            // Row #1
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Height, "22");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-sectionheader");
            writer.AddAttribute(HtmlTextWriterAttribute.Valign, "top");
            writer.AddAttribute(HtmlTextWriterAttribute.Style, "padding-top: 4px;");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-standardheader ms-inputformheader");
            writer.RenderBeginTag(HtmlTextWriterTag.H3);
            writer.Write(Header);
            writer.RenderEndTag();

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            // Row #2
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-descriptiontext ms-inputformdescription");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(Description);
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"8\" height=\"1\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            // Row #3
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"150\" height=\"19\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            writer.RenderEndTag(); // table
        }

        protected override void RenderChildren(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
            writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            foreach (var sectionControl in SectionControls)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
                writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write(sectionControl.Label);
                writer.RenderEndTag(); // span
                writer.RenderEndTag(); // td

                writer.RenderEndTag(); // tr

                writer.RenderBeginTag(HtmlTextWriterTag.Tr);
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.Write("<img width=\"1\" height=\"3\" style=\"display: block;\" alt=\"\" src=\"/_layouts/images/blank.gif\" />");
                writer.RenderEndTag(); // td
                writer.RenderEndTag(); // tr

                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.AddAttribute(HtmlTextWriterAttribute.Width, "11");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.Write("<img width=\"11\" height=\"1\" style=\"display: block;\" alt=\"\" src=\"/_layouts/images/blank.gif\" />");
                writer.RenderEndTag(); // td

                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
                writer.AddAttribute(HtmlTextWriterAttribute.Width, "99%");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);

                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                sectionControl.Control.RenderControl(writer);
                writer.RenderEndTag(); // span

                if (!string.IsNullOrEmpty(sectionControl.ErrorMessage))
                {
                    writer.AddStyleAttribute(HtmlTextWriterStyle.Color, "red");
                    writer.RenderBeginTag(HtmlTextWriterTag.Span);
                    writer.Write("<br/>");
                    writer.RenderBeginTag(HtmlTextWriterTag.Span);
                    writer.Write(sectionControl.ErrorMessage);
                    writer.RenderEndTag(); // span
                    writer.RenderEndTag(); // span
                }

                writer.RenderEndTag(); // td

                writer.RenderEndTag(); // tr

                writer.RenderBeginTag(HtmlTextWriterTag.Tr);
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.Write("<img width=\"1\" height=\"6\" style=\"display: block;\" alt=\"\" src=\"/_layouts/images/blank.gif\" />");
                writer.RenderEndTag(); // td
                writer.RenderEndTag(); // tr
            }

            writer.RenderEndTag(); // table
        }
    }

    public delegate void PropertySheetSectionEventHandler(HtmlTextWriter writer);
}