﻿using System.Web.UI;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class PropertySheetControl
    {
        public PropertySheetControl(string label, Control control)
        {
            Label = label;
            Control = control;
        }

        public string Label { get; private set; }

        public Control Control { get; private set; }

        public string ErrorMessage { get; set; }
    }
}