﻿using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class PropertySheet : Control
    {
        public PropertySheet()
        {
            Buttons = new List<Button>();
            Sections = new List<PropertySheetSection>();
        }

        private IList<Button> Buttons { get; set; }

        private IList<PropertySheetSection> Sections { get; set; }

        public void AddButton(Button button)
        {
            Buttons.Add(button);
            Controls.Add(button);
        }

        public void AddSection(PropertySheetSection section)
        {
            Sections.Add(section);
            Controls.Add(section);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "propertysheet");
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);

            // Row #1
            RenderSectionOneLine(writer);

            var index = 1;
            foreach (var section in Sections)
            {
                section.RenderControl(writer);

                // Row end of section
                if (index < Sections.Count)
                {
                    RenderSectionOneLine(writer);    
                }
                else
                {
                    RenderSectionTwoLine(writer);    
                }
                index++;
            }

            #region Row

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Height, "10");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-descriptiontext");
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "1");
            writer.AddAttribute(HtmlTextWriterAttribute.Height, "10");
            writer.AddAttribute(HtmlTextWriterAttribute.Alt, "");
            writer.AddAttribute(HtmlTextWriterAttribute.Src, "/_layouts/images/blank.gif");
            writer.RenderBeginTag(HtmlTextWriterTag.Img);
            writer.RenderEndTag(); // img

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            #endregion

            #region Buttons

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            RenderButtons(writer);

            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            #endregion

            #region Row

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Height, "40");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-descriptiontext s4-notdlg");
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "1");
            writer.AddAttribute(HtmlTextWriterAttribute.Height, "40");
            writer.AddAttribute(HtmlTextWriterAttribute.Alt, "");
            writer.AddAttribute(HtmlTextWriterAttribute.Src, "/_layouts/images/blank.gif");
            writer.RenderBeginTag(HtmlTextWriterTag.Img);
            writer.RenderEndTag(); // img

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            #endregion

            writer.RenderEndTag(); // tbody

            writer.RenderEndTag(); // table
        }

        private static void RenderSectionTwoLine(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Height, "2");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-sectionline");
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "1");
            writer.AddAttribute(HtmlTextWriterAttribute.Height, "1");
            writer.AddAttribute(HtmlTextWriterAttribute.Alt, "");
            writer.AddAttribute(HtmlTextWriterAttribute.Src, "/_layouts/images/blank.gif");
            writer.RenderBeginTag(HtmlTextWriterTag.Img);
            writer.RenderEndTag(); // img

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr
        }

        private void RenderButtons(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            // colgroup
            writer.RenderBeginTag(HtmlTextWriterTag.Colgroup);

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "99%");
            writer.RenderBeginTag(HtmlTextWriterTag.Col);
            writer.RenderEndTag(); // col

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "1%");
            writer.RenderBeginTag(HtmlTextWriterTag.Col);
            writer.RenderEndTag(); // col

            writer.RenderEndTag(); // colgroup

            // tbody
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("&nbsp;");
            writer.RenderEndTag(); // td

            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            foreach (var button in Buttons)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-ButtonHeightWidth");
                button.RenderControl(writer);
                writer.Write("&nbsp;");
            }

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr
            writer.RenderEndTag(); // tbody

            writer.RenderEndTag(); // table
        }

        private static void RenderSectionOneLine(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Height, "1");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-sectionline");
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "1");
            writer.AddAttribute(HtmlTextWriterAttribute.Height, "1");
            writer.AddAttribute(HtmlTextWriterAttribute.Alt, "");
            writer.AddAttribute(HtmlTextWriterAttribute.Src, "/_layouts/images/blank.gif");
            writer.RenderBeginTag(HtmlTextWriterTag.Img);
            writer.RenderEndTag(); // img

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr
        }
    }
}