﻿using System;
using System.Collections.Specialized;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class DialogBox : WebControl, IPostBackDataHandler
    {
        private Image btnShowDialog;
        private bool focus;
        private HiddenField hdfDialogSectionUrl;
        
        /// <summary>
        ///   Collection of choices, separated by ;#
        /// </summary>
        public string Choices { get; set; }

        public override string CssClass
        {
            get
            {
                var value = ViewState["CssClass"];
                return value == null ? "ms-long" : value.ToString();
            }
            set { ViewState["CssClass"] = value; }
        }

        public string IconUrl
        {
            get
            {
                var value = ViewState["IconUrl"];
                return value == null ? "/_layouts/images/edit.gif" : value.ToString();
            }
            set { ViewState["IconUrl"] = value; }
        }

        public string DialogTitle
        {
            get
            {
                var value = ViewState["DialogTitle"];
                return value == null ? string.Empty : value.ToString();
            }
            set { ViewState["DialogTitle"] = value; }
        }

        public bool AllowMultipleValues
        {
            get
            {
                var value = ViewState["AllowMultipleValues"];
                if (value != null)
                {
                    return (bool) value;
                }
                return false;
            }
            set { ViewState["AllowMultipleValues"] = value; }
        }

        public bool AllowFillInValue
        {
            get
            {
                var value = ViewState["AllowFillInValue"];
                if (value != null)
                {
                    return (bool) value;
                }
                return false;
            }
            set { ViewState["AllowFillInValue"] = value; }
        }

        public string LookupList
        {
            get
            {
                var value = ViewState["LookupList"];
                return value == null ? string.Empty : value.ToString();
            }
            set { ViewState["LookupList"] = value; }
        }

        public string LookupField
        {
            get
            {
                var value = ViewState["LookupField"];
                return value == null ? string.Empty : value.ToString();
            }
            set { ViewState["LookupField"] = value; }
        }

        public bool LookupWithHighPermission
        {
            get
            {
                var value = ViewState["LookupWithHighPermission"];
                if (value != null)
                {
                    return (bool) value;
                }
                return false;
            }
            set { ViewState["LookupWithHighPermission"] = value; }
        }

        public string WhereCondition
        {
            get
            {
                var value = ViewState["WhereCondition"];
                return value == null ? string.Empty : value.ToString();
            }
            set { ViewState["WhereCondition"] = value; }
        }

        public string SeparateCharacter
        {
            get
            {
                var value = ViewState["SeparateCharacter"];
                return value == null ? string.Empty : value.ToString();
            }
            set { ViewState["SeparateCharacter"] = value; }
        }

        public bool AutoPostBack
        {
            get
            {
                var value = ViewState["AutoPostBack"];
                if (value != null)
                {
                    return (bool) value;
                }
                return false;
            }
            set { ViewState["AutoPostBack"] = value; }
        }

        public bool CombineDataSources
        {
            get
            {
                var value = ViewState["CombineDataSources"];
                if (value != null)
                {
                    return (bool) value;
                }
                return false;
            }
            set { ViewState["CombineDataSources"] = value; }
        }

        public string Value
        {
            get
            {
                var value = ViewState["Value"];
                if (value != null)
                {
                    return (string) value;
                }
                return string.Empty;
            }
            set { ViewState["Value"] = value; }
        }

        public int Rows
        {
            get
            {
                var value = ViewState["Rows"];
                if (value != null)
                {
                    return (int) value;
                }
                return 1;
            }
            set { ViewState["Rows"] = value; }
        }

        public bool MultiLine
        {
            get
            {
                var value = ViewState["MultiLine"];
                if (value == null)
                {
                    return false;
                }

                return (bool) value;
            }
            set { ViewState["MultiLine"] = value; }
        }

        public bool EnableQuickSearch
        {
            get
            {
                var value = ViewState["EnableQuickSearch"];
                if (value == null)
                {
                    return false;
                }

                return (bool) value;
            }
            set { ViewState["EnableQuickSearch"] = value; }
        }

        #region IPostBackDataHandler Members

        public bool LoadPostData(string postDataKey, NameValueCollection postCollection)
        {
            var postData = postCollection[postDataKey];
            if (postData != Value)
            {
                Value = postData;
                return true;
            }
            return false;
        }

        public void RaisePostDataChangedEvent()
        {
            OnDataChanged();
        }

        #endregion

        public event EventHandler DataChanged;

        protected virtual void OnDataChanged()
        {
            if (DataChanged != null)
            {
                DataChanged(this, EventArgs.Empty);
            }
        }

        protected override void CreateChildControls()
        {
            hdfDialogSectionUrl = new HiddenField();
            Controls.Add(hdfDialogSectionUrl);

            btnShowDialog = new Image {ImageUrl = IconUrl};
            btnShowDialog.Style.Add(HtmlTextWriterStyle.Cursor, "pointer");
            btnShowDialog.Style.Add(HtmlTextWriterStyle.PaddingLeft, "2px");
            Controls.Add(btnShowDialog);
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            EnsureChildControls();

            var key = "DialogFieldScript_" + ID;
            if (!Page.ClientScript.IsClientScriptBlockRegistered(typeof (DialogList), key))
            {
                const string urlFormat =
                    "{0}/DialogBox.aspx?IsDlg=1&Choices={1}&AllowMultipleValues={2}&AllowFillInValue={3}&LookupList={4}&LookupField={5}&WhereCondition={6}&SeparateCharacter={7}&CombineDataSources={8}&MultiLine={9}&EnableQuickSearch={10}&LookupWithHighPermission={11}";
                var url = string.Format(urlFormat, SPContext.Current.Web.Url, SPEncode.UrlEncode(Choices),
                                        AllowMultipleValues,
                                        AllowFillInValue, SPEncode.UrlEncode(LookupList),
                                        SPEncode.UrlEncode(LookupField), SPEncode.UrlEncode(WhereCondition),
                                        SPEncode.UrlEncode(SeparateCharacter), CombineDataSources, MultiLine,
                                        EnableQuickSearch, LookupWithHighPermission);
                hdfDialogSectionUrl.Value = url;

                var script = new StringBuilder();
                script.AppendFormat("function dfShowModalDialog_{0}(){{", ID);
                script.AppendFormat("var url = $('#{0}').val();", hdfDialogSectionUrl.ClientID);
                script.AppendFormat("var value = $('#{0}').val();", ClientID);
                script.Append("value = escape(value);");
                script.Append("url = url + '&Value=' + value;");

                script.Append("var options = SP.UI.$create_DialogOptions();");
                script.Append("options.url = url;");
                script.Append("options.allowMaximize = false;");
                script.Append("options.showMaximized = false;");
                script.AppendFormat("options.title = '{0}';", DialogTitle);
                script.AppendFormat(
                    "options.dialogReturnValueCallback = Function.createDelegate(null, dfOnDialogCloseCallback_{0});",
                    ID);
                script.Append("var dialog = SP.UI.ModalDialog.showModalDialog(options);");
                script.Append("return false;");
                script.Append("}");

                script.AppendFormat("function dfOnDialogCloseCallback_{0}(result, target){{", ID);
                script.Append("if(result == SP.UI.DialogResult.OK){");
                script.AppendFormat("$('#{0}').val(target);", ClientID);
                script.AppendFormat(MultiLine
                                            ? "$('#{0}').val(target.replace(/;#/g, '\\r\\n'));"
                                            : "$('#{0}_Input').val(target.replace(/;#/g, '; '));", ClientID);

                if (AutoPostBack)
                {
                    script.Append(Page.ClientScript.GetPostBackEventReference(this, ""));
                }

                script.Append("}");
                script.Append("}");

                Page.ClientScript.RegisterClientScriptBlock(typeof (DialogList), key, script.ToString(), true);
            }

            // Client Behavior
            if (!Page.ClientScript.IsClientScriptIncludeRegistered(Page.GetType(), "Client_Behavior"))
            {
                var src = Page.ClientScript.GetWebResourceUrl(GetType(), FrameworkConstants.WebResources.Scripts.DialogBoxBehavior);
                Page.ClientScript.RegisterClientScriptInclude(Page.GetType(), "Client_Behavior", src);
            }

            if (focus)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "Focus", string.Format("$(document).ready(function(){{$('#{0}_ShowModalDialog').focus();}});", ClientID), true);
            }
        }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID + "_Input");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, CssClass);
            writer.AddAttribute(HtmlTextWriterAttribute.ReadOnly, "readonly");
            if (!Width.IsEmpty)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Width, Width.ToString());
            }

            if (AllowMultipleValues && MultiLine)
            {
                if (Rows > 0)
                {
                    writer.AddAttribute(HtmlTextWriterAttribute.Rows, Rows.ToString());
                }
                writer.RenderBeginTag(HtmlTextWriterTag.Textarea);
                writer.Write(Value.Replace(";#", "\r\n"));
                writer.RenderEndTag(); // textarea
            }
            else
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Type, "text");
                writer.AddAttribute(HtmlTextWriterAttribute.Value, Value.Replace(";#", "; "));
                writer.RenderBeginTag(HtmlTextWriterTag.Input);
                writer.RenderEndTag(); // input    
            }

            // Render hidden field value
            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID);
            writer.AddAttribute(HtmlTextWriterAttribute.Name, UniqueID);
            writer.AddAttribute(HtmlTextWriterAttribute.Value, Convert.ToString(Value));
            writer.AddAttribute(HtmlTextWriterAttribute.Type, "hidden");
            writer.RenderBeginTag(HtmlTextWriterTag.Input);
            writer.RenderEndTag();

            hdfDialogSectionUrl.RenderControl(writer);

            writer.RenderEndTag();

            writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingTop, "2px");

            if (MultiLine)
            {
                writer.AddStyleAttribute(HtmlTextWriterStyle.VerticalAlign, "top");
            }

            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            if (TabIndex > 0)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Tabindex, TabIndex.ToString());
            }

            writer.AddAttribute(HtmlTextWriterAttribute.Href, "javascript:void(0)");
            writer.AddAttribute(HtmlTextWriterAttribute.Onclick, string.Format("dfShowModalDialog_{0}();", ID));
            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID + "_ShowModalDialog");
            writer.RenderBeginTag(HtmlTextWriterTag.A);
            btnShowDialog.RenderControl(writer);
            writer.RenderEndTag(); // a
            writer.RenderEndTag(); // td

            writer.RenderEndTag();
            writer.RenderEndTag();
        }

        public override void Focus()
        {
            focus = true;
        }
    }
}