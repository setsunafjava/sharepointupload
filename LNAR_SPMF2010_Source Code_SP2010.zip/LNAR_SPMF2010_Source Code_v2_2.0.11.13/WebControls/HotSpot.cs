﻿using System.ComponentModel;
using System.Drawing.Design;
using System.Linq;
using System.Web.UI;
using System.Web.UI.Design.WebControls;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.WebControls;
using Menu = Microsoft.SharePoint.WebControls.Menu;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    [ParseChildren(true, "Items")]
    public class HotSpot : WebControl
    {
        private ListItemCollection items;
        private Menu menu;
        private MenuTemplate menuTemplate;

        [Browsable(true)]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Editor(typeof (ListItemsCollectionEditor), typeof (UITypeEditor))]
        public ListItemCollection Items
        {
            get { return items ?? (items = new ListItemCollection()); }
        }

        public string Text
        {
            get
            {
                var value = ViewState["Text"];
                return value == null ? string.Empty : value.ToString();
            }
            set { ViewState["Text"] = value; }
        }

        public HotSpotAction Action
        {
            get
            {
                var value = ViewState["Action"];
                return value == null ? HotSpotAction.OnClick : (HotSpotAction) value;
            }
            set { ViewState["Action"] = value; }
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            menuTemplate = new MenuTemplate {ID = "menuTemplateControl", CompactMode = true};
            foreach (var item in from ListItem listItem in Items
                                 select new MenuItemTemplate
                                            {
                                                Text = listItem.Text
                                            })
            {
                menuTemplate.Controls.Add(item);
            }
            Controls.Add(menuTemplate);

            menu = new Menu(Text, string.Empty)
                       {
                           UseMaximumWidth = true,
                           TemplateId = "menuTemplateControl",
                           ID = "menuControl",
                           AlignmentElementOverrideClientId = ClientID,
                       };
            Controls.Add(menu);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            menuTemplate.RenderControl(writer);

            writer.AddStyleAttribute(HtmlTextWriterStyle.Display, "none");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            menu.RenderControl(writer);
            writer.RenderEndTag();

            var showMenuScript =
                string.Format(
                    "CoreInvoke('MMU_Open',byid('{0}'), MMU_GetMenuFromClientId('{1}'),event,true, '{2}', 0); return false;",
                    menuTemplate.ClientID, menu.ClientID, ClientID);

            if (Action == HotSpotAction.OnClick)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Onclick, showMenuScript);
            }
            else
            {
                writer.AddAttribute("onmouseover", showMenuScript);
            }

            writer.AddAttribute(HtmlTextWriterAttribute.Href, "javascript:void(0)");
            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID);
            writer.RenderBeginTag(HtmlTextWriterTag.A);
            writer.Write(Text);
            writer.RenderEndTag(); // a
        }
    }

    public enum HotSpotAction
    {
        /// <summary>
        ///   Show when mouse click
        /// </summary>
        OnClick,

        /// <summary>
        ///   Show when mouse over
        /// </summary>
        OnMouseOver,
    }
}