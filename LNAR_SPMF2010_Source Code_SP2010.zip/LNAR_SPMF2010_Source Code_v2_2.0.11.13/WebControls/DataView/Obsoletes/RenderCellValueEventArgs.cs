﻿using System;
using System.Data;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    [Obsolete]
    public class RenderCellValueEventArgs : EventArgs
    {
        public RenderCellValueEventArgs(DataRow dataRow, object value)
        {
            DataRow = dataRow;
            Value = value;
            EncodeHtml = true;
        }

        public DataRow DataRow { get; private set; }

        public object Value { get; set; }

        public bool EncodeHtml { get; set; }
    }
}