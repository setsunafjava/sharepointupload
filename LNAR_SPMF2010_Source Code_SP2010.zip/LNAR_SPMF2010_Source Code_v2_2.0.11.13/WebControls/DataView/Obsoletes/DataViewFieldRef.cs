﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Web.UI;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    [ToolboxItem(false)]
    [ToolboxData("<{0}:FieldRef runat=\"server\" />")]
    [TypeConverter(typeof (ExpandableObjectConverter))]
    [Obsolete]
    public class DataViewFieldRef : Control
    {
        #region Delegates

        public delegate void RenderCellValueEventHandler(RenderCellValueEventArgs args);

        #endregion

        private const string DefaultEmptyGroupString = "(Not Categorized)";

        public DataViewFieldRef()
        {
            FieldType = DataViewFieldType.Text;
            EmptyGroupString = DefaultEmptyGroupString;
            Sortable = false;
            SortAscending = true;
            Filterable = false;
            DefaultValue = "(no title)";
            GroupingSeparateCharacter = ";#";
        }

        [NotifyParentProperty(true)]
        public string FieldName { get; set; }

        [NotifyParentProperty(true)]
        public string DisplayName { get; set; }

        [NotifyParentProperty(true)]
        public DataViewFieldType FieldType { get; set; }

        /// <summary>
        ///   Default value to show when value is null or empty, avaible on context field only
        /// </summary>
        public string DefaultValue { get; set; }

        internal bool IsLastField { get; set; }

        internal bool HasCustomCellRender
        {
            get { return RenderCellValue != null; }
        }

        #region Grouping

        public string EmptyGroupString { get; set; }

        internal DataViewFieldRef ParentGroup { get; set; }

        public bool CountGroupItems { get; set; }

        public bool GroupingByMultiValues { get; set; }

        public string GroupingSeparateCharacter { get; set; }

        #endregion

        #region Aggregations

        private string sumFormatNumber;

        public bool CountFieldData { get; set; }

        internal int Counter { get; set; }

        public bool SumFieldData { get; set; }

        internal double SumTotal { get; set; }

        public string SumFormatNumber
        {
            get { return string.IsNullOrEmpty(sumFormatNumber) ? "N0" : sumFormatNumber; }
            set { sumFormatNumber = value; }
        }

        #endregion

        #region Filter

        public bool Filterable { get; set; }

        internal bool IsFilter { get; set; }

        internal string FilterValue { get; set; }

        internal string GetFilterQuery()
        {
            return FilterValue == DefaultEmptyGroupString
                       ? string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", FieldName)
                       : string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Text'><![CDATA[{1}]]></Value></Eq>",
                                       FieldName,
                                       FilterValue);
        }

        #endregion

        #region Sort

        public bool Sortable { get; set; }

        public bool SortAscending { get; set; }

        #endregion

        #region Number

        private string numberFormat;

        [DefaultValue("N0")]
        public string NumberFormat
        {
            get { return string.IsNullOrEmpty(numberFormat) ? "N0" : numberFormat; }
            set { numberFormat = value; }
        }

        #endregion

        #region Currency

        private string currencyFormat;

        [DefaultValue("C0")]
        public string CurrencyFormat
        {
            get { return string.IsNullOrEmpty(currencyFormat) ? "C0" : currencyFormat; }
            set { currencyFormat = value; }
        }

        [DefaultValue(0)]
        public int CurrencyLocaleID { get; set; }

        #endregion

        public event RenderCellValueEventHandler RenderCellValue;

        internal virtual void OnRenderCellValue(RenderCellValueEventArgs args)
        {
            if (RenderCellValue != null)
            {
                RenderCellValue(args);
            }
        }

        protected override object SaveControlState()
        {
            var baseState = base.SaveControlState();
            var allState = new object[3];
            allState[0] = baseState;
            allState[1] = IsFilter;
            allState[2] = FilterValue;
            return allState;
        }

        protected override void LoadControlState(object savedState)
        {
            if (savedState != null)
            {
                var allState = (object[]) savedState;
                base.LoadViewState(allState[0]);
                IsFilter = (bool) allState[1];
                FilterValue = (string) allState[2];
            }
        }

        public override string ToString()
        {
            return FieldName;
        }
    }

    public class DataViewFieldRefCollectionEditor : CollectionEditor
    {
        public DataViewFieldRefCollectionEditor(Type type)
            : base(type)
        {
        }

        protected override bool CanSelectMultipleInstances()
        {
            return false;
        }

        protected override Type CreateCollectionItemType()
        {
            return typeof (DataViewFieldRef);
        }
    }
}