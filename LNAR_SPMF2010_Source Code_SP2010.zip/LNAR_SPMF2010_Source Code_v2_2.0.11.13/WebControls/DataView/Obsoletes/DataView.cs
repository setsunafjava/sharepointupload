﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing.Design;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.UI;
using System.Web.UI.WebControls;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using Menu = Microsoft.SharePoint.WebControls.Menu;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    [Obsolete]
    public class DataView : WebControl, IPostBackEventHandler
    {
        private const string EmptyValue = "(Empty)";
        private LinkButton btnNext;
        private LinkButton btnPrevious;

        private MenuTemplate contextMenuTemplate;
        private Hashtable contextMenus;
        private ArrayList groupFields;
        private MenuTemplate headerMenuTemplate;
        private List<Menu> headerMenus;
        private List<SPList> lists;
        private ArrayList sortFields;
        private ArrayList viewFields;

        #region Custom Ribbon for Users

        private readonly Hashtable ribbonGroups = new Hashtable();
        private readonly Hashtable ribbonControls = new Hashtable();

        public void AddRibbonGroup(RibbonGroup ribbonGroup, string location)
        {
            IList<RibbonGroup> groups;
            if (ribbonGroups.Contains(location))
            {
                groups = (IList<RibbonGroup>)ribbonGroups[location];
            }
            else
            {
                groups = new List<RibbonGroup>();
                ribbonGroups[location] = groups;
            }

            groups.Add(ribbonGroup);
        }

        public void AddRibbonControl(IRibbonControl ribbonControl, string location)
        {
            IList<IRibbonControl> controls;
            if (ribbonControls.Contains(location))
            {
                controls = (IList<IRibbonControl>)ribbonControls[location];
            }
            else
            {
                controls = new List<IRibbonControl>();
                ribbonControls[location] = controls;
            }

            controls.Add(ribbonControl);
        }

        private void RegisterRibbonGroups(RibbonTab ribbonTab)
        {
            if (ribbonGroups.Contains(ribbonTab.Id))
            {
                var groups = (IList<RibbonGroup>)ribbonGroups[ribbonTab.Id];
                ribbonTab.Groups.AddRange(groups);
            }
        }

        private void RegisterRibbonControls(RibbonGroup ribbonGroup)
        {
            if (ribbonControls.Contains(ribbonGroup.Id))
            {
                var controls = (IList<IRibbonControl>)ribbonControls[ribbonGroup.Id];
                ribbonGroup.Controls.AddRange(controls);
            }
        }

        #endregion

        #region Variables

        private DataTable allDataView;
        private bool disableGroup;
        private bool? enableAddNewItem;
        private bool? enableDeleteItem;
        private bool? enableEditItem;
        private bool hasNextPage;
        private string sortDir;
        private string sortField;
        private DataTable sourceDataView;
        private bool thresholdException;
        private int viewCounter;

        #endregion

        public DataView()
            : base(HtmlTextWriterTag.Table)
        {
        }

        [Browsable(true)]
        [DisplayName("ViewFields")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Editor(typeof(DataViewFieldRefCollectionEditor), typeof(UITypeEditor))]
        public ArrayList ViewFields
        {
            get { return viewFields ?? (viewFields = new ArrayList()); }
        }

        [Browsable(true)]
        [DisplayName("GroupFields")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Editor(typeof(DataViewFieldRefCollectionEditor), typeof(UITypeEditor))]
        public ArrayList GroupFields
        {
            get { return groupFields ?? (groupFields = new ArrayList()); }
        }

        [Browsable(true)]
        [DisplayName("SortFields")]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Editor(typeof(DataViewFieldRefCollectionEditor), typeof(UITypeEditor))]
        public ArrayList SortFields
        {
            get { return sortFields ?? (sortFields = new ArrayList()); }
        }

        [DefaultValue(100)]
        public int RowLimit
        {
            get
            {
                var value = ViewState["RowLimit"];
                if (value != null)
                {
                    return (int)value;
                }
                return 100;
            }
            set { ViewState["RowLimit"] = value; }
        }

        [Browsable(false)]
        [DefaultValue(1)]
        public int CurrentPage
        {
            get
            {
                var value = ViewState["CurrentPage"];
                if (value != null)
                {
                    return (int)value;
                }
                return 1;
            }
            set { ViewState["CurrentPage"] = value; }
        }

        [Browsable(true)]
        public string ListNames
        {
            get
            {
                var value = ViewState["ListNames"];
                if (value != null)
                {
                    return (string)value;
                }
                return string.Empty;
            }
            set
            {
                ViewState["ListNames"] = value;
                lists = null;
            }
        }

        public List<SPList> Lists
        {
            get
            {
                if (lists == null)
                {
                    lists = new List<SPList>();
                    var split = ListNames.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var str in split)
                    {
                        lists.Add(SPContext.Current.Web.Lists[str]);
                    }
                }
                return lists;
            }
        }

        [Browsable(true)]
        [DefaultValue(false)]
        public bool CrossList
        {
            get
            {
                var value = ViewState["CrossList"];
                if (value != null)
                {
                    return (bool)value;
                }
                return false;
            }
            set { ViewState["CrossList"] = value; }
        }

        private Hashtable ListItemCollectionPositions
        {
            get
            {
                var value = ViewState["ListItemCollectionPositions"];
                if (value != null)
                {
                    return (Hashtable)value;
                }
                value = new Hashtable();
                ViewState["ListItemCollectionPositions"] = value;
                return (Hashtable)value;
            }
        }

        [Browsable(true)]
        [DefaultValue(false)]
        public bool ShowRibbonTabs
        {
            get
            {
                var value = ViewState["ShowRibbonTabs"];
                if (value != null)
                {
                    return (bool)value;
                }
                return false;
            }
            set { ViewState["ShowRibbonTabs"] = value; }
        }

        [Browsable(true)]
        [DefaultValue(false)]
        public bool ShowTotalItems
        {
            get
            {
                var value = ViewState["ShowTotalItems"];
                if (value != null)
                {
                    return (bool)value;
                }
                return false;
            }
            set { ViewState["ShowTotalItems"] = value; }
        }

        [Browsable(true)]
        [DefaultValue("Total items:")]
        public string TotalItemsText
        {
            get
            {
                var value = ViewState["TotalItemsText"];
                if (value != null)
                {
                    return (string)value;
                }
                return "Total items:";
            }
            set { ViewState["TotalItemsText"] = value; }
        }

        [Browsable(true)]
        public string MenuField
        {
            get
            {
                var value = ViewState["MenuField"];
                if (value != null)
                {
                    return (string)value;
                }
                return string.Empty;
            }
            set
            {
                ViewState["MenuField"] = value;
                lists = null;
            }
        }

        [Browsable(false)]
        [DefaultValue(true)]
        public bool EnableAddNewItem
        {
            get
            {
                if (!enableAddNewItem.HasValue)
                {
                    enableAddNewItem = Lists[0].DoesUserHavePermissions(SPBasePermissions.AddListItems);
                }
                return enableAddNewItem.Value;
            }
            set { enableAddNewItem = value; }
        }

        [Browsable(false)]
        [DefaultValue(true)]
        public bool EnableEditItem
        {
            get
            {
                if (!enableEditItem.HasValue)
                {
                    enableEditItem = Lists[0].DoesUserHavePermissions(SPBasePermissions.EditListItems);
                }
                return enableEditItem.Value;
            }
            set { enableEditItem = value; }
        }

        [Browsable(false)]
        [DefaultValue(true)]
        public bool EnableDeleteItem
        {
            get
            {
                if (!enableDeleteItem.HasValue)
                {
                    enableDeleteItem = Lists[0].DoesUserHavePermissions(SPBasePermissions.DeleteListItems);
                }
                return enableDeleteItem.Value;
            }
            set { enableDeleteItem = value; }
        }

        public string WhereCondition
        {
            get
            {
                var value = ViewState["WhereCondition"];
                if (value != null)
                {
                    return (string)value;
                }
                return string.Empty;
            }
            set { ViewState["WhereCondition"] = value; }
        }

        private bool RequiredAggregations
        {
            get
            {
                return GroupFields.Cast<DataViewFieldRef>().Any(item => item.CountGroupItems)
                       ||
                       ViewFields.Cast<DataViewFieldRef>().Any(
                           item => item.CountFieldData || item.SumFieldData || item.Filterable);
            }
        }

        #region IPostBackEventHandler Members

        public void RaisePostBackEvent(string eventArgument)
        {
            var args = eventArgument.Split(';');
            switch (args[0])
            {
                case "FILTER":
                    if (args[1] == "CLEARFILTER")
                    {
                        var fieldName = args[2];
                        var viewField = ViewFields.Cast<DataViewFieldRef>().First(item => item.FieldName == fieldName);
                        viewField.IsFilter = false;
                        viewField.FilterValue = string.Empty;
                    }
                    else
                    {
                        var fieldName = args[1];
                        var value = args[2];
                        var viewField = ViewFields.Cast<DataViewFieldRef>().First(item => item.FieldName == fieldName);
                        viewField.IsFilter = true;
                        viewField.FilterValue = value == EmptyValue ? string.Empty : value;
                    }
                    CurrentPage = 1;
                    ListItemCollectionPositions.Clear();
                    break;
                case "_SORT":
                    sortField = args[1];
                    sortDir = args[2];
                    ListItemCollectionPositions.Clear();
                    break;
                case "_ITEMDELETE":
                    var itemId = Convert.ToInt32(args[1]);
                    var listId = new Guid(args[2]);
                    var list = SPContext.Current.Web.Lists[listId];
                    var itemToDelete = list.GetItemById(itemId);
                    itemToDelete.Delete();
                    break;
            }
        }

        #endregion

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            viewCounter = new Random(1).Next(100, 1000);

            #region Header Menu

            headerMenuTemplate = new MenuTemplate { ID = "FilterMenuTemplate", CompactMode = true };
            Controls.Add(headerMenuTemplate);

            var ascMenuItemTemplate = new MenuItemTemplate
                                          {
                                              Text = SPResource.GetString(Strings.VersionsSortAscending, new object[0]),
                                              ImageUrl =
                                                  string.Format("/_layouts/{0}/images/sortazlang.gif",
                                                                Thread.CurrentThread.CurrentUICulture.LCID),
                                              ClientOnClickScript =
                                                  Page.ClientScript.GetPostBackEventReference(this,
                                                                                              "_SORT;%FIELDNAME%;ASC")
                                          };
            headerMenuTemplate.Controls.Add(ascMenuItemTemplate);

            var descMenuItemTemplate = new MenuItemTemplate
                                           {
                                               Text =
                                                   SPResource.GetString(Strings.VersionsSortDescending, new object[0]),
                                               ImageUrl =
                                                   string.Format("/_layouts/{0}/images/sortzalang.gif",
                                                                 Thread.CurrentThread.CurrentUICulture.LCID),
                                               ClientOnClickScript =
                                                   Page.ClientScript.GetPostBackEventReference(this,
                                                                                               "_SORT;%FIELDNAME%;DESC")
                                           };
            headerMenuTemplate.Controls.Add(descMenuItemTemplate);

            headerMenuTemplate.Controls.Add(new MenuSeparatorTemplate());

            var clearFilterMenuTeplate = new MenuItemTemplate
                                             {
                                                 Text =
                                                     SPResource.GetString(Strings.ClearFilterFromField,
                                                                          new object[] { "%FIELDDISPLAYNAME%" }),
                                                 ImageUrl = "/_layouts/images/filteroffdisabled.gif",
                                                 ClientOnClickScript =
                                                     Page.ClientScript.GetPostBackEventReference(this,
                                                                                                 "FILTER;CLEARFILTER;%FIELDNAME%")
                                             };
            clearFilterMenuTeplate.Attributes["clearFilterItem"] = "true";
            headerMenuTemplate.Controls.Add(clearFilterMenuTeplate);

            headerMenus = new List<Menu>();
            var navigateUrl = string.Format("javascript:{0};",
                                            Page.ClientScript.GetPostBackEventReference(this, "_SORT;%FIELDNAME%"));

            foreach (DataViewFieldRef field in ViewFields)
            {
                var menu = new Menu(field.DisplayName, navigateUrl)
                               {
                                   SuppressBubbleIfPostback = true,
                                   UseMaximumWidth = true,
                                   TemplateId = "FilterMenuTemplate",
                                   ID = string.Concat("FilterMenu", ViewFields.IndexOf(field)),
                                   AlignmentElementOverrideClientId = string.Format("th{0}", field.FieldName),
                               };
                menu.TokenNamesAndValues.Add("FIELDDISPLAYNAME", SPHttpUtility.NoEncode(field.DisplayName));
                menu.TokenNamesAndValues.Add("FIELDNAME", SPHttpUtility.NoEncode(field.FieldName));
                headerMenus.Add(menu);
                Controls.Add(menu);
            }

            #endregion

            #region Context Menu

            contextMenuTemplate = new MenuTemplate { ID = "contextMenuTemplate", CompactMode = true };
            Controls.Add(contextMenuTemplate);

            var viewItem = new MenuItemTemplate
                               {
                                   Text = "View Item",
                                   ClientOnClickNavigateUrl =
                                       "%WEBURL%/_layouts/listform.aspx?PageType=4&ListId=%LISTID%&ID=%ITEMID%&ContentTypeID=0x0100C52A55B6DCC75D4EA7BC118149118F5C",
                                   ClientOnClickScript =
                                       "FW_OpenDisplayDialog(\"%WEBURL%/_layouts/listform.aspx?PageType=4&ListId=%LISTID%&ID=%ITEMID%&ContentTypeID=0x0100C52A55B6DCC75D4EA7BC118149118F5C\");return false;"
                               };
            contextMenuTemplate.Controls.Add(viewItem);

            var editItem = new MenuItemTemplate
                               {
                                   ID = "EditItem",
                                   Text = SPResource.GetString(Strings.ButtonTextEditItem),
                                   ImageUrl = "~/_layouts/images/edititem.gif",
                                   ClientOnClickNavigateUrl =
                                       "%WEBURL%/_layouts/listform.aspx?PageType=6&ListId=%LISTID%&ID=%ITEMID%&ContentTypeID=0x0100C52A55B6DCC75D4EA7BC118149118F5C",
                                   ClientOnClickScript =
                                       "FW_OpenDisplayDialog(\"%WEBURL%/_layouts/listform.aspx?PageType=6&ListId=%LISTID%&ID=%ITEMID%&ContentTypeID=0x0100C52A55B6DCC75D4EA7BC118149118F5C\");return false;"
                               };
            contextMenuTemplate.Controls.Add(editItem);

            contextMenuTemplate.Controls.Add(new MenuSeparatorTemplate());

            var deleteItem = new MenuItemTemplate
                                 {
                                     ID = "DeleteItem",
                                     Text = SPResource.GetString(Strings.ButtonTextDeleteItem),
                                     ImageUrl = "~/_layouts/images/delitem.gif",
                                     ClientOnClickNavigateUrl =
                                         string.Concat("javascript:if(confirm(L_STSRecycleConfirm_Text))",
                                                       Page.ClientScript.
                                                           GetPostBackEventReference(this,
                                                                                     "_ITEMDELETE;%ITEMID%;%LISTID%"))
                                 };
            contextMenuTemplate.Controls.Add(deleteItem);

            #endregion

            #region Paging

            btnPrevious = new LinkButton
                              {
                                  Text =
                                      string.Format(
                                          "<img border=\"0\" alt=\"Previous\" src=\"/_layouts/{0}/images/prev.gif\">",
                                          Thread.CurrentThread.CurrentUICulture.LCID)
                              };
            Controls.Add(btnPrevious);

            btnNext = new LinkButton
                          {
                              Text =
                                  string.Format(
                                      "<img border=\"0\" alt=\"Next\" src=\"/_layouts/{0}/images/next.gif\">",
                                      Thread.CurrentThread.CurrentUICulture.LCID)
                          };
            Controls.Add(btnNext);

            #endregion
        }

        private static string BuildViewFields(IEnumerable<string> fields)
        {
            var sb = new StringBuilder();

            foreach (var field in fields)
            {
                sb.AppendFormat("<FieldRef Name='{0}' />", field);
            }

            return sb.ToString();
        }

        private void NextPaging(object sender, EventArgs e)
        {
            CurrentPage++;
        }

        private void PreviousPaging(object sender, EventArgs e)
        {
            CurrentPage--;
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            EnsureChildControls();

            Page.RegisterRequiresControlState(this);
            foreach (DataViewFieldRef viewField in ViewFields)
            {
                Page.RegisterRequiresControlState(viewField);
            }

            btnPrevious.Click += PreviousPaging;
            btnNext.Click += NextPaging;

            if (SPContext.Current.ViewContext != null && SPContext.Current.ViewContext.View != null)
            {
                var placeHolderPageTitleInTitleArea = Page.Master.FindControl("PlaceHolderPageTitleInTitleArea");
                if (placeHolderPageTitleInTitleArea != null)
                {
                    placeHolderPageTitleInTitleArea.Controls.Add(new DataViewSelectorMenu());
                }
            }
        }

        protected override void AddAttributesToRender(HtmlTextWriter writer)
        {
            EnsureChildControls();
            base.AddAttributesToRender(writer);
            writer.AddAttribute(HtmlTextWriterAttribute.Class,
                                sourceDataView.Rows.Count > 0 ? "ms-listviewtable" : "ms-emptyView");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "100%");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "1");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute("onmouseover", string.Format("EnsureSelectionHandler(event,this,{0})", viewCounter));
            writer.AddAttribute(HtmlTextWriterAttribute.Dir, "none");
            writer.AddAttribute("handledeleteinit", "true");
        }

        public override void DataBind()
        {
            var allFields = ViewFields.Cast<DataViewFieldRef>().Where(item => item.FieldType != DataViewFieldType.AutoNumber).Union(
            GroupFields.Cast<DataViewFieldRef>()).Select(item => item.FieldName).Union(SortFields.Cast<DataViewFieldRef>().Select(item => item.FieldName)).ToList();
            allFields.Add("ID");

            var fields = allFields.Distinct().ToList();

            if (CrossList)
            {
                DataBindForCrossList(fields);
            }
            else
            {
                DataBindForStandardView(fields);
            }

            sourceDataView.Columns.Add("RowIndex", typeof(int));
            for (var i = 0; i < sourceDataView.Rows.Count; i++)
            {
                sourceDataView.Rows[i]["RowIndex"] = i;
            }
            sourceDataView.AcceptChanges();

            if (allDataView != null)
            {
                foreach (var viewField in ViewFields.Cast<DataViewFieldRef>().Where(item => item.CountFieldData))
                {
                    var fieldName = viewField.FieldName;
                    viewField.Counter = allDataView.AsEnumerable().Count(
                                    item => GetObjectData<object>(item, fieldName) != null);
                }

                foreach (var viewField in ViewFields.Cast<DataViewFieldRef>().Where(item => item.SumFieldData))
                {
                    var fieldName = viewField.FieldName;
                    viewField.SumTotal =
                        allDataView.AsEnumerable().Sum(item => GetObjectData<double>(item, fieldName));
                }
            }
        }

        private void DataBindForStandardView(IEnumerable<string> fields)
        {
            var whereCondition = "";

            try
            {
                var query = new SPQuery
                                {
                                    RowLimit = (uint)RowLimit,
                                    ViewFields = BuildViewFields(fields),
                                    QueryThrottleMode = SPQueryThrottleOption.Override
                                };

                // Where
                var sb = new StringBuilder();
                var filterCondition = new StringBuilder();
                var hasFilter = false;
                foreach (var viewField in ViewFields.Cast<DataViewFieldRef>().Where(viewField => viewField.IsFilter))
                {
                    filterCondition.Append(viewField.GetFilterQuery());
                    if (hasFilter)
                    {
                        filterCondition.Insert(0, "<And>");
                        filterCondition.Append("</And>");
                    }
                    hasFilter = true;
                }

                if (!hasFilter)
                {
                    sb.Append(WhereCondition);
                }
                else
                {
                    if (string.IsNullOrEmpty(WhereCondition))
                    {
                        sb.AppendFormat("<Where>{0}</Where>", filterCondition);
                    }
                    else
                    {
                        whereCondition = WhereCondition.Replace("<Where>", "").Replace("</Where>", "");
                        if (!string.IsNullOrEmpty(whereCondition))
                        {
                            whereCondition = string.Format("<Where><And>{0}{1}</And></Where>", filterCondition,
                                                           whereCondition);
                            sb.Append(whereCondition);
                        }
                    }
                }

                whereCondition = sb.ToString();

                var sortedFields = new List<string>();

                // GroupBy
                if (GroupFields.Count > 0)
                {
                    var groupField = (DataViewFieldRef)GroupFields[0];
                    sb.AppendFormat("<GroupBy Collapse='FALSE'>");

                    sb.AppendFormat(groupField.SortAscending
                                        ? "<FieldRef Name='{0}' />"
                                        : "<FieldRef Name='{0}' Ascending='FALSE' />", groupField.FieldName);

                    if (GroupFields.Count >= 2)
                    {
                        groupField = (DataViewFieldRef)GroupFields[1];
                        sb.AppendFormat(groupField.SortAscending
                                            ? "<FieldRef Name='{0}' />"
                                            : "<FieldRef Name='{0}' Ascending='FALSE' />", groupField.FieldName);
                    }

                    sb.Append("</GroupBy>");
                }

                sb.Append("<OrderBy>");

                if (GroupFields.Count > 2)
                {
                    for (var i = 2; i < GroupFields.Count; i++)
                    {
                        var groupField = (DataViewFieldRef)GroupFields[i];
                        if (!sortedFields.Contains(groupField.FieldName))
                        {
                            sb.AppendFormat(
                                groupField.SortAscending
                                    ? "<FieldRef Name='{0}' />"
                                    : "<FieldRef Name='{0}' Ascending='FALSE' />", groupField.FieldName);
                            sortedFields.Add(groupField.FieldName);
                        }
                    }
                }

                if (!string.IsNullOrEmpty(sortField))
                {
                    sb.AppendFormat(
                        sortDir == "ASC" ? "<FieldRef Name='{0}' />" : "<FieldRef Name='{0}' Ascending='FALSE' />",
                        sortField);
                    sortedFields.Add(sortField);
                }

                // OrderBy
                if (SortFields.Count > 0)
                {
                    foreach (
                        var field in
                            SortFields.Cast<DataViewFieldRef>().Where(field => !sortedFields.Contains(field.FieldName)))
                    {
                        sb.AppendFormat(
                            field.SortAscending
                                ? "<FieldRef Name='{0}' />"
                                : "<FieldRef Name='{0}' Ascending='FALSE' />", field.FieldName);
                    }
                }
                sb.Append("</OrderBy>");
                query.Query = sb.ToString();

                if (ListItemCollectionPositions.ContainsKey(CurrentPage))
                {
                    query.ListItemCollectionPosition =
                        new SPListItemCollectionPosition((string)ListItemCollectionPositions[CurrentPage]);
                }

                SPListItemCollection items;

                if (query.ListItemCollectionPosition == null && CurrentPage > 1)
                {
                    var pageIndex = 1;
                    do
                    {
                        items = Lists[0].GetItems(query);
                        query.ListItemCollectionPosition = items.ListItemCollectionPosition;
                        pageIndex++;

                        // Save ListItemCollectionPosition
                        if (items.ListItemCollectionPosition != null)
                        {
                            ListItemCollectionPositions[pageIndex] = items.ListItemCollectionPosition.PagingInfo;
                            hasNextPage = true;
                        }
                        else
                        {
                            hasNextPage = false;
                        }
                    } while (pageIndex <= CurrentPage);
                }
                else
                {
                    items = Lists[0].GetItems(query);
                    // Save ListItemCollectionPosition
                    if (items.ListItemCollectionPosition != null)
                    {
                        ListItemCollectionPositions[CurrentPage + 1] = items.ListItemCollectionPosition.PagingInfo;
                        hasNextPage = true;
                    }
                    else
                    {
                        hasNextPage = false;
                    }
                }

                sourceDataView = DataViewUtils.GetDataTable(items, fields);

                sourceDataView.Columns.Add("ListId", typeof(string));

                var listId = Lists[0].ID.ToString();
                foreach (DataRow row in sourceDataView.Rows)
                {
                    row["ListId"] = listId;
                }

                if (RequiredAggregations)
                {
                    try
                    {
                        var subQuery = new SPQuery
                                           {
                                               RowLimit = int.MaxValue,
                                               ViewFields = query.ViewFields,
                                               Query = query.Query,
                                               QueryThrottleMode = SPQueryThrottleOption.Override
                                           };

                        items = Lists[0].GetItems(subQuery);
                        allDataView = DataViewUtils.GetDataTable(items, fields);
                    }
                    catch (SPQueryThrottledException)
                    {
                        allDataView = null;
                    }
                }

                if (GroupFields.Cast<DataViewFieldRef>().Any(item => item.GroupingByMultiValues))
                {
                    var dt = sourceDataView.Clone();

                    foreach (
                        var groupField in
                            GroupFields.Cast<DataViewFieldRef>().Where(groupField => groupField.GroupingByMultiValues))
                    {
                        foreach (DataRow row in sourceDataView.Rows)
                        {
                            var values = Regex.Split(Convert.ToString(row[groupField.FieldName]),
                                                     groupField.GroupingSeparateCharacter);
                            if (values.Length == 1)
                            {
                                dt.ImportRow(row);
                            }
                            else
                            {
                                switch (groupField.FieldType)
                                {
                                    case DataViewFieldType.User:
                                        for (var index = 0; index < values.Length; index = index + 2)
                                        {
                                            var value = values[index] + ";#" + values[index + 1];
                                            row[groupField.FieldName] = value;
                                            row.AcceptChanges();
                                            dt.ImportRow(row);
                                        }
                                        break;
                                    default:
                                        foreach (var value in values)
                                        {
                                            row[groupField.FieldName] = value;
                                            row.AcceptChanges();
                                            dt.ImportRow(row);
                                        }
                                        break;
                                }
                            }
                        }

                        sourceDataView = dt;
                    }
                }
            }
            catch (SPQueryThrottledException)
            {
                disableGroup = true;
                var query = new SPQuery
                                {
                                    RowLimit = (uint)RowLimit,
                                    ViewFields = BuildViewFields(fields),
                                    Query =
                                        whereCondition +
                                        "<OrderBy Override='TRUE'><FieldRef Name='ID' Ascending='FALSE' /></OrderBy>",
                                    QueryThrottleMode = SPQueryThrottleOption.Override
                                };

                if (ListItemCollectionPositions.ContainsKey(CurrentPage))
                {
                    query.ListItemCollectionPosition =
                        new SPListItemCollectionPosition((string)ListItemCollectionPositions[CurrentPage]);
                }

                var items = Lists[0].GetItems(query);

                // Save ListItemCollectionPosition
                if (items.ListItemCollectionPosition != null)
                {
                    ListItemCollectionPositions[CurrentPage + 1] = items.ListItemCollectionPosition.PagingInfo;
                    hasNextPage = true;
                }
                else
                {
                    hasNextPage = false;
                }

                sourceDataView = DataViewUtils.GetDataTable(items, fields);

                sourceDataView.Columns.Add("ListId", typeof(string));

                var listId = Lists[0].ID.ToString();
                foreach (DataRow row in sourceDataView.Rows)
                {
                    row["ListId"] = listId;
                }
            }
        }

        private void DataBindForCrossList(IEnumerable<string> fields)
        {
            var startRowIndex = (CurrentPage - 1) * RowLimit;

            try
            {
                var siteDataQuery = new SPSiteDataQuery();
                var sb = new StringBuilder();

                // Lists
                sb.Append("<Lists>");
                foreach (var list in Lists)
                {
                    sb.AppendFormat("<List ID='{0}' />", list.ID.ToString("B"));
                }
                sb.Append("</Lists>");
                siteDataQuery.Lists = sb.ToString();

                // ViewFields
                siteDataQuery.ViewFields = BuildViewFields(fields);

                // Where
                sb = new StringBuilder();
                var filterCondition = new StringBuilder();
                var hasFilter = false;
                foreach (var viewField in ViewFields.Cast<DataViewFieldRef>().Where(viewField => viewField.IsFilter))
                {
                    filterCondition.Append(viewField.GetFilterQuery());
                    if (hasFilter)
                    {
                        filterCondition.Insert(0, "<And>");
                        filterCondition.Append("</And>");
                    }
                    hasFilter = true;
                }

                if (!hasFilter)
                {
                    sb.Append(WhereCondition);
                }
                else
                {
                    if (string.IsNullOrEmpty(WhereCondition))
                    {
                        sb.AppendFormat("<Where>{0}</Where>", filterCondition);
                    }
                    else
                    {
                        var whereCondition = WhereCondition.Replace("<Where>", "").Replace("</Where>", "");
                        if (!string.IsNullOrEmpty(whereCondition))
                        {
                            whereCondition = string.Format("<Where><And>{0}{1}</And></Where>", filterCondition,
                                                           whereCondition);
                            sb.Append(whereCondition);
                        }
                    }
                }

                var sortedFields = new List<string>();

                sb.Append("<OrderBy>");

                if (!string.IsNullOrEmpty(sortField))
                {
                    sb.AppendFormat(
                        sortDir == "ASC" ? "<FieldRef Name='{0}' />" : "<FieldRef Name='{0}' Ascending='FALSE' />",
                        sortField);
                    sortedFields.Add(sortField);
                }

                foreach (
                    var groupField in
                        GroupFields.Cast<DataViewFieldRef>().Where(item => !sortedFields.Contains(item.FieldName)))
                {
                    sb.AppendFormat(
                        groupField.SortAscending
                            ? "<FieldRef Name='{0}' />"
                            : "<FieldRef Name='{0}' Ascending='FALSE' />", groupField.FieldName);
                    sortedFields.Add(groupField.FieldName);
                }

                // OrderBy
                if (SortFields.Count > 0)
                {
                    foreach (
                        var field in
                            SortFields.Cast<DataViewFieldRef>().Where(field => !sortedFields.Contains(field.FieldName)))
                    {
                        sb.AppendFormat(
                            field.SortAscending
                                ? "<FieldRef Name='{0}' />"
                                : "<FieldRef Name='{0}' Ascending='FALSE' />", field.FieldName);
                    }
                }
                sb.Append("</OrderBy>");
                siteDataQuery.Query = sb.ToString();

                // Webs
                siteDataQuery.Webs = "<Webs Scope='SiteCollection' />";

                allDataView = DataViewUtils.GetDataTable(SPContext.Current.Web.GetSiteData(siteDataQuery), Lists[0], fields);

                sourceDataView = allDataView.Clone();

                for (var i = 0; i < RowLimit; i++)
                {
                    try
                    {
                        var row = allDataView.Rows[startRowIndex + i];
                        sourceDataView.ImportRow(row);
                    }
                    catch (IndexOutOfRangeException)
                    {
                        break;
                    }
                }
                sourceDataView.AcceptChanges();

                if (allDataView.Rows.Count > startRowIndex + RowLimit)
                {
                    hasNextPage = true;
                }
            }
            catch (SPQueryThrottledException)
            {
                thresholdException = true;
                return;
            }
        }

        private static T GetObjectData<T>(DataRow item, string fieldName)
        {
            var value = item[fieldName];

            if (value == null || value is DBNull)
            {
                return default(T);
            }

            if ((value is string) && string.IsNullOrEmpty(value.ToString()))
            {
                return default(T);
            }

            try
            {
                return (T)value;
            }
            catch (InvalidCastException)
            {
                return default(T);
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            DataBind();

            // function FW_OnChildColumn);
            if (!Page.ClientScript.IsClientScriptBlockRegistered("FW_OnChildColumn"))
            {
                var fncOnChildColumn = new StringBuilder();
                fncOnChildColumn.BeginFunction("function FW_OnChildColumn(elm)");

                fncOnChildColumn.Append("var i;");
                fncOnChildColumn.BeginFunction("for (i=0; i < elm.childNodes.length; i++)");
                fncOnChildColumn.Append("var child=elm.childNodes[i];");

                fncOnChildColumn.BeginFunction(
                    "if (child.nodeType==1 && child.tagName==\"DIV\" && child.getAttribute(\"CtxNum\") !=null)");
                fncOnChildColumn.Append("DeferCall('FW_OnMouseOverFilter', child);break;");
                fncOnChildColumn.EndFunction();

                fncOnChildColumn.EndFunction();

                fncOnChildColumn.EndFunction();

                Page.ClientScript.RegisterClientScriptBlock(GetType(), "FW_OnChildColumn", fncOnChildColumn.ToString(),
                                                            true);
            }

            // function FW_OnMouseOverFilter
            if (!Page.ClientScript.IsClientScriptBlockRegistered("FW_OnMouseOverFilter"))
            {
                var fncOnMouseOverFilter = new StringBuilder();
                fncOnMouseOverFilter.BeginFunction("function FW_OnMouseOverFilter(elm)");
                fncOnMouseOverFilter.Append("if (!IsFilterMenuEnabled()) return false;");
                fncOnMouseOverFilter.Append("if (IsFilterMenuOn() || bMenuLoadInProgress) return false;");
                fncOnMouseOverFilter.Append("if (window.location.href.search(\"[?&]Filter=1\") !=-1) return false;");
                fncOnMouseOverFilter.Append("if (elm.FilterDisable==\"TRUE\") return false;");
                fncOnMouseOverFilter.Append("if (IsFieldNotFilterable(elm) && IsFieldNotSortable(elm)) return false;");
                fncOnMouseOverFilter.Append("if (filterTable==elm) return;");
                fncOnMouseOverFilter.Append("if (filterTable !=null) FW_OnMouseOutFilter();");
                fncOnMouseOverFilter.Append("filterTable=elm;");
                fncOnMouseOverFilter.Append("var isTable=filterTable.tagName==\"TABLE\";");

                fncOnMouseOverFilter.BeginFunction("if (isTable)");
                fncOnMouseOverFilter.Append("filterTable.className=\"ms-selectedtitle\";");
                fncOnMouseOverFilter.Append("filterTable.onmouseout=FW_OnMouseOutFilter;");
                fncOnMouseOverFilter.EndFunction();

                fncOnMouseOverFilter.BeginFunction("else");
                fncOnMouseOverFilter.Append("var par=filterTable.parentNode;");
                fncOnMouseOverFilter.Append("par.onmouseout=FW_OnMouseOutFilter;");
                fncOnMouseOverFilter.Append("CreateCtxImg(par, FW_OnMouseOutFilter);");
                fncOnMouseOverFilter.EndFunction();

                fncOnMouseOverFilter.EndFunction();

                Page.ClientScript.RegisterClientScriptBlock(GetType(), "FW_OnMouseOverFilter",
                                                            fncOnMouseOverFilter.ToString(), true);
            }

            // function FW_OnMouseOutFilter
            if (!Page.ClientScript.IsClientScriptBlockRegistered("FW_OnMouseOutFilter"))
            {
                Page.ClientScript.RegisterClientScriptBlock(GetType(), "FW_OnMouseOutFilter",
                                                            "function FW_OnMouseOutFilter(evt){OnMouseOutFilter(evt);}",
                                                            true);
            }

            // function FW_ShowHideGroup
            if (!Page.ClientScript.IsClientScriptBlockRegistered("FW_ShowHideGroup"))
            {
                var fncShowHideGroup = new StringBuilder();
                fncShowHideGroup.BeginFunction("function FW_ShowHideGroup(groupId)");
                fncShowHideGroup.Append("var self = $(\"tbody[groupId=\" + groupId + \"]\");");
                fncShowHideGroup.Append("var ex = $(\"tbody[groupId^=\" + groupId + \"-\" + \"]\");");
                fncShowHideGroup.Append("var isCollapsed = self.attr('isCollapsed');");

                fncShowHideGroup.BeginFunction("if(isCollapsed == 'false')");
                fncShowHideGroup.Append("self.attr('isCollapsed', 'true');");
                fncShowHideGroup.Append(
                    "$(\"img[groupId=\" + groupId + \"]\").attr('src', '/_layouts/images/plus.gif');");

                fncShowHideGroup.Append("$.each(ex, function(index, value){");
                fncShowHideGroup.Append("$(this).hide();");
                fncShowHideGroup.Append("var hideByGroupId = $(this).attr('hideByGroupId');");
                fncShowHideGroup.Append(
                    "if(hideByGroupId == undefined || hideByGroupId == ''){$(this).attr('hideByGroupId', groupId);}");
                fncShowHideGroup.Append("});");

                fncShowHideGroup.EndFunction();

                fncShowHideGroup.BeginFunction("else");
                fncShowHideGroup.Append("self.attr('isCollapsed', 'false');");
                fncShowHideGroup.Append(
                    "$(\"img[groupId=\" + groupId + \"]\").attr('src', '/_layouts/images/minus.gif');");

                fncShowHideGroup.Append("$.each(ex, function(index, value){");
                fncShowHideGroup.Append("var _this = $(this);");
                fncShowHideGroup.BeginFunction("if(_this.attr('hideByGroupId') + '' == groupId)");
                fncShowHideGroup.Append("_this.show();");
                fncShowHideGroup.Append("_this.attr('hideByGroupId', '');");
                fncShowHideGroup.EndFunction();
                fncShowHideGroup.Append("});");

                fncShowHideGroup.EndFunction();

                fncShowHideGroup.EndFunction();
                Page.ClientScript.RegisterClientScriptBlock(GetType(), "FW_ShowHideGroup", fncShowHideGroup.ToString(),
                                                            true);
            }

            // function FW_ToggleCheckBox
            if (!Page.ClientScript.IsClientScriptBlockRegistered("FW_ToggleCheckBox"))
            {
                var fncToggleCheckBox = new StringBuilder();
                fncToggleCheckBox.BeginFunction("function FW_ToggleCheckBox(elm)");
                fncToggleCheckBox.Append("if(event.srcElement.tagName.toLowerCase() == 'a') return;");
                fncToggleCheckBox.Append("$(elm).toggleClass('s4-itm-selected');");

                fncToggleCheckBox.BeginFunction("if($(elm).hasClass('s4-itm-selected'))");
                fncToggleCheckBox.Append("$(\"input[type='checkbox']\", $(elm)).attr('checked', 'checked');");
                fncToggleCheckBox.EndFunction();

                fncToggleCheckBox.BeginFunction("else");
                fncToggleCheckBox.Append("$(\"input[type='checkbox']\", $(elm)).removeAttr('checked');");
                fncToggleCheckBox.EndFunction();

                fncToggleCheckBox.Append("RibbonCustomization.PageComponent.refreshRibbonStatus();");
                fncToggleCheckBox.EndFunction();
                Page.ClientScript.RegisterClientScriptBlock(GetType(), "FW_ToggleCheckBox", fncToggleCheckBox.ToString(),
                                                            true);
            }

            // function FW_OpenDisplayDialog
            if (!Page.ClientScript.IsClientScriptBlockRegistered("FW_OpenDisplayDialog"))
            {
                var fncOpenDisplayDialog = new StringBuilder();
                fncOpenDisplayDialog.BeginFunction("function FW_OpenDisplayDialog(url, e)");
                fncOpenDisplayDialog.Append("url = url + '';");
                fncOpenDisplayDialog.Append("var options = SP.UI.$create_DialogOptions();");
                fncOpenDisplayDialog.Append("options.url = url;");
                fncOpenDisplayDialog.Append(
                    "options.dialogReturnValueCallback = Function.createDelegate(null, function(result, target){if(result == SP.UI.DialogResult.OK){SP.UI.ModalDialog.RefreshPage(SP.UI.DialogResult.OK);}});");
                fncOpenDisplayDialog.Append("SP.UI.ModalDialog.showModalDialog(options);");

                // Cancel default event
                fncOpenDisplayDialog.BeginFunction("if(e != undefined)");
                fncOpenDisplayDialog.Append("var eventObject = jQuery.Event(e);");
                fncOpenDisplayDialog.Append("eventObject.preventDefault();");
                fncOpenDisplayDialog.Append("eventObject.isDefaultPrevented();");
                fncOpenDisplayDialog.Append("eventObject.stopPropagation();");
                fncOpenDisplayDialog.Append("eventObject.isPropagationStopped();");
                fncOpenDisplayDialog.Append("eventObject.stopImmediatePropagation();");
                fncOpenDisplayDialog.Append("eventObject.isImmediatePropagationStopped();");
                fncOpenDisplayDialog.EndFunction();

                fncOpenDisplayDialog.Append("return false;");
                fncOpenDisplayDialog.EndFunction();

                Page.ClientScript.RegisterClientScriptBlock(GetType(), "FW_OpenDisplayDialog",
                                                            fncOpenDisplayDialog.ToString(), true);
            }

            // function FW_ToggleAllItems
            if (!Page.ClientScript.IsClientScriptBlockRegistered("FW_ToggleAllItems"))
            {
                var fncToggleAllItems = new StringBuilder();
                fncToggleAllItems.BeginFunction("function FW_ToggleAllItems(obj, ctx)");
                fncToggleAllItems.Append("var checked = $(obj).attr('checked');");

                fncToggleAllItems.BeginFunction("if(checked == true)");
                fncToggleAllItems.Append("$(\"tr[class*='ms-itmhover'][ctx='\" + ctx + \"']\").click();");
                fncToggleAllItems.EndFunction();

                fncToggleAllItems.BeginFunction("else");
                fncToggleAllItems.Append("$(\"tr[class*='s4-itm-selected'][ctx='\" + ctx + \"']\").click();");
                fncToggleAllItems.EndFunction();

                fncToggleAllItems.EndFunction();
                Page.ClientScript.RegisterClientScriptBlock(GetType(), "FW_ToggleAllItems", fncToggleAllItems.ToString(),
                                                            true);
            }

            // function FW_OnItem
            if (!Page.ClientScript.IsClientScriptBlockRegistered("FW_OnItem"))
            {
                var fncOnItem = new StringBuilder();
                fncOnItem.BeginFunction("function FW_OnItem(elm)");
                fncOnItem.Append("OnItem(elm);");
                fncOnItem.Append("var div = $(\"div.s4-ctx\", $(elm).parent());");
                fncOnItem.Append("var altclick = div.attr('altclick');");
                fncOnItem.Append("div.unbind().click(function(){eval(altclick);});");
                fncOnItem.EndFunction();

                Page.ClientScript.RegisterClientScriptBlock(GetType(), "FW_OnItem", fncOnItem.ToString(), true);
            }

            // function FW_BindDataForMenu
            if (!Page.ClientScript.IsClientScriptBlockRegistered("FW_BindDataForMenu"))
            {
                var fncBindDataForMenu = new StringBuilder();
                fncBindDataForMenu.BeginFunction(
                    "function FW_BindDataForMenu(menuTemplateId, menuId, fieldName, values, clientId)");
                fncBindDataForMenu.Append("var menuTemplate = document.getElementById(menuTemplateId);");
                fncBindDataForMenu.Append("var menu = MMU_GetMenuFromClientId(menuId);");
                fncBindDataForMenu.Append("var items = values.split(';#');");
                fncBindDataForMenu.Append("if(values == ';;No Filder') items = [];");

                // Remove old items
                fncBindDataForMenu.BeginFunction(
                    "for(var menuIndex=0; menuIndex < menuTemplate.childNodes.length; menuIndex++)");
                fncBindDataForMenu.Append("var menuChild=menuTemplate.childNodes[menuIndex];");

                fncBindDataForMenu.BeginFunction("if(menuChild.nodeName != '#text')");
                fncBindDataForMenu.Append(
                    "if (menuChild.getAttribute('isFilterItem')=='true'){menuTemplate.removeChild(menuChild);--menuIndex;}");
                fncBindDataForMenu.EndFunction();

                fncBindDataForMenu.EndFunction();

                // Add new items
                fncBindDataForMenu.BeginFunction("for(menuIndex = 0; menuIndex < items.length; menuIndex++)");
                fncBindDataForMenu.Append(
                    "var script = \"__doPostBack('\" + clientId + \"','FILTER;' + '\" + fieldName + \"' + \" + \"';' + '\" + items[menuIndex] + \"')\";");
                fncBindDataForMenu.Append("menuItem = CAMOpt(menuTemplate, items[menuIndex], script);");
                fncBindDataForMenu.Append("menuItem.setAttribute('isFilterItem', 'true');");
                fncBindDataForMenu.EndFunction();

                fncBindDataForMenu.EndFunction();
                Page.ClientScript.RegisterClientScriptBlock(GetType(), "FW_BindDataForMenu",
                                                            fncBindDataForMenu.ToString(), true);
            }

            // function getSelectedItems: return id collection of selected items
            var fncGetSelectedItems = new StringBuilder();
            fncGetSelectedItems.BeginFunction("function getSelectedItems()");
            fncGetSelectedItems.Append("var result = [];");
            fncGetSelectedItems.Append("var selected = $(\"input[type='checkbox'][class='s4-itm-cbx']:checked\");");
            fncGetSelectedItems.Append(
                "$.each(selected, function(index,value){var refId = $(value).attr('refId'); var refListId = $(value).attr('refListId');result.push({refListId:refListId,refId:refId});});");
            fncGetSelectedItems.Append("return result;");
            fncGetSelectedItems.EndFunction();
            Page.ClientScript.RegisterClientScriptBlock(GetType(), "getSelectedItems", fncGetSelectedItems.ToString(),
                                                        true);

            // Set last field for ViewFields
            ViewFields.Cast<DataViewFieldRef>().Last().IsLastField = true;

            // Build group tree
            for (var i = 1; i < GroupFields.Count; i++)
            {
                var groupField = (DataViewFieldRef)GroupFields[i];
                groupField.ParentGroup = (DataViewFieldRef)GroupFields[i - 1];
            }

            base.OnPreRender(e);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (thresholdException)
            {
                var maxQueryLookupFields = SPContext.Current.Site.WebApplication.MaxItemsPerThrottledOperation;
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write(SPResource.GetString("DataViewThrottleText", new object[] { maxQueryLookupFields }));
                writer.RenderEndTag(); // span
                return;
            }

            if (disableGroup)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write("This group by feature is disabled because throttled exception has throws.");
                writer.RenderEndTag(); // span
            }

            headerMenuTemplate.RenderControl(writer);
            contextMenuTemplate.RenderControl(writer);

            // Hidden div container menu
            writer.AddStyleAttribute(HtmlTextWriterStyle.Display, "none");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);

            foreach (var headerMenu in headerMenus)
            {
                headerMenu.RenderControl(writer);
            }

            contextMenus = new Hashtable();

            var disabledMenuItemIds = new List<string>();

            if (!EnableEditItem)
            {
                disabledMenuItemIds.Add("EditItem");
            }

            if (!EnableDeleteItem)
            {
                disabledMenuItemIds.Add("DeleteItem");
            }

            foreach (DataRow item in sourceDataView.Rows)
            {
                var contextMenu = new Menu("")
                                      {
                                          SuppressBubbleIfPostback = false,
                                          UseMaximumWidth = true,
                                          TemplateId = "contextMenuTemplate",
                                          ID = string.Format("itemContextMenu_{0}_{1}_{2}", item["ListId"], item["ID"], item["RowIndex"]).Replace("-", "")
                                      };

                if (disabledMenuItemIds.Count > 0)
                {
                    contextMenu.DisabledMenuItemIds = string.Join(",", disabledMenuItemIds.ToArray());
                }

                contextMenu.TokenNamesAndValues.Add("WEBURL", SPContext.Current.Web.Url);
                contextMenu.TokenNamesAndValues.Add("LISTID", item["ListId"].ToString());
                contextMenu.TokenNamesAndValues.Add("ITEMID", item["ID"].ToString());
                contextMenus.Add(string.Format("{0}_{1}_{2}", item["ListId"], item["ID"], item["RowIndex"]), contextMenu);
                Controls.Add(contextMenu);
                contextMenu.RenderControl(writer);
            }

            writer.RenderEndTag(); // div

            RenderBeginTag(writer);

            // Header
            RenderHeader(writer);

            if (GroupFields.Count > 0 && !disableGroup)
            {
                var groupField = (DataViewFieldRef)GroupFields[0];
                IEnumerable<IGrouping<object, DataRow>> groups;
                switch (groupField.FieldType)
                {
                    case DataViewFieldType.DateOnly:
                        groups = sourceDataView.AsEnumerable().GroupBy(g => g[groupField.FieldName],
                                                                       new DateOnlyComparer());
                        break;
                    default:
                        groups = sourceDataView.AsEnumerable().GroupBy(g => g[groupField.FieldName]);
                        break;
                }

                var groupId = 0;

                foreach (var @group in groups)
                {
                    groupId++;
                    var predicate = PredicateBuilderExtensions.True<DataRow>();
                    // Begin with group level is 1
                    RenderGroup(writer, groupField, 1, groupId.ToString(), @group, predicate);
                }
            }
            else
            {
                // Rows
                RenderRows(writer, "0", sourceDataView.AsEnumerable());
            }

            if (sourceDataView.Rows.Count == 0 && CurrentPage == 1)
            {
                RenderEmptyData(writer);
            }

            // Sum
            if (allDataView != null && ViewFields.Cast<DataViewFieldRef>().Any(item => item.SumFieldData))
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Tbody);
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                // Empty cell
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.RenderEndTag(); // td

                foreach (DataViewFieldRef viewField in ViewFields)
                {
                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb2");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    if (viewField.SumFieldData)
                    {
                        var fieldName = viewField.FieldName;
                        var sum = allDataView.AsEnumerable().Sum(item => GetObjectData<double>(item, fieldName));
                        writer.RenderBeginTag(HtmlTextWriterTag.Nobr);
                        writer.RenderBeginTag(HtmlTextWriterTag.B);
                        writer.Write(string.Format("Total = {0}", sum.ToString(viewField.SumFormatNumber)));
                        writer.RenderEndTag(); // b
                        writer.RenderEndTag(); // nobr
                    }
                    writer.RenderEndTag(); // td
                }

                writer.RenderEndTag(); // tr
                writer.RenderEndTag(); // tbody
            }

            if (ShowTotalItems && allDataView != null)
            {
                RenderTotalItems(writer);
            }

            RenderEndTag(writer);

            if (CurrentPage > 1)
            {
                RenderPaging(writer);
            }
            else
            {
                if (hasNextPage)
                {
                    RenderPaging(writer);
                }
            }

            RenderEndLine(writer);

            if (EnableAddNewItem)
            {
                RenderAddNewLink(writer);
            }
        }

        private void RenderTotalItems(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "100");
            writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingLeft, "15px");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.RenderBeginTag(HtmlTextWriterTag.B);
            writer.Write("{0} {1}", TotalItemsText, allDataView.Rows.Count);
            writer.RenderEndTag(); // b

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr
            writer.RenderEndTag(); // tbody
        }

        private void RenderEmptyData(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "100");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(string.Format("There are no items to show in this view of the \"{0}\" list.", Lists[0].Title));
            if (EnableAddNewItem)
            {
                writer.Write(" To add a new item, click \"New\".");
            }
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr
            writer.RenderEndTag(); // tbody
        }

        private void RenderAddNewLink(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-addnew");
            writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingBottom, "3px");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "s4-clust");
            writer.AddAttribute(HtmlTextWriterAttribute.Style,
                                "position: relative; width: 10px; display: inline-block; height: 10px; overflow: hidden;");
            writer.RenderBeginTag(HtmlTextWriterTag.Span);
            writer.Write(
                "<img style=\"position: absolute; top: -128px !important; left: 0px !important;\" alt=\"\" src=\"/_layouts/images/fgimg.png\" />");
            writer.RenderEndTag(); // span

            var href = string.Format("{0}/_layouts/listform.aspx?PageType=8&ListId={1}", SPContext.Current.Web.Url,
                                     Lists[0].ID);
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-addnew");
            writer.AddAttribute(HtmlTextWriterAttribute.Href, href);
            writer.AddAttribute(HtmlTextWriterAttribute.Onclick,
                                string.Format("NewItem2(event, '{0}'); return false;", href));
            writer.AddStyleAttribute(HtmlTextWriterStyle.MarginLeft, "3px");
            writer.RenderBeginTag(HtmlTextWriterTag.A);
            writer.Write("Add new item");
            writer.RenderEndTag();

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr
            writer.RenderEndTag(); // table
        }

        private static void RenderEndLine(HtmlTextWriter writer)
        {
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "100%");
            writer.AddAttribute(HtmlTextWriterAttribute.Id, "Hero-WPQ1");
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-partline");
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"1\" height=\"1\" alt=\"\" src=\"/_layouts/images/blank.gif\" />");
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            // Add new item

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"1\" height=\"5\" alt=\"\" src=\"/_layouts/images/blank.gif\" />");
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            writer.RenderEndTag(); // tbody
            writer.RenderEndTag(); // table
        }

        private void RenderPaging(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-bottompaging");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "100%");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-bottompagingline1");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"1\" height=\"1\" alt=\"\" src=\"/_layouts/images/blank.gif\">");
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-bottompagingline2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"1\" height=\"1\" alt=\"\" src=\"/_layouts/images/blank.gif\">");
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Id, "bottomPagingCellWPQ1");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb");
            writer.AddAttribute(HtmlTextWriterAttribute.Align, "center");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            if (CurrentPage > 1)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                btnPrevious.RenderControl(writer);
                writer.RenderEndTag(); // td    
            }

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-paging");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            var startItem = (CurrentPage * RowLimit) - RowLimit + 1;
            var endItem = startItem + RowLimit - 1;
            if (!hasNextPage)
            {
                endItem = startItem + sourceDataView.Rows.Count - 1;
            }

            writer.Write(string.Format("{0} - {1}", startItem, endItem));
            writer.RenderEndTag(); // td

            if (hasNextPage)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                btnNext.RenderControl(writer);
                writer.RenderEndTag(); // td
            }

            writer.RenderEndTag(); // tr
            writer.RenderEndTag(); // tbody
            writer.RenderEndTag(); // table

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-bottompagingline3");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"1\" height=\"1\" alt=\"\" src=\"/_layouts/images/blank.gif\">");
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            writer.RenderEndTag(); // tbody

            writer.RenderEndTag(); // table
        }

        private void RenderGroup(HtmlTextWriter writer, DataViewFieldRef groupField, int groupLevel, string groupId,
                                 IGrouping<object, DataRow> @group, Expression<Func<DataRow, bool>> filter)
        {
            Func<DataRow, bool> whereCondition = null;

            writer.AddAttribute("groupId", groupId);
            writer.AddAttribute("isCollapsed", "false");
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, groupLevel == 1 ? "ms-gb" : "ms-gb2");
            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "100");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            for (var i = 1; i < groupLevel; i++)
            {
                writer.Write("<img width=\"10\" height=\"1\" alt=\"\" src=\"/_layouts/images/blank.gif\" />");
            }

            writer.AddAttribute(HtmlTextWriterAttribute.Href, "javascript:void(0)");
            writer.AddStyleAttribute(HtmlTextWriterStyle.TextDecoration, "none");
            writer.AddAttribute(HtmlTextWriterAttribute.Onclick, string.Format("FW_ShowHideGroup('{0}')", groupId));
            writer.RenderBeginTag(HtmlTextWriterTag.A);

            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Src, "/_layouts/images/minus.gif");
            writer.AddAttribute("groupId", groupId);
            writer.RenderBeginTag(HtmlTextWriterTag.Img);
            writer.RenderEndTag();

            writer.Write("&nbsp;");
            writer.Write(groupField.DisplayName);

            writer.RenderEndTag(); // a

            if (!string.IsNullOrEmpty(groupField.DisplayName))
            {
                writer.Write("&nbsp;:&nbsp;");    
            }

            string groupHeader;

            switch (groupField.FieldType)
            {
                case DataViewFieldType.User:
                case DataViewFieldType.Calculated:
                    if (@group.Key is double)
                    {
                        groupHeader = ((double) group.Key).ToString(groupField.NumberFormat);
                    }
                    else
                    {
                        groupHeader = Convert.ToString(@group.Key);    
                    }
                    
                    if (string.IsNullOrEmpty(groupHeader))
                    {
                        groupHeader = groupField.EmptyGroupString;
                    }
                    writer.Write(groupHeader);
                    break;
                case DataViewFieldType.DateOnly:
                    DateTime dt;
                    if (@group.Key is DateTime)
                    {
                        dt = (DateTime)@group.Key;
                    }
                    else
                    {
                        DateTime.TryParse(@group.Key.ToString(), CultureInfo.InvariantCulture, DateTimeStyles.None,
                                          out dt);
                    }

                    groupHeader = dt == DateTime.MinValue ? groupField.EmptyGroupString : dt.ToShortDateString();
                    writer.Write(groupHeader);
                    break;
                default:
                    groupHeader = Convert.ToString(@group.Key);
                    if (string.IsNullOrEmpty(groupHeader))
                    {
                        groupHeader = groupField.EmptyGroupString;
                    }
                    writer.Write(SPEncode.HtmlEncode(groupHeader));
                    break;
            }

            if (allDataView != null)
            {
                switch (groupField.FieldType)
                {
                    case DataViewFieldType.DateOnly:
                        if (group.Key == null)
                        {
                            filter = filter.And(item => GetObjectData<object>(item, groupField.FieldName) == null);
                        }
                        filter = filter.And(item => Compare((DateTime)group.Key, GetObjectData<DateTime>(item, groupField.FieldName), true));
                        break;
                    default:
                        var groupKey = group.Key is DBNull ? string.Empty : Convert.ToString(group.Key);
                        filter = string.IsNullOrEmpty(groupKey)
                                     ? filter.And(item => string.IsNullOrEmpty(GetObjectData<string>(item, groupField.FieldName)))
                                     : filter.And(item => GetObjectData<string>(item, groupField.FieldName) == groupKey);
                        break;
                }

                whereCondition = filter.Compile();

                if (groupField.CountGroupItems)
                {
                    var groupItemsCounter = allDataView.AsEnumerable().Count(whereCondition);

                    writer.AddStyleAttribute("font-weight", "lighter");
                    writer.RenderBeginTag(HtmlTextWriterTag.Span);
                    writer.Write(string.Format("&nbsp;({0})", groupItemsCounter));
                    writer.RenderEndTag(); // span        
                }
            }

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr
            writer.RenderEndTag(); // tbody

            // Render group counter (check if group required has counter and any column had counter)
            if (allDataView != null && groupField.CountFieldData &&
                ViewFields.Cast<DataViewFieldRef>().Any(item => item.CountFieldData))
            {
                writer.AddAttribute("groupId", groupId + "-counter");
                writer.RenderBeginTag(HtmlTextWriterTag.Tbody);
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                // Empty cell
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.RenderEndTag(); // td

                foreach (DataViewFieldRef viewField in ViewFields)
                {
                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb2");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    if (viewField.CountFieldData)
                    {
                        var fieldName = viewField.FieldName;

                        var countCondition = filter.And(item => GetObjectData<object>(item, fieldName) != null);

                        writer.RenderBeginTag(HtmlTextWriterTag.Nobr);
                        writer.RenderBeginTag(HtmlTextWriterTag.B);
                        writer.Write(string.Format("Count = {0}",
                                                   allDataView.AsEnumerable().Count(countCondition.Compile())));
                        writer.RenderEndTag(); // b
                        writer.RenderEndTag(); // nobr
                    }
                    writer.RenderEndTag(); // td
                }

                writer.RenderEndTag(); // tr
                writer.RenderEndTag(); // tbody
            }

            if (groupLevel < GroupFields.Count)
            {
                var nextGroupField = (DataViewFieldRef)GroupFields[groupLevel];

                var groups = @group.GroupBy(g => g[nextGroupField.FieldName]);
                var nextGroupId = 0;
                foreach (var nextGroup in groups)
                {
                    nextGroupId++;
                    RenderGroup(writer, nextGroupField, groupLevel + 1, string.Format("{0}-{1}", groupId, nextGroupId),
                                nextGroup, filter);
                }
            }
            else
            {
                RenderRows(writer, groupId + "-all", group);
            }

            // Sum
            if (allDataView != null && groupField.SumFieldData &&
                ViewFields.Cast<DataViewFieldRef>().Any(item => item.SumFieldData))
            {
                writer.AddAttribute("groupId", groupId + "-sum");
                writer.RenderBeginTag(HtmlTextWriterTag.Tbody);
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                // Empty cell
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.RenderEndTag(); // td

                foreach (DataViewFieldRef viewField in ViewFields)
                {
                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb2");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    if (viewField.SumFieldData)
                    {
                        var fieldName = viewField.FieldName;
                        var sum =
                            allDataView.AsEnumerable().Where(whereCondition).Sum(
                                item => GetObjectData<double>(item, fieldName));
                        writer.RenderBeginTag(HtmlTextWriterTag.Nobr);
                        writer.RenderBeginTag(HtmlTextWriterTag.B);
                        writer.Write(string.Format("Total = {0}", sum.ToString(viewField.SumFormatNumber)));
                        writer.RenderEndTag(); // b
                        writer.RenderEndTag(); // nobr
                    }
                    writer.RenderEndTag(); // td
                }

                writer.RenderEndTag(); // tr
                writer.RenderEndTag(); // tbody
            }
        }

        private void RenderRows(HtmlTextWriter writer, string groupId, IEnumerable<DataRow> items)
        {
            writer.AddAttribute("groupId", groupId);
            writer.AddAttribute("isCollapsed", "false");
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);

            var altRow = false;
            var rowIndex = 1;
            foreach (var item in items)
            {
                RenderRow(writer, item, altRow, string.Format("{0}-{1}", groupId, rowIndex));
                rowIndex++;
                altRow = !altRow;
            }
            writer.RenderEndTag(); // tbody
        }

        private void RenderRow(HtmlTextWriter writer, DataRow item, bool alt, string rowId)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Class, alt ? "ms-itmhover ms-alternating" : "ms-itmhover");
            writer.AddAttribute(HtmlTextWriterAttribute.Onclick, "FW_ToggleCheckBox(this)");
            writer.AddAttribute("ctx", viewCounter.ToString());
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb-itmcbx ms-vb-firstCell");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "s4-itm-cbx");
            writer.AddAttribute(HtmlTextWriterAttribute.Type, "checkbox");
            writer.AddAttribute("refListId", item["ListId"].ToString());
            writer.AddAttribute("refId", item["ID"].ToString());
            writer.RenderBeginTag(HtmlTextWriterTag.Input);
            writer.RenderEndTag(); // input

            writer.RenderEndTag(); // td

            foreach (DataViewFieldRef field in ViewFields)
            {
                RenderCell(writer, field, item, rowId);
            }

            writer.RenderEndTag(); // tr
        }

        private void RenderCell(HtmlTextWriter writer, DataViewFieldRef fieldRef, DataRow item, string rowId)
        {
            var web = SPContext.Current.Web;
            var isMenuCell = fieldRef.FieldName == MenuField;
            if (isMenuCell)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Class,
                                    fieldRef.IsLastField ? "ms-vb-title ms-vb-lastCell" : "ms-vb-title");

                writer.AddAttribute("onmouseover", "FW_OnChildColumn(this)");
                writer.AddAttribute(HtmlTextWriterAttribute.Id, string.Format("td_{0}_{1}", fieldRef.FieldName, rowId));
            }
            else
            {
                switch (fieldRef.FieldType)
                {
                    case DataViewFieldType.Number:
                    case DataViewFieldType.Currency:
                        writer.AddStyleAttribute(HtmlTextWriterStyle.TextAlign, "right");
                        break;
                }
                writer.AddAttribute(HtmlTextWriterAttribute.Class, fieldRef.IsLastField ? "ms-vb2 ms-vb-lastCell" : "ms-vb2");
            }

            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            var args = new RenderCellValueEventArgs(item, item[fieldRef.FieldName]);
            fieldRef.OnRenderCellValue(args);

            switch (fieldRef.FieldType)
            {
                case DataViewFieldType.AutoNumber:
                    var rowIndex = (int)item["RowIndex"];
                    writer.Write(rowIndex + 1);
                    break;
                case DataViewFieldType.Attachments:
                    var hasAttachments = (bool)args.Value;
                    writer.Write(hasAttachments
                                     ? "<img title=\"Attachment\" class=\"ms-vb-lvitemimg\" alt=\"Attachment\" src=\"/_layouts/images/attach.gif\" border=\"0\" />"
                                     : "&nbsp;");
                    break;
                case DataViewFieldType.DocumentIcon:
                    writer.Write(string.Format("<img alt='' src='/_layouts/images/{0}' />",
                                               SPUtility.MapToIcon(web, Convert.ToString(item[fieldRef.FieldName]), string.Empty, IconSize.Size16)));
                    break;
                case DataViewFieldType.User:
                    var split = Convert.ToString(item[fieldRef.FieldName]).Split(new[] { ";#" }, StringSplitOptions.None);
                    if (split.Length == 0)
                    {
                        writer.Write("&nbsp;");
                    }
                    else if (split.Length == 1)
                    {
                        writer.Write(split[0]);
                    }
                    else
                    {
                        var webUrl = web.Url;
                        for (var i = 0; i < split.Length; i = i + 2)
                        {
                            var href = string.Format("{0}/_layouts/userdisp.aspx?ID={1}", webUrl, split[i]);
                            writer.AddAttribute(HtmlTextWriterAttribute.Onclick,
                                                string.Format("return FW_OpenDisplayDialog('{0}', event);", href));
                            writer.AddAttribute(HtmlTextWriterAttribute.Href, href);
                            writer.RenderBeginTag(HtmlTextWriterTag.A);
                            writer.Write(split[i + 1]);
                            writer.RenderEndTag();

                            if ((i + 2) < split.Length)
                            {
                                writer.Write(";&nbsp;");
                            }
                        }
                    }
                    break;
                case DataViewFieldType.Note:
                    if (args.Value == null)
                    {
                        writer.Write("&nbsp;");
                    }
                    else
                    {
                        writer.Write(args.Value);
                    }
                    break;
                case DataViewFieldType.Lookup:
                    if (args.Value == null)
                    {
                        writer.Write("&nbsp;");
                    }
                    else
                    {
                        var list = web.Lists[new Guid((string)item["ListId"])];
                        var lookupField = (SPFieldLookup)list.Fields.GetFieldByInternalName(fieldRef.FieldName);
                        var rawUrl = SPEncode.UrlEncode(Page.Request.RawUrl);

                        if (args.Value is SPFieldLookupValueCollection)
                        {
                            var values = (SPFieldLookupValueCollection)args.Value;
                            var index = 0;
                            foreach (var lookupValue in values)
                            {
                                writer.AddAttribute(HtmlTextWriterAttribute.Href,
                                                    string.Format(
                                                        "{0}/_layouts/listform.aspx?PageType=4&ListId={1}&ID={2}&Source={3}",
                                                        web.Url, lookupField.LookupList, lookupValue.LookupId, rawUrl));
                                writer.AddAttribute(HtmlTextWriterAttribute.Onclick,
                                                    "return FW_OpenDisplayDialog(this, event);");
                                writer.RenderBeginTag(HtmlTextWriterTag.A);
                                writer.Write(SPEncode.HtmlEncode(lookupValue.LookupValue));
                                writer.RenderEndTag();

                                if (index < values.Count - 1)
                                {
                                    writer.Write(";&nbsp;");
                                }

                                index++;
                            }
                        }
                        else
                        {
                            var splitLookup = Convert.ToString(args.Value).Split(new[] { ";#" }, StringSplitOptions.None);
                            if (splitLookup.Length == 2)
                            {
                                writer.AddAttribute(HtmlTextWriterAttribute.Href,
                                                    string.Format("{0}/_layouts/listform.aspx?PageType=4&ListId={1}&ID={2}&Source={3}",
                                                        web.Url, lookupField.LookupList, splitLookup[0], rawUrl));
                                writer.AddAttribute(HtmlTextWriterAttribute.Onclick,
                                                    "return FW_OpenDisplayDialog(this, event);");
                                writer.RenderBeginTag(HtmlTextWriterTag.A);
                                writer.Write(SPEncode.HtmlEncode(splitLookup[1]));
                                writer.RenderEndTag();
                            }
                            else
                            {
                                writer.Write("&nbsp;");
                            }
                        }
                    }
                    break;
                default:
                    string value;

                    if (!fieldRef.HasCustomCellRender)
                    {
                        if (args.Value == null || args.Value is DBNull)
                        {
                            value = string.Empty;
                        }
                        else
                        {
                            switch (fieldRef.FieldType)
                            {
                                case DataViewFieldType.DateOnly:
                                    var dt = (DateTime)args.Value;
                                    // ShortDatePattern
                                    value = dt.ToString("d", web.Locale);
                                    break;
                                case DataViewFieldType.DateTime:
                                    var dt2 = (DateTime)args.Value;
                                    // General date/time pattern (short time).
                                    value = dt2.ToString("g", web.Locale);
                                    break;
                                case DataViewFieldType.Currency:
                                    CultureInfo cultureInfo;
                                    if (fieldRef.CurrencyLocaleID == 0 ||
                                        fieldRef.CurrencyLocaleID == web.CurrencyLocaleID)
                                    {
                                        cultureInfo = web.Locale;
                                    }
                                    else
                                    {
                                        try
                                        {
                                            cultureInfo = CultureInfo.GetCultureInfo(fieldRef.CurrencyLocaleID);
                                            cultureInfo.NumberFormat.CurrencyDecimalSeparator =
                                                web.Locale.NumberFormat.CurrencyDecimalSeparator;
                                            cultureInfo.NumberFormat.CurrencyGroupSeparator =
                                                web.Locale.NumberFormat.CurrencyGroupSeparator;
                                        }
                                        catch (Exception)
                                        {
                                            cultureInfo = web.Locale;
                                        }
                                    }

                                    value = Convert.ToDouble(args.Value).ToString(fieldRef.CurrencyFormat, cultureInfo);
                                    break;
                                case DataViewFieldType.Number:
                                    value = Convert.ToDouble(args.Value).ToString(fieldRef.NumberFormat, web.Locale);
                                    break;
                                case DataViewFieldType.Boolean:
                                    if ((bool)args.Value)
                                    {
                                        value = "Yes";
                                    }
                                    else
                                    {
                                        value = "No";
                                    }
                                    break;
                                case DataViewFieldType.Calculated:
                                    if (args.Value is double)
                                    {
                                        value = Convert.ToDouble(args.Value).ToString(fieldRef.NumberFormat, web.Locale);
                                    }
                                    else
                                    {
                                        value = Convert.ToString(args.Value);
                                    }
                                    break;
                                default:
                                    value = Convert.ToString(args.Value);
                                    break;
                            }
                        }
                    }
                    else
                    {
                        value = Convert.ToString(args.Value);
                    }

                    if (isMenuCell)
                    {
                        var contextMenu =
                            (Menu)
                            contextMenus[string.Format("{0}_{1}_{2}", item["ListId"], item["ID"], item["RowIndex"])];
                        var showMenuScript = string.Format(
                            "CoreInvoke('MMU_Open',byid('{0}'), MMU_GetMenuFromClientId('{1}'),event,true, 'td_{2}_{3}', 0);",
                            contextMenuTemplate.ClientID, contextMenu.ClientID, fieldRef.FieldName, rowId);

                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb");
                        writer.AddAttribute("onmouseover", "FW_OnItem(this)");
                        writer.AddAttribute("ctxname", viewCounter.ToString());
                        writer.RenderBeginTag(HtmlTextWriterTag.Div);

                        writer.AddAttribute(HtmlTextWriterAttribute.Href,
                                            string.Format(
                                                "{0}/_layouts/listform.aspx?PageType=4&ListId={1}&ID={2}&ContentTypeID=0x0100C52A55B6DCC75D4EA7BC118149118F5C&Source={3}",
                                                web.Url, item["ListId"], item["ID"],
                                                SPEncode.UrlEncode(Page.Request.RawUrl)));
                        writer.AddAttribute(HtmlTextWriterAttribute.Onclick, "return FW_OpenDisplayDialog(this, event);");
                        writer.RenderBeginTag(HtmlTextWriterTag.A);

                        if (string.IsNullOrEmpty(value))
                        {
                            value = fieldRef.DefaultValue;
                        }

                        writer.Write(SPEncode.HtmlEncode(value));

                        writer.RenderEndTag(); // a

                        writer.RenderEndTag(); // div

                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "s4-ctx");
                        writer.AddAttribute("altclick", showMenuScript);
                        writer.RenderBeginTag(HtmlTextWriterTag.Div);
                        writer.Write("<span>&nbsp;</span>");

                        writer.AddAttribute(HtmlTextWriterAttribute.Title, "Open Menu");
                        writer.AddAttribute(HtmlTextWriterAttribute.Href, "javascript:void(0)");
                        writer.RenderBeginTag(HtmlTextWriterTag.A);
                        writer.RenderEndTag();

                        writer.Write("<span>&nbsp;</span>");
                        writer.RenderEndTag(); // div
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(value))
                        {
                            writer.Write("&nbsp;");
                        }
                        else
                        {
                            writer.Write(args.EncodeHtml ? SPEncode.HtmlEncode(value) : value);
                        }
                    }
                    break;
            }

            writer.RenderEndTag(); // td
        }

        private void RenderHeader(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-viewheadertr ms-vhltr");
            writer.AddAttribute(HtmlTextWriterAttribute.Valign, "top");
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            // Th
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vh-icon");
            writer.AddAttribute(HtmlTextWriterAttribute.Scope, "col");
            writer.RenderBeginTag(HtmlTextWriterTag.Th);

            writer.AddAttribute(HtmlTextWriterAttribute.Type, "checkbox");
            writer.AddAttribute("onclick", string.Format("FW_ToggleAllItems(this, '{0}')", viewCounter));
            writer.AddAttribute(HtmlTextWriterAttribute.Title, "Select or deselect all items");
            writer.RenderBeginTag(HtmlTextWriterTag.Input);
            writer.RenderEndTag(); // input

            writer.RenderEndTag(); // th

            foreach (DataViewFieldRef viewField in ViewFields)
            {
                RenderHeaderField(writer, viewField);
            }

            writer.RenderEndTag(); // tr

            if (allDataView != null && ViewFields.Cast<DataViewFieldRef>().Any(item => item.CountFieldData))
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                // Empty td
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.RenderEndTag();

                foreach (DataViewFieldRef viewField in ViewFields)
                {
                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb2");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    if (viewField.CountFieldData)
                    {
                        writer.RenderBeginTag(HtmlTextWriterTag.Nobr);
                        writer.RenderBeginTag(HtmlTextWriterTag.B);
                        writer.Write(string.Format("Count = {0}", viewField.Counter));
                        writer.RenderEndTag(); // b
                        writer.RenderEndTag(); // nobr
                    }
                    writer.RenderEndTag();
                }

                writer.RenderEndTag(); // tr
            }

            writer.RenderEndTag(); // tbody
        }

        private void RenderHeaderField(HtmlTextWriter writer, DataViewFieldRef fieldRef)
        {
            switch (fieldRef.FieldType)
            {
                case DataViewFieldType.AutoNumber:
                case DataViewFieldType.Note:
                    fieldRef.Sortable = false;
                    fieldRef.Filterable = false;
                    break;
                case DataViewFieldType.File:
                    fieldRef.Filterable = false;
                    break;
            }

            var showMenuScript = new StringBuilder();
            if (fieldRef.Filterable || fieldRef.Sortable)
            {
                var headerMenu = headerMenus[ViewFields.IndexOf(fieldRef)];

                if (fieldRef.Filterable && allDataView != null)
                {
                    var values =
                        allDataView.AsEnumerable().Select(item => GetObjectData<string>(item, fieldRef.FieldName)).
                            Distinct().ToList();
                    values.Sort();
                    if (values.Count > 0)
                    {
                        if (string.IsNullOrEmpty(values[0]))
                        {
                            values[0] = EmptyValue;
                        }
                    }
                    showMenuScript.AppendFormat("FW_BindDataForMenu('{0}','{1}','{2}','{3}','{4}');",
                                                headerMenuTemplate.ClientID, headerMenu.ClientID, fieldRef.FieldName,
                                                string.Join(";#", values.ToArray()), UniqueID);
                }
                else
                {
                    showMenuScript.AppendFormat("FW_BindDataForMenu('{0}','{1}','{2}','{3}','{4}');",
                                                headerMenuTemplate.ClientID, headerMenu.ClientID, fieldRef.FieldName,
                                                ";;No Filder", UniqueID);
                }

                showMenuScript.AppendFormat(
                    "CoreInvoke('MMU_Open',byid('{0}'), MMU_GetMenuFromClientId('{1}'),event,true, 'th{2}', 0); return false;",
                    headerMenuTemplate.ClientID, headerMenu.ClientID, fieldRef.FieldName);
            }

            switch (fieldRef.FieldType)
            {
                case DataViewFieldType.Attachments:
                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vh-icon");
                    writer.AddAttribute(HtmlTextWriterAttribute.Nowrap, "nowrap");
                    writer.AddAttribute("onmouseover", "FW_OnChildColumn(this)");
                    writer.AddAttribute(HtmlTextWriterAttribute.Scope, "col");
                    writer.AddAttribute(HtmlTextWriterAttribute.Id, string.Format("th{0}", fieldRef.FieldName));
                    writer.RenderBeginTag(HtmlTextWriterTag.Th);

                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vh-div");
                    writer.AddAttribute(HtmlTextWriterAttribute.Name, "Attachments");
                    writer.AddAttribute("ctxnum", viewCounter.ToString());
                    writer.RenderBeginTag(HtmlTextWriterTag.Div);

                    writer.AddAttribute(HtmlTextWriterAttribute.Id, "diidSortAttachments");
                    writer.AddAttribute(HtmlTextWriterAttribute.Onclick, "return false;");
                    writer.AddAttribute("onfocus", "OnFocusFilter(this)");
                    writer.AddAttribute(HtmlTextWriterAttribute.Href, "javascript:void(0)");
                    writer.RenderBeginTag(HtmlTextWriterTag.A);

                    writer.AddAttribute(HtmlTextWriterAttribute.Src, "/_layouts/images/attachhd.gif");
                    writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
                    writer.RenderBeginTag(HtmlTextWriterTag.Img);
                    writer.RenderEndTag();

                    if (fieldRef.FieldName == sortField)
                    {
                        writer.Write(sortDir == "ASC"
                                         ? "<img alt=\"Ascending\" src=\"/_layouts/images/sort.gif\" border=\"0\" />"
                                         : "<img alt=\"Descending\" src=\"/_layouts/images/rsort.gif\" border=\"0\" />");
                    }

                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-hidden");
                    writer.AddAttribute(HtmlTextWriterAttribute.Width, "1");
                    writer.AddAttribute(HtmlTextWriterAttribute.Height, "1");
                    writer.AddAttribute(HtmlTextWriterAttribute.Border, "1");
                    writer.AddAttribute(HtmlTextWriterAttribute.Alt, "Use SHIFT+ENTER to open the menu (new window).");
                    writer.AddAttribute(HtmlTextWriterAttribute.Src, "/_layouts/images/blank.gif");
                    writer.RenderBeginTag(HtmlTextWriterTag.Img);
                    writer.RenderEndTag();

                    writer.RenderEndTag(); // a

                    writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
                    writer.AddAttribute(HtmlTextWriterAttribute.Src, "/_layouts/images/blank.gif");
                    writer.RenderBeginTag(HtmlTextWriterTag.Img);
                    writer.RenderEndTag();

                    writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
                    writer.AddAttribute(HtmlTextWriterAttribute.Src, "/_layouts/images/blank.gif");
                    writer.RenderBeginTag(HtmlTextWriterTag.Img);
                    writer.RenderEndTag();

                    writer.RenderEndTag(); // div

                    if (fieldRef.Filterable || fieldRef.Sortable)
                    {
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "s4-ctx");
                        writer.AddAttribute(HtmlTextWriterAttribute.Onclick, showMenuScript.ToString());
                        writer.RenderBeginTag(HtmlTextWriterTag.Div);

                        writer.Write("<span>&nbsp;</span>");

                        writer.AddAttribute(HtmlTextWriterAttribute.Title, "Open Menu");
                        writer.AddAttribute(HtmlTextWriterAttribute.Href, "javascript:void(0)");
                        writer.AddAttribute(HtmlTextWriterAttribute.Onclick, showMenuScript.ToString());
                        writer.AddAttribute("onfocus", "FW_OnChildColumn(this.parentNode.parentNode); return false;");
                        writer.RenderBeginTag(HtmlTextWriterTag.A);
                        writer.RenderEndTag();

                        writer.Write("<span>&nbsp;</span>");

                        writer.RenderEndTag(); // div   
                    }

                    writer.RenderEndTag(); //th
                    break;
                default:
                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vh2");
                    writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");
                    writer.AddAttribute(HtmlTextWriterAttribute.Scope, "col");
                    writer.AddAttribute("onmouseover", "FW_OnChildColumn(this);");
                    writer.AddAttribute(HtmlTextWriterAttribute.Id, string.Format("th{0}", fieldRef.FieldName));
                    // Fix style for ASP.NET WebPart
                    writer.AddStyleAttribute(HtmlTextWriterStyle.FontWeight, "normal !important");
                    writer.RenderBeginTag(HtmlTextWriterTag.Th);

                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vh-div");
                    writer.AddAttribute("filterable", fieldRef.Filterable.ToString().ToUpperInvariant());
                    writer.AddAttribute("filterdisable", (!fieldRef.Filterable).ToString().ToUpper());
                    writer.AddAttribute("fieldtype", fieldRef.FieldType.ToString());
                    writer.AddAttribute("sortable", fieldRef.Sortable.ToString().ToUpperInvariant());
                    writer.AddAttribute("ctxnum", viewCounter.ToString());
                    if (fieldRef.Filterable || fieldRef.Sortable)
                    {
                        writer.AddAttribute(HtmlTextWriterAttribute.Onclick, showMenuScript.ToString());
                    }

                    writer.RenderBeginTag(HtmlTextWriterTag.Div);

                    writer.AddAttribute(HtmlTextWriterAttribute.Id, string.Format("diidSort{0}", fieldRef.FieldName));
                    writer.RenderBeginTag(HtmlTextWriterTag.A);
                    writer.Write(fieldRef.DisplayName);
                    if (fieldRef.FieldName == sortField)
                    {
                        writer.Write(sortDir == "ASC"
                                         ? "<img alt=\"Ascending\" src=\"/_layouts/images/sort.gif\" border=\"0\" />"
                                         : "<img alt=\"Descending\" src=\"/_layouts/images/rsort.gif\" border=\"0\" />");
                    }
                    writer.Write(
                        "<img width=\"1\" height=\"1\" border=\"0\" alt=\"Use SHIFT+ENTER to open the menu (new window).\" class=\"ms-hidden\" src=\"/_layouts/images/blank.gif\" />");
                    writer.RenderEndTag(); //a

                    writer.Write("<img border=\"0\" alt=\"\" src=\"/_layouts/images/blank.gif\" />");
                    writer.Write(fieldRef.IsFilter
                                     ? "<img alt=\"\" src=\"/_layouts/images/filter.gif\" border=\"0\" />"
                                     : "<img border=\"0\" alt=\"\" src=\"/_layouts/images/blank.gif\" />");

                    writer.RenderEndTag(); //div

                    if (fieldRef.Filterable || fieldRef.Sortable)
                    {
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "s4-ctx");
                        writer.AddAttribute(HtmlTextWriterAttribute.Onclick, showMenuScript.ToString());
                        writer.RenderBeginTag(HtmlTextWriterTag.Div);
                        writer.Write("<span>&nbsp;</span>");

                        writer.AddAttribute(HtmlTextWriterAttribute.Title, "Open Menu");
                        writer.AddAttribute(HtmlTextWriterAttribute.Href, "javascript:void(0)");
                        writer.AddAttribute(HtmlTextWriterAttribute.Onclick, showMenuScript.ToString());
                        writer.RenderBeginTag(HtmlTextWriterTag.A);
                        writer.RenderEndTag(); //a

                        writer.Write("<span>&nbsp;</span>");
                        writer.RenderEndTag(); //div
                    }

                    writer.RenderEndTag(); //th
                    break;
            }
        }

        protected override object SaveControlState()
        {
            var baseState = base.SaveControlState();
            var allState = new object[3];
            allState[0] = baseState;
            allState[1] = sortField;
            allState[2] = sortDir;
            return allState;
        }

        protected override void LoadControlState(object savedState)
        {
            if (savedState != null)
            {
                var allState = (object[])savedState;
                base.LoadControlState(allState[0]);
                sortField = (string)allState[1];
                sortDir = (string)allState[2];
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (ShowRibbonTabs)
            {
                RegisterListItemTab();
                RegisterListTab();
            }
        }

        #region Comparer

        private static bool Compare(DateTime x, DateTime y, bool dateOnly)
        {
            if (dateOnly)
            {
                return new DateOnlyComparer().Equals(x, y);
            }

            return Equals(x, y);
        }

        #endregion

        #region Ribbon Tabs

        private void RegisterListTab()
        {
            var lcid = Thread.CurrentThread.CurrentUICulture.LCID;

            var listTab = new RibbonTab("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List")
                              {
                                  Title = "List",
                                  Sequence = 500
                              };

            var viewFormatGroup =
                new RibbonGroup("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.ViewFormat")
                    {
                        Sequence = 10,
                        Title = "View Format",
                        Image32By32Popup = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32PopupLeft = -256,
                        Image32By32PopupTop = -256,
                        GroupTemplate = RibbonGroupTemplate.Flexible2
                    };
            viewFormatGroup.MaxSizes.Add(new RibbonMaxSize("Ribbon.List.Scaling.ViewFormat.MaxSize") { Sequence = 10, Group = viewFormatGroup, Size = RibbonSize.LargeLarge });
            viewFormatGroup.Scales.Add(new RibbonScale("Ribbon.List.Scaling.ViewFormat.Popup") { Sequence = 240, Group = viewFormatGroup, Size = RibbonSize.Popup });
            listTab.Groups.Add(viewFormatGroup);
            RegisterRibbonControls(viewFormatGroup);

            var btnStandard =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.ViewFormat.Controls.Standard")
                    {
                        Sequence = 10,
                        LabelText = "Standard View",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -32,
                        Image16By16Left = -144,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -256,
                        Image32By32Left = -256,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c1",
                    };
            viewFormatGroup.Controls.Add(btnStandard);

            var btnDatasheet =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.ViewFormat.Controls.Datasheet")
                    {
                        Sequence = 10,
                        LabelText = "Datasheet View",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -48,
                        Image16By16Left = -144,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = 0,
                        Image32By32Left = -288,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c1",
                    };
            viewFormatGroup.Controls.Add(btnDatasheet);

            var datasheetGroup =
                new RibbonGroup("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Datasheet")
                    {
                        Sequence = 20,
                        Title = "Datasheet",
                        Image32By32Popup = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32PopupLeft = -448,
                        Image32By32PopupTop = -256,
                        GroupTemplate = RibbonGroupTemplate.Flexible2
                    };
            viewFormatGroup.MaxSizes.Add(new RibbonMaxSize("Ribbon.List.Scaling.Datasheet.MaxSize") { Sequence = 20, Group = datasheetGroup, Size = RibbonSize.LargeMedium });
            viewFormatGroup.Scales.Add(new RibbonScale("Ribbon.List.Scaling.Datasheet.LargeSmall") { Sequence = 90, Group = datasheetGroup, Size = RibbonSize.LargeSmall });
            viewFormatGroup.Scales.Add(new RibbonScale("Ribbon.List.Scaling.Datasheet.Popup") { Sequence = 170, Group = datasheetGroup, Size = RibbonSize.Popup });
            listTab.Groups.Add(datasheetGroup);
            RegisterRibbonControls(datasheetGroup);

            var btnNewRow =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Datasheet.Controls.NewRow")
                    {
                        Sequence = 10,
                        LabelText = "New Row",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -80,
                        Image16By16Left = -192,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -160,
                        Image32By32Left = -384,
                        ToolTipTitle = "New Row",
                        ToolTipDescription = "Add a new row to this list.",
                        TemplateAlias = "c1",
                    };
            datasheetGroup.Controls.Add(btnNewRow);

            var btnShowTaskPane =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Datasheet.Controls.ShowTaskPane")
                    {
                        Sequence = 20,
                        LabelText = "",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -16,
                        Image16By16Left = -152,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -256,
                        Image32By32Left = -224,
                        ToolTipTitle = "Show Task Panel",
                        ToolTipDescription = "Open tasl panel to access additional commands.",
                        TemplateAlias = "c2",
                    };
            datasheetGroup.Controls.Add(btnShowTaskPane);

            var btnShowTotals =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Datasheet.Controls.ShowTotals")
                    {
                        Sequence = 30,
                        LabelText = "",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -240,
                        Image16By16Left = -224,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -448,
                        Image32By32Left = -256,
                        ToolTipTitle = "Show Totals",
                        ToolTipDescription = "Display totals underneath each column.",
                        TemplateAlias = "c2",
                    };
            datasheetGroup.Controls.Add(btnShowTotals);

            var btnRefreshData =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Datasheet.Controls.RefreshData")
                    {
                        Sequence = 40,
                        LabelText = "",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -240,
                        Image16By16Left = -208,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -448,
                        Image32By32Left = -224,
                        ToolTipTitle = "Refresh Data",
                        ToolTipDescription = "Reload the data to display changes made by other users.",
                        TemplateAlias = "c2",
                    };
            datasheetGroup.Controls.Add(btnRefreshData);

            var customViewsGroup =
                new RibbonGroup("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.CustomViews")
                    {
                        Sequence = 40,
                        Title = "Manage Views",
                        Image32By32Popup = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32PopupLeft = -352,
                        Image32By32PopupTop = -320,
                        GroupTemplate = RibbonGroupTemplate.ManageViewsGroup
                    };
            customViewsGroup.MaxSizes.Add(new RibbonMaxSize("Ribbon.List.Scaling.CustomViews.MaxSize") { Sequence = 40, Group = customViewsGroup, Size = RibbonSize.LargeMedium });
            customViewsGroup.Scales.Add(new RibbonScale("Ribbon.List.Scaling.CustomViews.LargeSmall") { Sequence = 160, Group = customViewsGroup, Size = RibbonSize.LargeSmall });
            customViewsGroup.Scales.Add(new RibbonScale("Ribbon.List.Scaling.CustomViews.Popup") { Sequence = 220, Group = customViewsGroup, Size = RibbonSize.Popup });
            listTab.Groups.Add(customViewsGroup);
            RegisterRibbonControls(customViewsGroup);

            var btnCreateView =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.CustomViews.Controls.CreateView")
                    {
                        Sequence = 10,
                        LabelText = "Create View",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -48,
                        Image16By16Left = -192,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -352,
                        Image32By32Left = -352,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c1",
                    };
            customViewsGroup.Controls.Add(btnCreateView);

            var btnModifyView =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.CustomViews.Controls.ModifyView")
                    {
                        Sequence = 20,
                        LabelText = "Modify View",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -32,
                        Image16By16Left = -192,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -352,
                        Image32By32Left = -320,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c2",
                    };
            customViewsGroup.Controls.Add(btnModifyView);

            var btnCreateColumn =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.CustomViews.Controls.CreateColumn")
                    {
                        Sequence = 30,
                        LabelText = "Create Column",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -144,
                        Image16By16Left = -176,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -96,
                        Image32By32Left = -352,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c2",
                    };
            customViewsGroup.Controls.Add(btnCreateColumn);

            var btnNavigateUp =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.CustomViews.Controls.NavigateUp")
                    {
                        Sequence = 30,
                        LabelText = "Navigate Up",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = 0,
                        Image16By16Left = -56,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -64,
                        Image32By32Left = 0,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c2",
                    };
            customViewsGroup.Controls.Add(btnNavigateUp);

            var shareGroup = new RibbonGroup("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Share")
                                 {
                                     Sequence = 50,
                                     Title = "Share & Track",
                                     Image32By32Popup = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                                     Image32By32PopupLeft = -448,
                                     Image32By32PopupTop = -256,
                                     GroupTemplate = RibbonGroupTemplate.Flexible2
                                 };
            shareGroup.MaxSizes.Add(new RibbonMaxSize("Ribbon.List.Scaling.Share.MaxSize") { Sequence = 40, Group = shareGroup, Size = RibbonSize.LargeLarge });
            shareGroup.Scales.Add(new RibbonScale("Ribbon.List.Scaling.Share.MediumMedium") { Sequence = 90, Group = shareGroup, Size = RibbonSize.MediumMedium });
            shareGroup.Scales.Add(new RibbonScale("Ribbon.List.Scaling.Share.Popup") { Sequence = 170, Group = shareGroup, Size = RibbonSize.Popup });
            listTab.Groups.Add(shareGroup);
            RegisterRibbonControls(shareGroup);

            var handlerStatement = new StringBuilder();
            handlerStatement.AppendFormat("window.location = 'mailto:?body={0}';", Page.Request.Url.OriginalString);

            var btnEmailLibraryLink =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Share.Controls.EmailLibraryLink")
                    {
                        Sequence = 10,
                        LabelText = "E-mail a Link",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -16,
                        Image16By16Left = -88,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -128,
                        Image32By32Left = -448,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        Command =
                            new SPRibbonCommand(
                            "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Commands.EmailLibraryLink",
                            handlerStatement.ToString()),
                        TemplateAlias = "c1",
                    };
            shareGroup.Controls.Add(btnEmailLibraryLink);

            handlerStatement = new StringBuilder();
            handlerStatement.AppendFormat("window.location = '{0}/_layouts/listfeed.aspx?List={1}';",
                                          SPContext.Current.Web.Url, Lists[0].ID);

            var btnViewRssFeed =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Share.Controls.ViewRSSFeed")
                    {
                        Sequence = 30,
                        LabelText = "RSS Feed",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -128,
                        Image16By16Left = -112,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -224,
                        Image32By32Left = -128,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        Command =
                            new SPRibbonCommand(
                            "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Commands.ViewRSSFeed",
                            handlerStatement.ToString()),
                        TemplateAlias = "c1",
                    };
            shareGroup.Controls.Add(btnViewRssFeed);

            var settingsGroup =
                new RibbonGroup("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Settings")
                    {
                        Sequence = 80,
                        Title = "Settings",
                        Image32By32Popup = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32PopupLeft = 0,
                        Image32By32PopupTop = -384,
                        GroupTemplate = RibbonGroupTemplate.Flexible2
                    };
            settingsGroup.MaxSizes.Add(new RibbonMaxSize("Ribbon.List.Scaling.Settings.MaxSize") { Sequence = 70, Group = settingsGroup, Size = RibbonSize.LargeLarge });
            settingsGroup.Scales.Add(new RibbonScale("Ribbon.List.Scaling.Settings.LargeMedium") { Sequence = 100, Group = settingsGroup, Size = RibbonSize.LargeMedium });
            settingsGroup.Scales.Add(new RibbonScale("Ribbon.List.Scaling.Settings.LargeSmall") { Sequence = 130, Group = settingsGroup, Size = RibbonSize.LargeSmall });
            settingsGroup.Scales.Add(new RibbonScale("Ribbon.List.Scaling.Settings.Popup") { Sequence = 190, Group = settingsGroup, Size = RibbonSize.Popup });
            listTab.Groups.Add(settingsGroup);
            RegisterRibbonControls(settingsGroup);

            handlerStatement = new StringBuilder();
            handlerStatement.AppendFormat("window.location = '{0}/_layouts/listedit.aspx?List={1}';",
                                          SPContext.Current.Web.Url, Lists[0].ID);

            var btnListSettings =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Settings.Controls.ListSettings")
                    {
                        Sequence = 10,
                        LabelText = "List Settings",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -64,
                        Image16By16Left = -192,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = 0,
                        Image32By32Left = -384,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        Command =
                            new SPRibbonCommand(
                            "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Commands.ListSettings",
                            handlerStatement.ToString()),
                        TemplateAlias = "c1",
                    };
            settingsGroup.Controls.Add(btnListSettings);

            var btnListPermissions =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Settings.Controls.ListPermissions")
                    {
                        Sequence = 20,
                        LabelText = "List Permissions",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -128,
                        Image16By16Left = 0,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = 0,
                        Image32By32Left = -416,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c2",
                    };
            settingsGroup.Controls.Add(btnListPermissions);

            var btnManageWorkflows =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.List.Groups.Settings.Controls.ManageWorkflows")
                    {
                        Sequence = 30,
                        LabelText = "Manage Workflows",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -112,
                        Image16By16Left = -112,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -160,
                        Image32By32Left = -416,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c2",
                    };
            settingsGroup.Controls.Add(btnManageWorkflows);

            // Register custom ribbon groups
            RegisterRibbonGroups(listTab);

            // Manual register group template
            ((BaseUserControl)NamingContainer).RegisterRibbonGroupTemplate(RibbonGroupTemplate.ManageViewsGroup);
            ((BaseUserControl)NamingContainer).RegisterRibbonTab(listTab, false);
            ((BaseUserControl)NamingContainer).LoadRibbonTab(listTab);
        }

        private void RegisterListItemTab()
        {
            var lcid = Thread.CurrentThread.CurrentUICulture.LCID;

            var listItemTab = new RibbonTab("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem")
                                  {
                                      Title = "Items",
                                      Sequence = 400
                                  };

            var newGroup = new RibbonGroup("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.New")
                               {
                                   Sequence = 10,
                                   Title = "New",
                                   Image32By32Popup = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                                   Image32By32PopupLeft = -64,
                                   Image32By32PopupTop = -320,
                                   GroupTemplate = RibbonGroupTemplate.Flexible2
                               };
            newGroup.MaxSizes.Add(new RibbonMaxSize("Ribbon.ListItem.Scaling.New.MaxSize") { Sequence = 10, Group = newGroup, Size = RibbonSize.LargeLarge });
            newGroup.Scales.Add(new RibbonScale("Ribbon.ListItem.Scaling.New.Popup") { Sequence = 160, Group = newGroup, Size = RibbonSize.Popup });

            listItemTab.Groups.Add(newGroup);

            RegisterRibbonControls(newGroup);

            var handlerStatement = new StringBuilder();

            var btnNewItem =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.New.Controls.NewItem")
                    {
                        Sequence = 10,
                        LabelText = "New Item",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -176,
                        Image16By16Left = -64,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -320,
                        Image32By32Left = -64,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c1"
                    };
            newGroup.Controls.Add(btnNewItem);

            if (EnableAddNewItem)
            {
                handlerStatement.Append("var options = SP.UI.$create_DialogOptions();");
                handlerStatement.AppendFormat(
                    "options.url = '{0}/_layouts/listform.aspx?PageType=8&ListId={1}&ContentTypeID=0x0100C52A55B6DCC75D4EA7BC118149118F5C';",
                    SPContext.Current.Web.Url, Lists[0].ID);
                handlerStatement.Append(
                    "options.dialogReturnValueCallback = Function.createDelegate(null, function(result, target){if(result == SP.UI.DialogResult.OK){SP.UI.ModalDialog.RefreshPage(SP.UI.DialogResult.OK);}});");
                handlerStatement.Append("SP.UI.ModalDialog.showModalDialog(options);");

                var newItemCommand =
                    new SPRibbonCommand("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Commands.NewItem")
                        {
                            HandlerStatement = handlerStatement.ToString()
                        };
                btnNewItem.Command = newItemCommand;
            }

            var btnNewFolder =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.New.Controls.NewFolder")
                    {
                        Sequence = 20,
                        LabelText = "New Folder",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -16,
                        Image16By16Left = -248,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -448,
                        Image32By32Left = -320,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c1"
                    };
            newGroup.Controls.Add(btnNewFolder);

            var manageGroup =
                new RibbonGroup("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.Manage")
                    {
                        Sequence = 20,
                        Title = "Manage",
                        Image32By32Popup = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32PopupLeft = -64,
                        Image32By32PopupTop = -448,
                        GroupTemplate = RibbonGroupTemplate.Flexible2
                    };
            manageGroup.MaxSizes.Add(new RibbonMaxSize("Ribbon.ListItem.Scaling.Manage.MaxSize") { Sequence = 10, Group = manageGroup, Size = RibbonSize.LargeMedium });
            manageGroup.Scales.Add(new RibbonScale("Ribbon.ListItem.Scaling.Manage.LargeSmall") { Group = manageGroup, Sequence = 100, Size = RibbonSize.LargeSmall });
            manageGroup.Scales.Add(new RibbonScale("Ribbon.ListItem.Scaling.Manage.Popup") { Group = manageGroup, Sequence = 150, Size = RibbonSize.Popup });
            listItemTab.Groups.Add(manageGroup);
            RegisterRibbonControls(manageGroup);

            handlerStatement = new StringBuilder();
            handlerStatement.Append("var item = getSelectedItems()[0];");
            handlerStatement.Append("var options = SP.UI.$create_DialogOptions();");
            handlerStatement.AppendFormat(
                "options.url = '{0}/_layouts/listform.aspx?PageType=4&ContentTypeID=0x0100C52A55B6DCC75D4EA7BC118149118F5C&ListId=' + item.refListId + '&ID=' + item.refId;",
                SPContext.Current.Web.Url);
            handlerStatement.Append(
                "options.dialogReturnValueCallback = Function.createDelegate(null, function(result, target){if(result == SP.UI.DialogResult.OK){SP.UI.ModalDialog.RefreshPage(SP.UI.DialogResult.OK);}});");
            handlerStatement.Append("SP.UI.ModalDialog.showModalDialog(options);");

            var viewPropertiesCommand =
                new SPRibbonCommand("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Commands.ViewItem")
                    {
                        HandlerStatement = handlerStatement.ToString(),
                        EnabledStatement = "(getSelectedItems().length == 1)"
                    };

            var btnViewProperties =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.Manage.Controls.ViewProperties")
                    {
                        Sequence = 20,
                        LabelText = "View Item",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -32,
                        Image16By16Left = -80,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -96,
                        Image32By32Left = -448,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        Command = viewPropertiesCommand,
                        TemplateAlias = "c1"
                    };
            manageGroup.Controls.Add(btnViewProperties);

            var btnEditProperties =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.Manage.Controls.EditProperties")
                    {
                        Sequence = 20,
                        LabelText = "Edit Item",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -128,
                        Image16By16Left = -224,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -128,
                        Image32By32Left = -96,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c1"
                    };
            manageGroup.Controls.Add(btnEditProperties);

            if (EnableEditItem)
            {
                handlerStatement = new StringBuilder();
                handlerStatement.Append("var item = getSelectedItems()[0];");
                handlerStatement.Append("var options = SP.UI.$create_DialogOptions();");
                handlerStatement.AppendFormat(
                    "options.url = '{0}/_layouts/listform.aspx?PageType=6&ContentTypeID=0x0100C52A55B6DCC75D4EA7BC118149118F5C&ListId=' + item.refListId + '&ID=' + item.refId;",
                    SPContext.Current.Web.Url);
                handlerStatement.Append(
                    "options.dialogReturnValueCallback = Function.createDelegate(null, function(result, target){if(result == SP.UI.DialogResult.OK){SP.UI.ModalDialog.RefreshPage(SP.UI.DialogResult.OK);}});");
                handlerStatement.Append("SP.UI.ModalDialog.showModalDialog(options);");

                var editPropertiesCommand =
                    new SPRibbonCommand("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Commands.EditItem")
                        {
                            HandlerStatement = handlerStatement.ToString(),
                            EnabledStatement = "(getSelectedItems().length == 1)"
                        };
                btnEditProperties.Command = editPropertiesCommand;
            }

            var btnViewVersions =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.Manage.Controls.ViewVersions")
                    {
                        Sequence = 30,
                        LabelText = "Version History",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -48,
                        Image16By16Left = -80,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -64,
                        Image32By32Left = -448,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c2"
                    };
            manageGroup.Controls.Add(btnViewVersions);

            var btnManagePermissions =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.Manage.Controls.ManagePermissions")
                    {
                        Sequence = 40,
                        LabelText = "Item Permissions",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -128,
                        Image16By16Left = 0,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = 0,
                        Image32By32Left = -416,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c2"
                    };
            manageGroup.Controls.Add(btnManagePermissions);

            var btnDelete =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.Manage.Controls.Delete")
                    {
                        Sequence = 50,
                        LabelText = "Delete Item",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -112,
                        Image16By16Left = -224,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -128,
                        Image32By32Left = -128,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c2"
                    };
            manageGroup.Controls.Add(btnDelete);

            if (EnableDeleteItem)
            {
                handlerStatement = new StringBuilder();
                handlerStatement.Append(
                    "if(!confirm('Are you sure you want to send the item(s) to the site Recycle Bin?')) return;");
                handlerStatement.Append("var items = getSelectedItems();");
                handlerStatement.Append("var ctx = new SP.ClientContext.get_current();");
                handlerStatement.Append(
                    "$.each(items, function(index, item){var list = ctx.get_web().get_lists().getById(item.refListId);var listItem = list.getItemById(item.refId);listItem.deleteObject();});");
                handlerStatement.Append(
                    "ctx.executeQueryAsync(Function.createDelegate(null, function(){SP.UI.ModalDialog.RefreshPage(SP.UI.DialogResult.OK);}), null);");

                var deleteItemCommand =
                    new SPRibbonCommand(
                        "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Commands.DeleteItem")
                        {
                            HandlerStatement = handlerStatement.ToString(),
                            EnabledStatement = "(getSelectedItems().length > 0)"
                        };
                btnDelete.Command = deleteItemCommand;
            }

            var actionsGroup =
                new RibbonGroup("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.Actions")
                    {
                        Sequence = 30,
                        Title = "Actions",
                        Image32By32Popup = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32PopupLeft = -352,
                        Image32By32PopupTop = -128,
                        GroupTemplate = RibbonGroupTemplate.Flexible2
                    };
            actionsGroup.MaxSizes.Add(new RibbonMaxSize("Ribbon.ListItem.Scaling.Actions.MaxSize") { Sequence = 30, Group = actionsGroup, Size = RibbonSize.LargeLarge });
            actionsGroup.Scales.Add(new RibbonScale("Ribbon.ListItem.Scaling.Actions.Popup") { Sequence = 130, Group = actionsGroup, Size = RibbonSize.Popup });
            listItemTab.Groups.Add(actionsGroup);
            RegisterRibbonControls(actionsGroup);

            var btnAttachFile =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.Actions.Controls.AttachFile")
                    {
                        Sequence = 10,
                        LabelText = "Attach File",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -128,
                        Image16By16Left = -144,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -352,
                        Image32By32Left = -128,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c1"
                    };
            actionsGroup.Controls.Add(btnAttachFile);

            var workflowGroup =
                new RibbonGroup("DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.Workflows")
                    {
                        Sequence = 50,
                        Title = "Workflows",
                        Image32By32Popup = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32PopupLeft = -192,
                        Image32By32PopupTop = -416,
                        GroupTemplate = RibbonGroupTemplate.Flexible2
                    };
            workflowGroup.MaxSizes.Add(new RibbonMaxSize("Ribbon.ListItem.Scaling.Workflows.MaxSize") { Sequence = 50, Group = workflowGroup, Size = RibbonSize.LargeLarge });
            workflowGroup.Scales.Add(new RibbonScale("Ribbon.ListItem.Scaling.Workflows.MediumMedium") { Sequence = 70, Group = workflowGroup, Size = RibbonSize.MediumMedium });
            workflowGroup.Scales.Add(new RibbonScale("Ribbon.ListItem.Scaling.Workflows.Popup") { Sequence = 110, Group = workflowGroup, Size = RibbonSize.Popup });
            listItemTab.Groups.Add(workflowGroup);
            RegisterRibbonControls(workflowGroup);

            var btnViewWorkflows =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.Workflows.Controls.ViewWorkflows")
                    {
                        Sequence = 10,
                        LabelText = "Workflows",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -48,
                        Image16By16Left = -208,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -192,
                        Image32By32Left = -416,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c1"
                    };
            workflowGroup.Controls.Add(btnViewWorkflows);

            var btnModerate =
                new RibbonButton(
                    "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Tabs.ListItem.Groups.Workflows.Controls.Moderate")
                    {
                        Sequence = 10,
                        LabelText = "Approve/Reject",
                        Image16By16 = string.Format("/_layouts/{0}/images/formatmap16x16.png", lcid),
                        Image16By16Top = -48,
                        Image16By16Left = -240,
                        Image32By32 = string.Format("/_layouts/{0}/images/formatmap32x32.png", lcid),
                        Image32By32Top = -448,
                        Image32By32Left = -384,
                        ToolTipTitle = "",
                        ToolTipDescription = "",
                        TemplateAlias = "c1"
                    };
            workflowGroup.Controls.Add(btnModerate);

            // Register custom ribbon groups
            RegisterRibbonGroups(listItemTab);

            ((BaseUserControl)NamingContainer).RegisterRibbonTab(listItemTab);
            ((BaseUserControl)NamingContainer).LoadRibbonTab(listItemTab);
        }

        #endregion
    }
}