﻿using System;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    [Obsolete]
    public enum DataViewFieldType
    {
        Attachments,
        DocumentIcon,
        Text,
        User,
        Note,
        File,
        Calculated,
        DateOnly,
        DateTime,
        Number,
        Currency,
        Lookup,
        AutoNumber,
        Boolean,
    }
}