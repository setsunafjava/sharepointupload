﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Web.UI;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class UserFieldRef : BaseFieldRef, IGroupFieldRef
    {
        private SPFieldUser fieldUser;

        public UserFieldRef()
        {
            EmptyGroupString = LocalizationHelper.GetString("BaseFieldRef_MS004");
        }

        public override SPFieldType FieldType
        {
            get { return SPFieldType.User; }
        }

        #region IGroupFieldRef Members

        public string GetGroupFieldRef(string sortField, string sortDir)
        {
            ListSortDirection sortDirection;
            if (InternalFieldName.Equals(sortField))
            {
                sortDirection = sortDir == "ASC" ? ListSortDirection.Ascending : ListSortDirection.Descending;
            }
            else
            {
                sortDirection = SortDirection;
            }

            return string.Format(sortDirection == ListSortDirection.Ascending
                                     ? "<FieldRef Name='{0}' />"
                                     : "<FieldRef Name='{0}' Ascending='FALSE' />", InternalFieldName);
        }

        public override void Initialize(SPField field)
        {
            base.Initialize(field);
            fieldUser = (SPFieldUser) field;
        }

        public bool CollapsedGroup { get; set; }

        public override string GetViewFieldRef()
        {
            return string.Format("<FieldRef Name='{0}' Type='User' Nullable='TRUE' />", InternalFieldName);
        }

        public bool CountGroupItems { get; set; }

        public bool SumGroupFieldData { get; set; }

        IGroupFieldRef IGroupFieldRef.ParentGroup { get; set; }

        public string EmptyGroupString { get; set; }

        public ListSortDirection SortDirection { get; set; }

        public Expression<Func<DataRow, bool>> AddFilterExpression(Expression<Func<DataRow, bool>> filter,
                                                                   IGrouping<object, DataRow> group)
        {
            if (group.Key is DBNull)
            {
                return filter.And(item => DataViewUtils.IsDBNull(item, FieldName));
            }

            if (group.Key is SPFieldUserValue)
            {
                return filter.And(item => DataViewUtils.CompareObject((SPFieldUserValue) group.Key, item[FieldName]));
            }

            if (group.Key is SPFieldUserValueCollection)
            {
                return filter.And(item => DataViewUtils.CompareObject((SPFieldUserValueCollection) group.Key, item[FieldName]));
            }

            var key = group.Key.ToString();
            return filter.And(item => DataViewUtils.CompareStringObject(key, item[FieldName]));
        }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(DataTable dt)
        {
            return dt.AsEnumerable().GroupBy(g => g[FieldName], new UserFieldComparer());
        }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(IGrouping<object, DataRow> grouping)
        {
            return grouping.GroupBy(g => g[FieldName], new UserFieldComparer());
        }

        public void RenderCell(HtmlTextWriter writer, IGrouping<object, DataRow> grouping)
        {
            if (grouping.Key is DBNull)
            {
                writer.Write(EmptyGroupString);
            }
            else
            {
                if (grouping.Key is SPFieldUserValue)
                {
                    writer.Write(SPEncode.HtmlEncode(Utils.Cast<SPFieldUserValue>(grouping.Key).LookupValue));
                }
                else
                {
                    var users = (SPFieldUserValueCollection) grouping.Key;
                    writer.Write(string.Join("; ", users.Select(u => SPEncode.HtmlEncode(u.LookupValue)).ToArray()));
                }
            }
        }

        public override void RenderCell(HtmlTextWriter writer, DataRow row)
        {
            var value = row[FieldName];
            if (value is DBNull)
            {
                writer.Write(DefaultValue);
                return;
            }

            var html = fieldUser.GetFieldValueAsHtml(value);
            html = html.Replace("<a", "<a onclick=\"GoToLink(this);return false;\"");
            writer.Write(html);
        }

        #endregion

        public override Dictionary<string, string> GetFilterValues(DataTable dt)
        {
            var values = dt.AsEnumerable().Select(item => item[FieldName]);
            var dictionary = new Dictionary<string, string>();
            var hasEmpty = false;

            foreach (var value in values)
            {
                if (value is DBNull)
                {
                    hasEmpty = true;
                    continue;
                }

                if (value is SPFieldUserValue)
                {
                    var userValue = (SPFieldUserValue) value;
                    if (!dictionary.ContainsKey(userValue.LookupId.ToString()))
                    {
                        dictionary.Add(userValue.LookupId.ToString(), userValue.LookupValue);
                    }
                }
                else if (value is SPFieldUserValueCollection)
                {
                    var users = (SPFieldUserValueCollection) value;
                    if (users.Count == 0)
                    {
                        hasEmpty = true;
                        continue;
                    }

                    foreach (var user in users.Where(user => !dictionary.ContainsKey(user.LookupId.ToString())))
                    {
                        dictionary.Add(user.LookupId.ToString(), user.LookupValue);
                    }
                }
            }

            if (hasEmpty)
            {
                dictionary.Add(string.Empty, string.Empty);
            }

            return dictionary.OrderBy(item => item.Key)
                .ToDictionary(item => item.Key, item => string.IsNullOrEmpty(item.Value) ? "(Empty)" : DataViewUtils.TrimStringOverMaxLength(item.Value));
        }

        public override string[] GetFilterQuery()
        {
            const string caml =
                "<Eq><FieldRef Name='{0}' LookupId='TRUE' /><Value Type='User'>{1}</Value></Eq>";
            if (string.IsNullOrEmpty(FilterValue))
            {
                return new []{string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName)};
            }

            return new []{string.Format(caml, InternalFieldName, FilterValue)};
        }

        public override string GetFilterCamlQuery()
        {
            if (string.IsNullOrEmpty(FilterValue))
            {
                return string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName);
            }

            if (fieldUser.AllowMultipleValues)
            {
                return string.Format("<Eq><FieldRef Name='{0}' /><Value Type='UserMulti'>{1}</Value></Eq>", InternalFieldName, FilterValue);   
            }

            return string.Format("<Eq><FieldRef Name='{0}' /><Value Type='User'>{1}</Value></Eq>", InternalFieldName, FilterValue);  
        }

        public override string GetCellTextValue(DataRow row)
        {
            var value = row[FieldName];
            if (value is DBNull)
            {
                return DefaultValue;
            }

            return fieldUser.GetFieldValueAsText(value);
        }

        #region Nested type: UserFieldComparer

        private class UserFieldComparer : IEqualityComparer<object>
        {
            #region IEqualityComparer<object> Members

            bool IEqualityComparer<object>.Equals(object x, object y)
            {
                if (ReferenceEquals(x, y)) return true;

                if (ReferenceEquals(x, null) || ReferenceEquals(y, null))
                    return false;

                if ((x is DBNull) || (y is DBNull))
                {
                    return false;
                }

                return x.ToString() == y.ToString();
            }

            public int GetHashCode(object obj)
            {
                if (obj == null || obj is DBNull)
                {
                    return 0;
                }

                var split = obj.ToString().Split(new[] {";#"}, StringSplitOptions.None);
                if (split.Length == 2)
                {
                    return split[1].GetHashCode();
                }

                return obj.GetHashCode();
            }

            #endregion
        }

        #endregion
    }
}