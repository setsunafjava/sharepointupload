﻿using System;
using System.Data;
using System.Linq;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class RichTextFieldRef : BaseFieldRef
    {
        private SPFieldMultiLineText fieldMultiLineText;

        public bool EncodeHtml { get; set; }

        public override SPFieldType FieldType
        {
            get { return SPFieldType.Note; }
        }

        public override bool Sortable
        {
            get { return false; }
            set { base.Sortable = value; }
        }

        public override bool Filterable
        {
            get { return false; }
            set { base.Filterable = value; }
        }

        public override void Initialize(SPField field)
        {
            base.Initialize(field);
            fieldMultiLineText = (SPFieldMultiLineText) field;
        }

        public override void RenderCell(HtmlTextWriter writer, DataRow row)
        {
            var value = Convert.ToString(row[FieldName]);
            if (string.IsNullOrEmpty(value))
            {
                writer.Write(DefaultValue);
                return;
            }

            if (!fieldMultiLineText.RichText)
            {
                var split = value.Split(Environment.NewLine.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                writer.Write(string.Join("<br/>", split.Select(SPEncode.HtmlEncode).ToArray()));
            }
            else
            {
                writer.Write(value);
            }
        }

        public override string GetFilterCamlQuery()
        {
            throw new NotSupportedException();
        }

        public override string GetCellTextValue(DataRow row)
        {
            throw new NotSupportedException();
        }
    }
}