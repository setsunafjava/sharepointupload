﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Web.UI;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class LookupFieldRef : BaseFieldRef, IGroupFieldRef
    {
        private SPField lookupField;

        public LookupFieldRef()
        {
            EmptyGroupString = LocalizationHelper.GetString("BaseFieldRef_MS004");
        }

        public override SPFieldType FieldType
        {
            get { return SPFieldType.Lookup; }
        }

        #region IGroupFieldRef Members

        public override void Initialize(SPField field)
        {
            base.Initialize(field);
            lookupField = field;
        }

        public string GetGroupFieldRef(string sortField, string sortDir)
        {
            ListSortDirection sortDirection;
            if (InternalFieldName.Equals(sortField))
            {
                sortDirection = sortDir == "ASC" ? ListSortDirection.Ascending : ListSortDirection.Descending;
            }
            else
            {
                sortDirection = SortDirection;
            }

            return string.Format(sortDirection == ListSortDirection.Ascending
                                     ? "<FieldRef Name='{0}' />"
                                     : "<FieldRef Name='{0}' Ascending='FALSE' />", InternalFieldName);
        }

        public bool CountGroupItems { get; set; }

        public bool CollapsedGroup { get; set; }

        public bool SumGroupFieldData { get; set; }

        IGroupFieldRef IGroupFieldRef.ParentGroup { get; set; }

        public string EmptyGroupString { get; set; }

        public ListSortDirection SortDirection { get; set; }

        public Expression<Func<DataRow, bool>> AddFilterExpression(Expression<Func<DataRow, bool>> filter,
                                                                   IGrouping<object, DataRow> group)
        {
            if (group.Key is DBNull)
            {
                return filter.And(item => DataViewUtils.IsDBNull(item, FieldName));
            }

            var key = group.Key.ToString();
            return filter.And(item => DataViewUtils.CompareStringObject(key, item[FieldName]));
        }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(DataTable dt)
        {
            return dt.AsEnumerable().GroupBy(g => g[FieldName], new LookupEqualityComparer());
        }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(IGrouping<object, DataRow> grouping)
        {
            return grouping.GroupBy(g => g[FieldName], new LookupEqualityComparer());
        }

        public virtual void RenderCell(HtmlTextWriter writer, IGrouping<object, DataRow> grouping)
        {
            if (grouping.Key != null && !(grouping.Key is DBNull))
            {
                var split = Convert.ToString(grouping.Key).Split(new[] {";#"}, StringSplitOptions.None);
                var key = string.Join("; ", split.Where((item, i) => i%2 != 0).ToArray());
                if (string.IsNullOrEmpty(key))
                {
                    key = EmptyGroupString;
                }
                writer.Write(SPEncode.HtmlEncode(key));
            }
            else
            {
                writer.Write(EmptyGroupString);
            }
        }

        public override void RenderCell(HtmlTextWriter writer, DataRow row)
        {
            var value = row[FieldName];
            if (value == null || value is DBNull)
            {
                writer.Write(DefaultValue);
                return;
            }

            var html = lookupField.GetFieldValueAsHtml(value);
            writer.Write(string.IsNullOrEmpty(html) ? DefaultValue : html);
        }

        public override string GetViewFieldRef()
        {
            return string.Format("<FieldRef Name='{0}' Type='Lookup' Nullable='TRUE' />", InternalFieldName);
        }

        #endregion

        public override Dictionary<string, string> GetFilterValues(DataTable dt)
        {
            var values = dt.AsEnumerable().Select(item => item[FieldName]);
            var dictionary = new Dictionary<string, string>();
            bool? flag = null;
            var hasEmpty = false;

            foreach (var value in values)
            {
                if (!flag.HasValue)
                {
                    if (value is SPFieldLookupValueCollection)
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }

                if (flag.Value)
                {
                    var users = (SPFieldLookupValueCollection) value;
                    if (users.Count == 0)
                    {
                        if (!hasEmpty)
                        {
                            hasEmpty = true;
                        }
                    }
                    else
                    {
                        foreach (var user in users.Where(user => !dictionary.ContainsKey(user.LookupId.ToString())))
                        {
                            dictionary.Add(user.LookupId.ToString(), user.LookupValue);
                        }
                    }
                }
                else
                {
                    var split = Convert.ToString(value).Split(new[] {";#"}, StringSplitOptions.None);
                    if (split.Length == 2)
                    {
                        if (!dictionary.ContainsKey(split[0]))
                        {
                            dictionary.Add(split[0], split[1]);
                        }
                    }
                    else
                    {
                        hasEmpty = true;
                    }
                }
            }

            if (hasEmpty)
            {
                dictionary.Add(string.Empty, string.Empty);
            }

            return dictionary.OrderBy(item => item.Value)
                .ToDictionary(item => item.Key, item => string.IsNullOrEmpty(item.Value) ? LocalizationHelper.GetString("BaseFieldRef_MS003") : DataViewUtils.TrimStringOverMaxLength(item.Value));
        }

        public override string[] GetFilterQuery()
        {
            const string caml =
                "<Eq><FieldRef Name='{0}' LookupId='TRUE' /><Value Type='Lookup'><![CDATA[{1}]]></Value></Eq>";
            if (string.IsNullOrEmpty(FilterValue))
            {
                return new []{string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName)};
            }

            return new []{string.Format(caml, InternalFieldName, FilterValue)};
        }

        public override string GetFilterCamlQuery()
        {
            return string.IsNullOrEmpty(FilterValue) ?
                            string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName) :
                            string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Lookup'><![CDATA[{1}]]></Value></Eq>", InternalFieldName, FilterValue);
        }

        public override string GetCellTextValue(DataRow row)
        {
            var value = row[FieldName];
            if (value is DBNull)
            {
                return DefaultValue;
            }

            return SPEncode.HtmlEncode(lookupField.GetFieldValueAsText(value));
        }

        private class LookupEqualityComparer : IEqualityComparer<object>
        {
            bool IEqualityComparer<object>.Equals(object x, object y)
            {
                if (x is DBNull && y is DBNull)
                {
                    return true;
                }

                if (x is DBNull || y is DBNull)
                {
                    return false;
                }

                if (x is SPFieldLookupValue)
                {
                    return Utils.Cast<SPFieldLookupValue>(x).LookupId == Utils.Cast<SPFieldLookupValue>(y).LookupId;
                }

                if (x is SPFieldLookupValueCollection)
                {
                    return GetHashCode(Utils.Cast<SPFieldLookupValueCollection>(x)) == GetHashCode(Utils.Cast<SPFieldLookupValueCollection>(y));
                }

                return x.Equals(y);
            }

            public int GetHashCode(object obj)
            {
                if (obj is DBNull)
                {
                    return -1;
                }

                if (obj is SPFieldLookupValue)
                {
                    return Utils.Cast<SPFieldLookupValue>(obj).LookupId.GetHashCode();
                }

                if (obj is SPFieldLookupValueCollection)
                {
                    return GetHashCode(Utils.Cast<SPFieldLookupValueCollection>(obj));
                }

                return obj.GetHashCode();
            }

            private static int GetHashCode(IEnumerable<SPFieldLookupValue> values)
            {
                return values.Aggregate(0, (current, value) => current ^ value.LookupId.GetHashCode());
            }
        }
    }
}