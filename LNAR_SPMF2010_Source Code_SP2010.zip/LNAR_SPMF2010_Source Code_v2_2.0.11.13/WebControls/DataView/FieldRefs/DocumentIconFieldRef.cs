﻿using System;
using System.Data;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class DocumentIconFieldRef : BaseFieldRef
    {
        public DocumentIconFieldRef()
        {
            FieldName = "DocIcon";
        }

        public override void RenderCell(HtmlTextWriter writer, DataRow row)
        {
            var value = Convert.ToString(row[FieldName]);
            writer.Write(string.Format("<img alt='' src='/_layouts/images/{0}' />",
                                       SPUtility.MapToIcon(SPContext.Current.Web, value, string.Empty, IconSize.Size16)));
        }

        public override string GetFilterCamlQuery()
        {
            throw new NotSupportedException();
        }

        public override string GetCellTextValue(DataRow row)
        {
            throw new NotSupportedException();
        }
    }
}