﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Web.UI;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    /// <summary>
    ///   Represents a calculated field in a view
    /// </summary>
    public class CalculatedFieldRef : BaseFieldRef, IGroupFieldRef
    {
        private static readonly Hashtable CacheCurrencyFormats;
        private NumberFormatInfo currencyFormat;
        private SPFieldCalculated fieldCalculated;

        static CalculatedFieldRef()
        {
            CacheCurrencyFormats = new Hashtable();
        }

        public CalculatedFieldRef()
        {
            EmptyGroupString = LocalizationHelper.GetString("BaseFieldRef_MS004");
        }

        public override SPFieldType FieldType
        {
            get { return SPFieldType.Calculated; }
        }

        public override bool SupportSumFieldData
        {
            get
            {
                if (fieldCalculated == null)
                {
                    return true;
                }

                switch (fieldCalculated.OutputType)
                {
                    case SPFieldType.Number:
                    case SPFieldType.Currency:
                        return true;
                    default:
                        return false;
                }
            }
        }

        public override bool TextAlignRight
        {
            get
            {
                switch (fieldCalculated.OutputType)
                {
                    case SPFieldType.Number:
                    case SPFieldType.Currency:
                        return true;
                    default:
                        return false;
                }
            }
        }

        private NumberFormatInfo CurrencyFormat
        {
            get
            {
                if (currencyFormat == null)
                {
                    var currentCulture = Thread.CurrentThread.CurrentCulture;
                    if ((currentCulture.LCID == fieldCalculated.CurrencyLocaleId) &&
                        ((fieldCalculated.DisplayFormat == SPNumberFormatTypes.Automatic) ||
                         ((int) fieldCalculated.DisplayFormat == currentCulture.NumberFormat.CurrencyDecimalDigits)))
                    {
                        return currentCulture.NumberFormat;
                    }
                    currencyFormat = (NumberFormatInfo) Thread.CurrentThread.CurrentCulture.NumberFormat.Clone();
                    GetCombinedNumberFormatInfo(currencyFormat, fieldCalculated.CurrencyLocaleId,
                                                fieldCalculated.DisplayFormat);
                }
                else if (currencyFormat.CurrencyDecimalDigits != (int) fieldCalculated.DisplayFormat)
                {
                    if (fieldCalculated.DisplayFormat == SPNumberFormatTypes.Automatic)
                    {
                        currencyFormat.CurrencyDecimalDigits = 2;
                    }
                    else
                    {
                        currencyFormat.CurrencyDecimalDigits = (int) fieldCalculated.DisplayFormat;
                    }
                }
                return currencyFormat;
            }
        }

        #region IGroupFieldRef Members

        public bool CollapsedGroup { get; set; }

        public override void Initialize(SPField field)
        {
            base.Initialize(field);
            fieldCalculated = (SPFieldCalculated) field;
        }

        public bool CountGroupItems { get; set; }

        public bool SumGroupFieldData { get; set; }

        IGroupFieldRef IGroupFieldRef.ParentGroup { get; set; }

        public string EmptyGroupString { get; set; }

        public ListSortDirection SortDirection { get; set; }

        public Expression<Func<DataRow, bool>> AddFilterExpression(Expression<Func<DataRow, bool>> filter,
                                                                   IGrouping<object, DataRow> group)
        {
            if (group.Key is DBNull)
            {
                return filter.And(item => DataViewUtils.IsDBNull(item, FieldName));
            }

            switch (fieldCalculated.OutputType)
            {
                case SPFieldType.DateTime:
                    return filter.And(item => DataViewUtils.CompareDateObject(group.Key, item[FieldName]));
                case SPFieldType.Number:
                case SPFieldType.Currency:
                    return filter.And(item => DataViewUtils.CompareNumberObject(group.Key, item[FieldName], fieldCalculated.DisplayFormat));
                case SPFieldType.Boolean:
                    return filter.And(item => DataViewUtils.CompareBooleanObject(group.Key, item[FieldName]));
                default:
                    return filter.And(item => DataViewUtils.CompareStringObject(group.Key, item[FieldName]));
            }
        }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(DataTable dt)
        {
            switch (fieldCalculated.OutputType)
            {
                case SPFieldType.DateTime:
                    return dt.AsEnumerable().GroupBy(g => g[FieldName], new GenericEqualityComparer());
                case SPFieldType.Text:
                    return dt.AsEnumerable().GroupBy(g => g[FieldName], new TextFieldRef.StringComparer());
                default:
                    return dt.AsEnumerable().GroupBy(g => g[FieldName]);
            }
        }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(IGrouping<object, DataRow> grouping)
        {
            switch (fieldCalculated.OutputType)
            {
                case SPFieldType.DateTime:
                    return grouping.GroupBy(g => g[FieldName], new GenericEqualityComparer());
                case SPFieldType.Text:
                    return grouping.GroupBy(g => g[FieldName], new TextFieldRef.StringComparer());
                default:
                    return grouping.GroupBy(g => g[FieldName]);
            }
        }

        public virtual void RenderCell(HtmlTextWriter writer, IGrouping<object, DataRow> grouping)
        {
            RenderCell(writer, grouping.Key, EmptyGroupString);
        }

        public override void RenderCell(HtmlTextWriter writer, DataRow row)
        {
            var value = row[FieldName];
            RenderCell(writer, value, DefaultValue);
        }

        public string GetGroupFieldRef(string sortField, string sortDir)
        {
            ListSortDirection sortDirection;
            if (InternalFieldName.Equals(sortField))
            {
                sortDirection = sortDir == "ASC" ? ListSortDirection.Ascending : ListSortDirection.Descending;
            }
            else
            {
                sortDirection = SortDirection;
            }

            return string.Format(sortDirection == ListSortDirection.Ascending
                                     ? "<FieldRef Name='{0}' />"
                                     : "<FieldRef Name='{0}' Ascending='FALSE' />", InternalFieldName);
        }

        #endregion

        private void RenderCell(TextWriter writer, object value, string defaultValue)
        {
            if (value is DBNull)
            {
                writer.Write(defaultValue);
                return;
            }

            if (value is string)
            {
                var str = value.ToString().Trim();
                writer.Write(string.IsNullOrEmpty(str) ? defaultValue : SPEncode.HtmlEncode(str));
                return;
            }

            string html = null;

            switch (fieldCalculated.OutputType)
            {
                case SPFieldType.Currency:
                    html = ((double) value).ToString("C", CurrencyFormat);
                    break;
                case SPFieldType.Number:
                    var currentCulture = Thread.CurrentThread.CurrentCulture;
                    html = SPFieldNumber.GetFieldValueAsHtml((double) value, currentCulture,
                                                             fieldCalculated.ShowAsPercentage,
                                                             fieldCalculated.DisplayFormat);
                    break;
                case SPFieldType.Boolean:
                    html = SPFieldBoolean.GetFieldValueAsHtml((bool) value);
                    break;
                case SPFieldType.DateTime:
                    var dateFormat = fieldCalculated.DateFormat == SPDateTimeFieldFormatType.DateTime
                                         ? SPDateFormat.DateTime
                                         : SPDateFormat.DateOnly;
                    html = SPFieldDateTime.GetFieldValueAsHtml((DateTime) value, SPContext.Current.Web, dateFormat);
                    break;
            }

            if (html == null || string.IsNullOrEmpty(html.Trim()))
            {
                writer.Write(defaultValue);
                return;
            }

            writer.Write(html);
        }

        private static void GetCombinedNumberFormatInfoForEuro(NumberFormatInfo numberFormatInfo, int currencyLocaleId,
                                                               SPNumberFormatTypes displayFormat)
        {
            var currencyNegativePattern = numberFormatInfo.CurrencyNegativePattern;

            switch (numberFormatInfo.NumberNegativePattern)
            {
                case 0:
                    currencyNegativePattern = (currencyLocaleId == -1) ? 14 : 15;
                    break;

                case 1:
                case 2:
                    currencyNegativePattern = (currencyLocaleId == -1) ? 9 : 8;
                    break;

                case 3:
                case 4:
                    currencyNegativePattern = (currencyLocaleId == -1) ? 11 : 10;
                    break;
            }

            numberFormatInfo.CurrencySymbol = "€";
            numberFormatInfo.CurrencyPositivePattern = (currencyLocaleId == -1) ? 2 : 3;
            numberFormatInfo.CurrencyNegativePattern = currencyNegativePattern;
            numberFormatInfo.CurrencyDecimalDigits = (int) displayFormat;
        }

        private static void GetCombinedNumberFormatInfo(NumberFormatInfo numberFormatInfo, int currencyLocaleId,
                                                        SPNumberFormatTypes displayFormat)
        {
            var oldCurrencyPositivePattern = numberFormatInfo.CurrencyPositivePattern;
            var oldCurrencyNegativePattern = numberFormatInfo.CurrencyNegativePattern;
            var oldCurrencySymbol = numberFormatInfo.CurrencySymbol;
            var oldCurrencyDecimalDigits = numberFormatInfo.CurrencyDecimalDigits;

            var twoDecimals = displayFormat;
            if (twoDecimals == SPNumberFormatTypes.Automatic)
            {
                twoDecimals = SPNumberFormatTypes.TwoDecimals;
            }

            if ((currencyLocaleId == -2) || (currencyLocaleId == -1))
            {
                GetCombinedNumberFormatInfoForEuro(numberFormatInfo, currencyLocaleId, twoDecimals);
            }
            else
            {
                if (currencyLocaleId == -1055)
                {
                    currencyLocaleId = 0x41f;
                }

                try
                {
                    var numberFormat = CacheCurrencyFormats[currencyLocaleId] as NumberFormatInfo;
                    if (numberFormat == null)
                    {
                        var info2 = new CultureInfo(currencyLocaleId);
                        numberFormat = info2.NumberFormat;
                        CacheCurrencyFormats[currencyLocaleId] = numberFormat;
                    }
                    numberFormatInfo.CurrencyPositivePattern = numberFormat.CurrencyPositivePattern;
                    numberFormatInfo.CurrencyNegativePattern = numberFormat.CurrencyNegativePattern;
                    numberFormatInfo.CurrencySymbol = numberFormat.CurrencySymbol;
                    numberFormatInfo.CurrencyDecimalDigits = (int)twoDecimals;
                }
                catch (ArgumentException)
                {
                    numberFormatInfo.CurrencyPositivePattern = oldCurrencyPositivePattern;
                    numberFormatInfo.CurrencyNegativePattern = oldCurrencyNegativePattern;
                    numberFormatInfo.CurrencySymbol = oldCurrencySymbol;
                    numberFormatInfo.CurrencyDecimalDigits = oldCurrencyDecimalDigits;
                }
            }
        }

        public override void RenderSumFieldData(HtmlTextWriter writer, double value)
        {
            if (fieldCalculated.OutputType == SPFieldType.Currency)
            {
                writer.Write(string.Format(TotalStringFormat, value.ToString("C", CurrencyFormat)));
            }
            else
            {
                var currentCulture = Thread.CurrentThread.CurrentCulture;
                var number = SPFieldNumber.GetFieldValueAsHtml(value, currentCulture, fieldCalculated.ShowAsPercentage,
                                                               fieldCalculated.DisplayFormat);
                writer.Write(string.Format(TotalStringFormat, number));
            }
        }

        public override Dictionary<string, string> GetFilterValues(DataTable dt)
        {
            Dictionary<string, string> dictionary;

            switch (fieldCalculated.OutputType)
            {
                case SPFieldType.Number:
                    dictionary = dt.AsEnumerable()
                        .Select(item => item[FieldName])
                        .Distinct(new GenericEqualityComparer()).OrderBy(item => item, new GenericComparer<double>())
                        .ToDictionary(FormatNumber, FormatNumberValue);
                    break;
                case SPFieldType.Currency:
                    dictionary = dt.AsEnumerable()
                        .Select(item => item[FieldName])
                        .Distinct(new GenericEqualityComparer()).OrderBy(item => item, new GenericComparer<double>())
                        .ToDictionary(FormatNumber, FormatCurrencyValue);
                    break;
                case SPFieldType.Boolean:
                    dictionary = dt.AsEnumerable()
                        .Select(item => item[FieldName]).Distinct(new GenericEqualityComparer()).OrderBy(
                            item => item, new GenericComparer<bool>())
                        .ToDictionary(FormatBoolean, FormatBooleanValue);
                    break;
                case SPFieldType.DateTime:
                    dictionary = dt.AsEnumerable().Select(item => item[FieldName])
                        .Distinct(new GenericEqualityComparer()).OrderBy(item => item,
                                                                         new GenericComparer<DateTime>())
                        .ToDictionary(FormatDateTime, FormatDateTimeValue);
                    break;
                default:
                    dictionary = dt.AsEnumerable().Select(item => item[FieldName])
                        .Distinct(new GenericEqualityComparer())
                        .OrderBy(item => item, new GenericComparer<string>())
                        .ToDictionary(FormatString, FormatStringValue);
                    break;
            }

            return dictionary;
        }

        private string FormatCurrencyValue(object obj)
        {
            if (obj is DBNull)
            {
                return LocalizationHelper.GetString("BaseFieldRef_MS003");
            }

            if (obj is double)
            {
                return ((double) obj).ToString("C", CurrencyFormat);
            }

            return DataViewUtils.TrimStringOverMaxLength(obj.ToString());
        }

        private static string FormatNumber(object obj)
        {
            if (obj is DBNull)
            {
                return string.Empty;
            }

            if (obj is double)
            {
                return ((double)obj).ToString("N", CultureInfo.InvariantCulture);
            }

            return obj.ToString();
        }

        private string FormatNumberValue(object obj)
        {
            if (obj is DBNull)
            {
                return LocalizationHelper.GetString("BaseFieldRef_MS003");
            }

            if (obj is double)
            {
                var currentCulture = Thread.CurrentThread.CurrentCulture;
                return SPFieldNumber.GetFieldValueAsHtml((double) obj, currentCulture, fieldCalculated.ShowAsPercentage,
                                                         fieldCalculated.DisplayFormat);
            }
            return DataViewUtils.TrimStringOverMaxLength(obj.ToString());
        }

        private static string FormatString(object obj)
        {
            if (obj is DBNull)
            {
                return "";
            }

            return Convert.ToString(obj);
        }

        private static string FormatStringValue(object obj)
        {
            if (obj is DBNull)
            {
                return LocalizationHelper.GetString("BaseFieldRef_MS003");
            }

            return DataViewUtils.TrimStringOverMaxLength(Convert.ToString(obj));
        }

        private static string FormatBooleanValue(object obj)
        {
            if (obj is DBNull)
            {
                return LocalizationHelper.GetString("BaseFieldRef_MS003");
            }

            if (obj is bool)
            {
                return ((bool)obj) ? LocalizationHelper.GetString("BooleanFieldRef_MS001") : LocalizationHelper.GetString("BooleanFieldRef_MS002");
            }

            return DataViewUtils.TrimStringOverMaxLength(obj.ToString());
        }

        private static string FormatBoolean(object obj)
        {
            if (obj is DBNull)
            {
                return "";
            }

            if (obj is bool)
            {
                return ((bool) obj) ? "1" : "0";
            }

            return obj.ToString();
        }

        private static string FormatDateTimeValue(object obj)
        {
            if (obj is DBNull)
            {
                return LocalizationHelper.GetString("BaseFieldRef_MS003");
            }

            if (obj is DateTime)
            {
                return ((DateTime) obj).ToShortDateString();
            }

            return DataViewUtils.TrimStringOverMaxLength(obj.ToString());
        }

        private static string FormatDateTime(object obj)
        {
            if (obj is DateTime)
            {
                return ((DateTime) obj).ToString("d", CultureInfo.InvariantCulture);
            }

            if (obj is DBNull)
            {
                return "";
            }

            return obj.ToString();
        }

        private static double ConvertToDouble(object obj)
        {
            if (obj is double)
            {
                return (double) obj;
            }
            return 0;
        }

        public override string[] GetFilterQuery()
        {
            switch (fieldCalculated.OutputType)
            {
                case SPFieldType.Number:
                case SPFieldType.Currency:
                    if (string.IsNullOrEmpty(FilterValue))
                    {
                        return new []{string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName)};
                    }

                    try
                    {
                        var number = Convert.ToDouble(FilterValue, CultureInfo.InvariantCulture);
                        var maxValue = RoundUp(number);

                        if (number == 0)
                        {
                            return new []
                                       {
                                           string.Format("<Geq><FieldRef Name='{0}' /><Value Type='Number'>{1}</Value></Geq>", InternalFieldName, number.ToString(CultureInfo.InvariantCulture)),
                                           string.Format("<Lt><FieldRef Name='{0}' /><Value Type='Number'>{1}</Value></Lt>", InternalFieldName, maxValue)
                                       };
                        }

                        return new[]
                                       {
                                           string.Format("<Geq><FieldRef Name='{0}' /><Value Type='Number'>{1}</Value></Geq>", InternalFieldName, number.ToString(CultureInfo.InvariantCulture)),
                                           string.Format("<Lt><FieldRef Name='{0}' /><Value Type='Number'>{1}</Value></Lt>", InternalFieldName, maxValue)
                                       };
                    }
                    catch (FormatException)
                    {
                        return new []{string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Text'><![CDATA[{1}]]></Value></Eq>",
                                             InternalFieldName, FilterValue)};
                    }
                case SPFieldType.DateTime:
                    if (string.IsNullOrEmpty(FilterValue))
                        return new []{string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName)};

                    try
                    {
                        var dt = Convert.ToDateTime(FilterValue, CultureInfo.InvariantCulture);
                        var iso8601DateTime = SPUtility.CreateISO8601DateTimeFromSystemDateTime(dt);

                        return new []{string.Format("<Eq><FieldRef Name='{0}' /><Value Type='DateTime' IncludeTimeValue='FALSE'>{1}</Value></Eq>",
                                InternalFieldName, iso8601DateTime)};
                    }
                    catch (FormatException)
                    {
                        return new []{string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Text'><![CDATA[{1}]]></Value></Eq>",
                                             InternalFieldName, FilterValue)};
                    }
                case SPFieldType.Boolean:
                    if (string.IsNullOrEmpty(FilterValue))
                        return new []{string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName)};

                    if (FilterValue == "0" || FilterValue == "1")
                    {
                        return new []{string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Boolean'>{1}</Value></Eq>", InternalFieldName, FilterValue)};
                    }
                    
                    return new []{string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Text'><![CDATA[{1}]]></Value></Eq>",
                                         InternalFieldName, FilterValue)};
                default:
                    return base.GetFilterQuery();
            }
        }

        private static string RoundUp(double value)
        {
            var str = value.ToString(CultureInfo.InvariantCulture);
            var split = str.Split('.');

            if (split.Length == 1)
            {
                return (Convert.ToInt64(split[0]) + 1).ToString();
            }

            var decimalStr = split[1];
            decimalStr = decimalStr.TrimEnd('0');
            if (string.IsNullOrEmpty(decimalStr))
            {
                decimalStr = "0";
            }

            var val = Convert.ToInt64(decimalStr) + 1;
            return split[0] + "." + val;
        }

        public override double GetSumFieldData(DataTable dt)
        {
            return dt.AsEnumerable().Sum(item => ConvertToDouble(item[FieldName]));
        }

        public override double GetSumFieldData(DataTable dt, Func<DataRow, bool> whereCondition)
        {
            return dt.AsEnumerable().Where(whereCondition).Sum(item => ConvertToDouble(item[FieldName]));
        }

        public override string GetFilterCamlQuery()
        {
            if (string.IsNullOrEmpty(FilterValue))
            {
                return string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName);
            }

            var filterValue = FilterValue.Substring(2);

            switch (fieldCalculated.OutputType)
            {
                case SPFieldType.Number:
                case SPFieldType.Currency:
                    return string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Number'>{1}</Value></Eq>", InternalFieldName, filterValue);
                case SPFieldType.DateTime:
                    try
                    {
                        var dt = Convert.ToDateTime(filterValue, CultureInfo.InvariantCulture);
                        return string.Format("<Eq><FieldRef Name='{0}' /><Value Type='DateTime' IncludeTimeValue='FALSE'>{1}</Value></Eq>", InternalFieldName, SPUtility.CreateISO8601DateTimeFromSystemDateTime(dt));
                    }
                    catch (FormatException)
                    {
                        return string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Text'>{1}</Value></Eq>", InternalFieldName, filterValue);
                    }
                case SPFieldType.Boolean:
                    return string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Boolean'>{1}</Value></Eq>", InternalFieldName, filterValue);
                default:
                    return string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Text'><![CDATA[{1}]]></Value></Eq>", InternalFieldName, filterValue);
            }
        }

        public override string GetCellTextValue(DataRow row)
        {
            var value = row[FieldName];
            if (value is DBNull)
            {
                return DefaultValue;
            }

            if (value is string)
            {
                goto Return;
            }

            switch (fieldCalculated.OutputType)
            {
                case SPFieldType.Currency:
                    return ((double)value).ToString("C", CurrencyFormat);
                case SPFieldType.Number:
                    var currentCulture = Thread.CurrentThread.CurrentCulture;
                    return SPFieldNumber.GetFieldValueAsText((double)value, currentCulture, fieldCalculated.ShowAsPercentage, fieldCalculated.DisplayFormat);
                case SPFieldType.Boolean:
                    return SPFieldBoolean.GetFieldValueAsText((bool)value);
                case SPFieldType.DateTime:
                    var dateFormat = fieldCalculated.DateFormat == SPDateTimeFieldFormatType.DateTime ? SPDateFormat.DateTime : SPDateFormat.DateOnly;
                    return SPFieldDateTime.GetFieldValueAsText((DateTime)value, SPContext.Current.Web, dateFormat);
            }

            Return:
            return SPEncode.HtmlEncode((string) value);
        }
    }
}