﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Web.UI;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class NumberFieldRef : BaseFieldRef, IGroupFieldRef
    {
        private SPFieldNumber numberField;

        public NumberFieldRef()
        {
            EmptyGroupString = LocalizationHelper.GetString("BaseFieldRef_MS004");
        }

        public override bool SupportSumFieldData
        {
            get { return true; }
        }

        public bool CollapsedGroup { get; set; }

        /// <summary>
        /// Gets or sets the format of the number displayed.
        /// </summary>
        public string CustomFormat { get; set; }

        public override SPFieldType FieldType
        {
            get { return SPFieldType.Number; }
        }

        public override bool TextAlignRight
        {
            get { return true; }
        }

        #region IGroupFieldRef Members

        public override void Initialize(SPField field)
        {
            base.Initialize(field);
            numberField = (SPFieldNumber) field;
        }

        public string GetGroupFieldRef(string sortField, string sortDir)
        {
            ListSortDirection sortDirection;
            if (InternalFieldName.Equals(sortField))
            {
                sortDirection = sortDir == "ASC" ? ListSortDirection.Ascending : ListSortDirection.Descending;
            }
            else
            {
                sortDirection = SortDirection;
            }

            return string.Format(sortDirection == ListSortDirection.Ascending
                                     ? "<FieldRef Name='{0}' />"
                                     : "<FieldRef Name='{0}' Ascending='FALSE' />", InternalFieldName);
        }

        public bool CountGroupItems { get; set; }

        public bool SumGroupFieldData { get; set; }

        public IGroupFieldRef ParentGroup { get; set; }

        public string EmptyGroupString { get; set; }

        public ListSortDirection SortDirection { get; set; }

        public Expression<Func<DataRow, bool>> AddFilterExpression(Expression<Func<DataRow, bool>> filter,
                                                                   IGrouping<object, DataRow> group)
        {
            var flag = (group.Key is DBNull);
            if (flag)
            {
                return filter.And(item => IsDBNull(item, FieldName));
            }

            var value = (double) group.Key;
            return filter.And(item => CompareNumber(item, FieldName, value));
        }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(DataTable dt)
        {
            return dt.AsEnumerable().GroupBy(g => g[FieldName]);
        }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(IGrouping<object, DataRow> grouping)
        {
            return grouping.GroupBy(item => item[FieldName]);
        }

        public virtual void RenderCell(HtmlTextWriter writer, IGrouping<object, DataRow> grouping)
        {
            if (grouping.Key != null && !(grouping.Key is DBNull))
            {
                var number = (double) grouping.Key;
                writer.Write(!string.IsNullOrEmpty(CustomFormat)
                                 ? number.ToString(CustomFormat)
                                 : numberField.GetFieldValueAsText(number));
            }
            else
            {
                writer.Write(EmptyGroupString);
            }
        }

        public override void RenderCell(HtmlTextWriter writer, DataRow row)
        {
            var value = row[FieldName];
            if (value == null || value is DBNull)
            {
                writer.Write(DefaultValue);
                return;
            }

            var number = (double) value;
            writer.Write(string.IsNullOrEmpty(CustomFormat)
                             ? numberField.GetFieldValueAsText(number)
                             : number.ToString(CustomFormat));
        }

        #endregion

        private static bool CompareNumber(DataRow row, string name, double number)
        {
            var value = row[name];
            if (value == null || value is DBNull)
            {
                return false;
            }

            return Convert.ToDouble(value) == number;
        }

        private static bool IsDBNull(DataRow row, string name)
        {
            var value = row[name];
            var flag = value is DBNull;
            return flag;
        }

        public override void RenderSumFieldData(HtmlTextWriter writer, double value)
        {
            writer.Write(string.IsNullOrEmpty(CustomFormat)
                             ? string.Format(TotalStringFormat, numberField.GetFieldValueAsText(value))
                             : string.Format(TotalStringFormat, value.ToString(CustomFormat)));
        }

        public override Dictionary<string, string> GetFilterValues(DataTable dt)
        {
            var dictionary = dt.AsEnumerable()
                .Select(item => ConvertToDouble(item[FieldName]))
                .Distinct().OrderBy(item => item)
                .ToDictionary(item => item == double.MinValue ? "" : item.ToString(CultureInfo.InvariantCulture),
                              item => item == double.MinValue ? LocalizationHelper.GetString("BaseFieldRef_MS003") : FormatNumber(item));
            return dictionary;
        }

        private string FormatNumber(double item)
        {
            return string.IsNullOrEmpty(CustomFormat) ? numberField.GetFieldValueAsText(item) : item.ToString(CustomFormat);
        }

        protected double ConvertToDouble(object obj)
        {
            if (obj is DBNull)
            {
                return double.MinValue;
            }

            int roundDigits;
            switch (numberField.DisplayFormat)
            {
                case SPNumberFormatTypes.NoDecimal:
                    roundDigits = 0;
                    break;
                case SPNumberFormatTypes.OneDecimal:
                    roundDigits = 1;
                    break;
                case SPNumberFormatTypes.ThreeDecimals:
                    roundDigits = 3;
                    break;
                case SPNumberFormatTypes.FourDecimals:
                    roundDigits = 5;
                    break;
                case SPNumberFormatTypes.FiveDecimals:
                    roundDigits = 5;
                    break;
                default:
                    roundDigits = 2;
                    break;
            }

            return Math.Round(Convert.ToDouble(obj), roundDigits);
        }

        public override string[] GetFilterQuery()
        {
            if (string.IsNullOrEmpty(FilterValue))
            {
                return new []{string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName)};
            }

            return new []{string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Number'>{1}</Value></Eq>", InternalFieldName, FilterValue)};
        }

        public override double GetSumFieldData(DataTable dt)
        {
            var roundDigits = GetRoundDigits();
            return dt.AsEnumerable().Sum(item => ConvertToDouble(item[FieldName], roundDigits));
        }

        private static double ConvertToDouble(object obj, int roundDigits)
        {
            if (obj == null || obj is DBNull)
            {
                return 0;
            }

            return Math.Round(Convert.ToDouble(obj), roundDigits);
        }

        public override double GetSumFieldData(DataTable dt, Func<DataRow, bool> whereCondition)
        {
            var roundDigits = GetRoundDigits();
            return dt.AsEnumerable().Where(whereCondition).Sum(item => ConvertToDouble(item[FieldName], roundDigits));
        }

        private int GetRoundDigits()
        {
            switch (numberField.DisplayFormat)
            {
                case SPNumberFormatTypes.NoDecimal:
                    return 0;
                case SPNumberFormatTypes.OneDecimal:
                    return 1;
                case SPNumberFormatTypes.ThreeDecimals:
                    return 3;
                case SPNumberFormatTypes.FourDecimals:
                    return 4;
                case SPNumberFormatTypes.FiveDecimals:
                    return 5;
                default:
                    return 2;
            }
        }

        public override string GetFilterCamlQuery()
        {
            return string.IsNullOrEmpty(FilterValue) ?
                            string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName) :
                            string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Number'>{1}</Value></Eq>", InternalFieldName, FilterValue);
        }

        public override string GetCellTextValue(DataRow row)
        {
            var value = row[FieldName];
            if (value is DbType)
            {
                return DefaultValue;
            }

            if (string.IsNullOrEmpty(CustomFormat))
            {
                return numberField.GetFieldValueAsText(value);    
            }

            return Utils.Cast<double>(value).ToString(CustomFormat);
        }
    }
}