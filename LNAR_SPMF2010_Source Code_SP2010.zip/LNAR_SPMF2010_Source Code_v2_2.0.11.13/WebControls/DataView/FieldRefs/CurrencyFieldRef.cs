﻿using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class CurrencyFieldRef : NumberFieldRef
    {
        public override SPFieldType FieldType
        {
            get { return SPFieldType.Currency; }
        }
    }
}