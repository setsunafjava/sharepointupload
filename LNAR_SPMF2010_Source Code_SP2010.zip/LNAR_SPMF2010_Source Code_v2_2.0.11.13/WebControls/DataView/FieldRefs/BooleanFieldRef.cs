﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Web.UI;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class BooleanFieldRef : BaseFieldRef, IGroupFieldRef
    {
        private SPFieldBoolean booleanField;

        public BooleanFieldRef()
        {
            EmptyGroupString = LocalizationHelper.GetString("BaseFieldRef_MS004");
        }

        public override SPFieldType FieldType
        {
            get { return SPFieldType.Boolean; }
        }

        #region IGroupFieldRef Members

        public bool CountGroupItems { get; set; }

        public bool SumGroupFieldData { get; set; }

        public bool CollapsedGroup { get; set; }

        IGroupFieldRef IGroupFieldRef.ParentGroup { get; set; }

        public string EmptyGroupString { get; set; }

        public ListSortDirection SortDirection { get; set; }

        public Expression<Func<DataRow, bool>> AddFilterExpression(Expression<Func<DataRow, bool>> filter,
                                                                   IGrouping<object, DataRow> group)
        {
            if (group.Key is DBNull)
            {
                return filter.And(item => DataViewUtils.IsDBNull(item, FieldName));
            }

            var dt = (bool) group.Key;
            return filter.And(item => DataViewUtils.CompareBooleanObject(dt, item[FieldName]));
        }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(DataTable dt)
        {
            return dt.AsEnumerable().GroupBy(g => g[FieldName]);
        }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(IGrouping<object, DataRow> grouping)
        {
            return grouping.GroupBy(item => item[FieldName]);
        }

        public virtual void RenderCell(HtmlTextWriter writer, IGrouping<object, DataRow> grouping)
        {
            if (grouping.Key != null && !(grouping.Key is DBNull))
            {
                var key = (bool) grouping.Key;
                writer.Write(key ? LocalizationHelper.GetString("BooleanFieldRef_MS001") : LocalizationHelper.GetString("BooleanFieldRef_MS002"));
            }
            else
            {
                writer.Write(EmptyGroupString);
            }
        }

        public string GetGroupFieldRef(string sortField, string sortDir)
        {
            ListSortDirection sortDirection;
            if (InternalFieldName.Equals(sortField))
            {
                sortDirection = sortDir == "ASC" ? ListSortDirection.Ascending : ListSortDirection.Descending;
            }
            else
            {
                sortDirection = SortDirection;
            }

            return string.Format(sortDirection == ListSortDirection.Ascending
                                     ? "<FieldRef Name='{0}' />"
                                     : "<FieldRef Name='{0}' Ascending='FALSE' />", InternalFieldName);
        }

        public override void RenderCell(HtmlTextWriter writer, DataRow row)
        {
            writer.Write(GetCellTextValue(row));
        }

        #endregion

        public override Dictionary<string, string> GetFilterValues(DataTable dt)
        {
            var dictionary = dt.AsEnumerable().Select(item => item[FieldName])
                .Distinct().OrderBy(item => item, new BooleanComparer())
                .ToDictionary(SelectDictionaryKey, SelectDictionaryValue);

            return dictionary;
        }

        private static string SelectDictionaryValue(object obj)
        {
            if (obj is DBNull)
            {
                return LocalizationHelper.GetString("BaseFieldRef_MS003");
            }

            return (bool)obj ? LocalizationHelper.GetString("BooleanFieldRef_MS001") : LocalizationHelper.GetString("BooleanFieldRef_MS002");
        }

        private static string SelectDictionaryKey(object obj)
        {
            if (obj is DBNull)
            {
                return "";
            }

            return (bool) obj ? "1" : "0";
        }

        public override string GetFilterCamlQuery()
        {
            return string.IsNullOrEmpty(FilterValue) ? 
                string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName) : 
                string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Boolean'>{1}</Value></Eq>", InternalFieldName, FilterValue);
        }

        public class BooleanComparer : IComparer<object >
        {
            public int Compare(object x, object y)
            {
                if (x is DBNull && y is DBNull)
                {
                    return 0;
                }

                if (x is DBNull)
                {
                    return -1;
                }

                if (y is DBNull)
                {
                    return 1;
                }

                var x1 = (bool) x;
                var y1 = (bool) y;
                return x1.CompareTo(y1);
            }
        }

        public override string GetCellTextValue(DataRow row)
        {
            var value = row[FieldName];
            if (value is DBNull)
            {
                return DefaultValue;
            }

            return booleanField.GetFieldValueAsText(value);
        }

        public override void Initialize(SPField field)
        {
            base.Initialize(field);
            booleanField = (SPFieldBoolean) field;
        }
    }
}