﻿using System;
using System.Data;
using System.Web.UI;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class AutoNumberFieldRef : BaseFieldRef
    {
        public AutoNumberFieldRef()
        {
            FieldName = "RowIndex";
            InternalFieldName = "RowIndex";
        }

        public override bool IsVirtualField
        {
            get { return true; }
        }

        public override bool Sortable
        {
            get { return false; }
            set { base.Sortable = value; }
        }

        public override bool Filterable
        {
            get { return false; }
            set { base.Filterable = value; }
        }

        public override void RenderCell(HtmlTextWriter writer, DataRow row)
        {
            var value = row[FieldName];
            if (value != null)
            {
                writer.Write(Convert.ToInt32(value) + 1);
            }
            else
            {
                writer.Write(DefaultValue);
            }
        }

        public override string GetFilterCamlQuery()
        {
            throw new NotSupportedException();
        }

        public override string GetCellTextValue(DataRow row)
        {
            throw new NotSupportedException();
        }
    }
}