﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class AttachmentFieldRef : BaseFieldRef
    {
        public AttachmentFieldRef()
        {
            FieldName = "Attachments";
        }

        public override SPFieldType FieldType
        {
            get { return SPFieldType.Attachments; }
        }

        public override bool Filterable
        {
            get { return true; }
            set { base.Filterable = value; }
        }

        public override void RenderCell(HtmlTextWriter writer, DataRow row)
        {
            var value = row[FieldName];
            if (value == null)
            {
                writer.Write("&nbsp;");
            }
            else
            {
                if ((bool) value)
                {
                    writer.Write(
                        "<img title=\"Attachment\" class=\"ms-vb-lvitemimg\" alt=\"Attachment\" src=\"/_layouts/images/attach.gif\" border=\"0\" />");
                }
                else
                {
                    writer.Write("&nbsp;");
                }
            }
        }

        public override Dictionary<string, string> GetFilterValues(DataTable dt)
        {
            var dictionary = new Dictionary<string, string>();
            if (!string.IsNullOrEmpty(FilterValue))
            {
                dictionary.Add(FilterValue, FilterValue == "0" ? SPResource.GetString("No") : SPResource.GetString("Yes"));
            }
            else
            {
                dictionary.Add("0", SPResource.GetString("No"));
                dictionary.Add("1", SPResource.GetString("Yes"));
            }
            
            return dictionary;
        }

        public override string[] GetFilterQuery()
        {
            if (FilterValue == "0")
            {
                return new[] {"<Eq><FieldRef Name='Attachments' /><Value Type='Attachments'>0</Value></Eq>"};
            }

            return new []{"<Eq><FieldRef Name='Attachments' /><Value Type='Attachments'>1</Value></Eq>"};
        }

        public override string GetFilterCamlQuery()
        {
            return string.Format("<Eq><FieldRef Name='Attachments' /><Value Type='Attachments'>{0}</Value></Eq>", FilterValue);
        }

        public override string GetCellTextValue(DataRow row)
        {
            throw new NotSupportedException();
        }
    }
}