﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Web.UI;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class DateTimeFieldRef : BaseFieldRef, IGroupFieldRef
    {
        private SPFieldDateTime dateTimeField;

        public DateTimeFieldRef()
        {
            EmptyGroupString = LocalizationHelper.GetString("BaseFieldRef_MS004");
        }

        public override SPFieldType FieldType
        {
            get { return SPFieldType.DateTime; }
        }

        public bool DateOnly { get; set; }

        public string CustomDateFormat { get; set; }

        #region IGroupFieldRef Members

        public bool CountGroupItems { get; set; }

        public bool SumGroupFieldData { get; set; }

        public bool CollapsedGroup { get; set; }

        public IGroupFieldRef ParentGroup { get; set; }

        public string EmptyGroupString { get; set; }

        public ListSortDirection SortDirection { get; set; }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(DataTable dt)
        {
            return dt.AsEnumerable().GroupBy(g => g[FieldName], new DateOnlyComparer());
        }

        public IEnumerable<IGrouping<object, DataRow>> GetGroupBy(IGrouping<object, DataRow> grouping)
        {
            return grouping.GroupBy(item => item[FieldName], new DateOnlyComparer());
        }

        public Expression<Func<DataRow, bool>> AddFilterExpression(Expression<Func<DataRow, bool>> filter,
                                                                   IGrouping<object, DataRow> group)
        {
            var flag = (group.Key is DBNull);
            if (flag)
            {
                return filter.And(item => DataViewUtils.IsDBNull(item, FieldName));
            }

            var dt = (DateTime) group.Key;
            return filter.And(item => DataViewUtils.CompareDateObject(dt, item[FieldName]));
        }

        public virtual void RenderCell(HtmlTextWriter writer, IGrouping<object, DataRow> grouping)
        {
            if (grouping.Key != null && !(grouping.Key is DBNull))
            {
                var dt = (DateTime) grouping.Key;
                if (dt == DateTime.MinValue)
                {
                    writer.Write(DefaultValue);
                    return;
                }
                var groupHeader = dt.ToString("d");
                writer.Write(groupHeader);
            }
            else
            {
                writer.Write(EmptyGroupString);
            }
        }

        public string GetGroupFieldRef(string sortField, string sortDir)
        {
            ListSortDirection sortDirection;
            if (InternalFieldName.Equals(sortField))
            {
                sortDirection = sortDir == "ASC" ? ListSortDirection.Ascending : ListSortDirection.Descending;
            }
            else
            {
                sortDirection = SortDirection;
            }

            return string.Format(sortDirection == ListSortDirection.Ascending
                                     ? "<FieldRef Name='{0}' />"
                                     : "<FieldRef Name='{0}' Ascending='FALSE' />", InternalFieldName);
        }

        public override void RenderCell(HtmlTextWriter writer, DataRow row)
        {
            var value = row[FieldName];
            if (value == null || value is DBNull)
            {
                writer.Write(DefaultValue);
            }
            else
            {
                var dt = (DateTime) value;
                if (!string.IsNullOrEmpty(CustomDateFormat))
                {
                    writer.Write(dt.ToString(CustomDateFormat));
                }
                else
                {
                    writer.Write(dateTimeField.DisplayFormat == SPDateTimeFieldFormatType.DateOnly
                                     ? dt.ToString("d")
                                     : dt.ToString("g"));
                }
            }
        }

        #endregion

        public override Dictionary<string, string> GetFilterValues(DataTable dt)
        {
            var dictionary = dt.AsEnumerable().Select(item => item[FieldName])
                .Distinct(new DateOnlyComparer()).OrderBy(item => item, new DateTimeComparer())
                .Select(ConvertToDateTime)
                .ToDictionary(
                    item => item == DateTime.MinValue ? "" : item.ToString("d", CultureInfo.InvariantCulture),
                    item => item == DateTime.MinValue ? LocalizationHelper.GetString("BaseFieldRef_MS003") : item.ToString("d"));

            return dictionary;
        }

        private static DateTime ConvertToDateTime(object obj)
        {
            if (obj is DateTime)
            {
                return (DateTime) obj;
            }
            return DateTime.MinValue;
        }

        public override string[] GetFilterQuery()
        {
            if (string.IsNullOrEmpty(FilterValue))
                return new []{string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName)};

            var dt = Convert.ToDateTime(FilterValue, CultureInfo.InvariantCulture);
            var iso8601DateTime = SPUtility.CreateISO8601DateTimeFromSystemDateTime(dt);

            return new []{string.Format("<Eq><FieldRef Name='{0}' /><Value Type='DateTime' IncludeTimeValue='FALSE'>{1}</Value></Eq>", InternalFieldName, iso8601DateTime)};
        }

        public override string GetFilterCamlQuery()
        {
            if (string.IsNullOrEmpty(FilterValue))
            {
                return string.Format("<IsNull><FieldRef Name='{0}' /></IsNull>", InternalFieldName);
            }
            var dt = Convert.ToDateTime(FilterValue);
            return string.Format("<Eq><FieldRef Name='{0}' /><Value Type='DateTime' IncludeTimeValue='FALSE'>{1}</Value></Eq>",
                        InternalFieldName, SPUtility.CreateISO8601DateTimeFromSystemDateTime(dt));
        }

        public override string GetCellTextValue(DataRow row)
        {
            var value = row[FieldName];
            if (value is DBNull)
            {
                return DefaultValue;
            }

            var dt = (DateTime) value;
            return string.IsNullOrEmpty(CustomDateFormat) ? dateTimeField.GetFieldValueAsText(dt) : dt.ToString(CustomDateFormat);
        }

        public override void Initialize(SPField field)
        {
            base.Initialize(field);
            dateTimeField = (SPFieldDateTime) field;
        }
    }
}