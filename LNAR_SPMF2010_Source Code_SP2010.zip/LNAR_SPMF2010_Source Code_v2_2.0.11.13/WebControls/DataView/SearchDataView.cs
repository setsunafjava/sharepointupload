﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Search.Query;
using Microsoft.SharePoint.Utilities;
using SortDirection = Microsoft.SharePoint.Search.Query.SortDirection;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class SearchDataView : ListDataView
    {
        private Button btnClear;
        private Button btnSearch;
        private string contentClass;
        private TextBox txtKeyword;
        private Exception exception;
        private int totalRows;

        protected override bool SupportAggregationFunctions
        {
            get { return false; }
        }

        /// <summary>
        ///   Content Class, default is STS_ListItem_GenericList
        /// </summary>
        public string ContentClass
        {
            get { return contentClass ?? "STS_ListItem_GenericList"; }
            set { contentClass = value; }
        }

        public bool ShowSearchBox
        {
            get
            {
                var value = ViewState["ShowSearchBox"];
                if (value != null)
                {
                    return (bool) value;
                }
                return true;
            }
            set { ViewState["ShowSearchBox"] = value; }
        }

        public override string WhereCondition
        {
            get { return base.WhereCondition; }
            set { throw new NotSupportedException("Search Data View does not support WhereCondition property."); }
        }

        /// <summary>
        /// A keyword will include user keyword to searching
        /// </summary>
        public string AdditionalKeyword
        {
            get
            {
                var value = ViewState["AdditionalKeyword"];
                if (value != null)
                {
                    return (string)value;
                }
                return string.Empty;
            }
            set { ViewState["AdditionalKeyword"] = value; }
        }

        /// <summary>
        /// Default value display on search textbox
        /// </summary>
        public string DefaultKeyword
        {
            get
            {
                var value = ViewState["DefaultKeyword"];
                if (value != null)
                {
                    return (string)value;
                }
                return string.Empty;
            }
            set { ViewState["DefaultKeyword"] = value; }
        }

        [DefaultValue(true)]
        public bool LoadInitialView
        {
            get
            {
                var value = ViewState["LoadInitialView"];
                if (value != null)
                {
                    return (bool)value;
                }
                return true;
            }
            set { ViewState["LoadInitialView"] = value; }
        }

        protected override void CreateChildControls()
        {
            foreach (var viewField in ViewFields.Cast<BaseFieldRef>())
            {
                viewField.Filterable = false;
                viewField.Sortable = false;
            }

            base.CreateChildControls();

            if (ShowSearchBox)
            {
                txtKeyword = new TextBox
                                 {
                                     ID = "txtKeyword",
                                     CssClass = "ms-input",
                                     Text = Page.Request.QueryString["k"]
                                 };
                if (!Page.IsPostBack && string.IsNullOrEmpty(txtKeyword.Text))
                {
                    txtKeyword.Text = DefaultKeyword;
                }
                Controls.Add(txtKeyword);

                btnSearch = new Button { ID = "btnSearch", Text = LocalizationHelper.GetString("SearchDataView_MS001"), CssClass = "ms-ButtonHeightWidth" };
                Controls.Add(btnSearch);

                btnClear = new Button { ID = "btnClear", Text = LocalizationHelper.GetString("SearchDataView_MS002"), CssClass = "ms-ButtonHeightWidth" };
                Controls.Add(btnClear);
            }
        }

        protected override void BindDataSource()
        {
            var searchText = Page.Request.QueryString["k"];
            if (string.IsNullOrEmpty(searchText))
            {
                if (LoadInitialView)
                {
                    base.BindDataSource();    
                }
                else
                {
                    DataSource = new DataTable();
                }
                return;
            }

            var defaultViewUrl = SPContext.Current.Site.MakeFullUrl(List.DefaultViewUrl);
            var searchScope = defaultViewUrl.Remove(defaultViewUrl.LastIndexOf("/"));
            var startRow = 0;
            var pageFirstRow = Page.Request.QueryString["PageFirstRow"];
            if (!string.IsNullOrEmpty(pageFirstRow))
            {
                startRow = Convert.ToInt32(pageFirstRow) - 1;
            }

            var hiddenConstraints = string.Format("site:\"{0}\" AND ContentClass:\"{1}\"", searchScope, ContentClass);
            if (!string.IsNullOrEmpty(AdditionalKeyword))
            {
                hiddenConstraints = " " + AdditionalKeyword;
            }

            var keywordQuery = new KeywordQuery(SPContext.Current.Site)
                                   {
                                       ResultTypes = ResultType.RelevantResults,
                                       StartRow = startRow,
                                       RowLimit = RowLimit,
                                       EnableUrlSmashing = true,
                                       TrimDuplicates = true,
                                       HiddenConstraints = hiddenConstraints,
                                       QueryText = searchText
                                   };
            keywordQuery.SortList.Add("Rank", SortDirection.Descending);

            ResultTableCollection searchResults;

            try
            {
                searchResults = keywordQuery.Execute();
            }
            catch(Exception ex)
            {
                exception = ex;
                return;
            }

            var queryResultsTable = searchResults[ResultType.RelevantResults];
            var queryDataTable = new DataTable();
            queryDataTable.Load(queryResultsTable, LoadOption.OverwriteChanges);

            if (queryDataTable.Rows.Count == 0)
            {
                DataSource = new DataTable();
                return;
            }

            var items = new List<SPListItem>();

            foreach (var id in from DataRow row in queryDataTable.Rows
                               select new Uri(row["Path"].ToString())
                               into path select HttpUtility.ParseQueryString(path.Query)
                               into queryString select Convert.ToInt32(queryString["ID"]))
            {
                try
                {
                    var item = List.GetItemById(id);
                    items.Add(item);
                }
                catch (ArgumentException)
                {
                    // @dSPACE: This item shows up in the search result since it was in the search metadata, 
                    // however it was deleted, therefore we do not process this item in the result view.
                }
            }

            var fieldNames = ViewFields.Cast<IViewFieldRef>().Where(item => !item.IsVirtualField).Select(viewField => viewField.FieldName).ToList();
            fieldNames.AddRange(GroupFields.Cast<IGroupFieldRef>().Select(groupField => groupField.FieldName));
            fieldNames.AddRange(new[] { "ID", "Created" });
            fieldNames = fieldNames.Distinct().ToList();

            var fields = fieldNames.Select(f => List.Fields[f]).ToList();

            DataTable dt = null;

            GetDataTable(items, fieldNames, fields, ref dt);
            DataSource = dt;

            totalRows = queryResultsTable.TotalRows;

            // Pagging
            var totalNumberOfPages = CalculateNumberOfPages(queryResultsTable.TotalRows, RowLimit);
            startRow++;
            var currentPage = CalculateNumberOfPages(startRow, RowLimit);
            if (currentPage < totalNumberOfPages)
            {
                NextPagePosition = "NextPagePosition=True";
            }

            if (currentPage > 1)
            {
                PrevPagePosition = "PrevPagePosition=True";
            }
        }

        private static int CalculateNumberOfPages(int totalNumberOfItems, int pageSize)
        {
	        var result = totalNumberOfItems % pageSize;
            if (result == 0)
                return totalNumberOfItems / pageSize;
            return totalNumberOfItems/pageSize + 1;
        }

        protected override int GetTotalItems()
        {
            return totalRows;
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (ShowSearchBox)
            {
                writer.AddStyleAttribute(HtmlTextWriterStyle.Margin, "10px 0px 10px 0px");
                writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
                writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "1");
                writer.RenderBeginTag(HtmlTextWriterTag.Table);
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "80px");
                writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingLeft, "5px");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.Write("Keywords:");
                writer.RenderEndTag(); // td

                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                txtKeyword.RenderControl(writer);
                writer.RenderEndTag(); // td

                writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingLeft, "5px");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);

                writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "auto !important;");
                btnSearch.RenderControl(writer);

                writer.RenderEndTag(); // td

                writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingLeft, "5px");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                
                writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "auto !important;");
                btnClear.RenderControl(writer);

                writer.RenderEndTag(); // td

                writer.RenderEndTag(); // tr
                writer.RenderEndTag(); // table
            }

            if (exception != null)
            {
                writer.AddStyleAttribute(HtmlTextWriterStyle.MarginLeft, "5px");
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-descriptiontext");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);

                if (exception is QueryMalformedException)
                {
                    writer.Write(exception.Message);
                }
                else
                {
                    writer.Write(LocalizationHelper.GetString("SearchResults_GenericError"));
                }
                
                writer.RenderEndTag(); // span

                return;
            }

            base.Render(writer);
        }

        protected override void RenderEmptyData(HtmlTextWriter writer)
        {
            if (!string.IsNullOrEmpty(txtKeyword.Text))
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Tbody);
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "100");
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.Write(string.Format(LocalizationHelper.GetString("SearchResults_ResultsNotFound"), SPEncode.HtmlEncode(txtKeyword.Text)));
                writer.RenderEndTag(); // td

                writer.RenderEndTag(); // tr
                writer.RenderEndTag(); // tbody    
            }
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (ShowSearchBox)
            {
                btnSearch.Click += btnSearch_Click;
                btnClear.Click += btnClear_Click;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            var queryString = HttpUtility.ParseQueryString(Page.Request.Url.Query);
            queryString["k"] = string.Empty;
            var url = Page.Request.Url.GetLeftPart(UriPartial.Path);
            Page.Response.Redirect(url + "?" + queryString, true);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var queryString = HttpUtility.ParseQueryString(Page.Request.Url.Query);
            queryString["k"] = txtKeyword.Text.Trim();
            queryString["PageFirstRow"] = string.Empty;
            var url = Page.Request.Url.GetLeftPart(UriPartial.Path);
            Page.Response.Redirect(url + "?" + queryString, true);
        }

        protected override int GetCountFieldData(BaseFieldRef fieldRef, Func<DataRow, bool> countCondition)
        {
            throw new NotImplementedException();
        }

        protected override double GetSumFieldData(BaseFieldRef fieldRef)
        {
            throw new NotImplementedException();
        }

        protected override double GetSumFieldData(BaseFieldRef fieldRef, Func<DataRow, bool> whereCondition)
        {
            throw new NotImplementedException();
        }

        protected override int CountGroupItems(IGroupFieldRef fieldRef, Func<DataRow, bool> filter)
        {
            throw new NotImplementedException();
        }

        protected override IDictionary<string, string> GetFilterValues(BaseFieldRef fieldRef)
        {
            throw new NotImplementedException();
        }
    }
}