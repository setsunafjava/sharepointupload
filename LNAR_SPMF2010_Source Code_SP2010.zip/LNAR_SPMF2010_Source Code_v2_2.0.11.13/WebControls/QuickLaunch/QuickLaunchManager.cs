﻿using System;
using System.Collections.Generic;
using System.Linq;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Configuration;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using DeutscheBank.SharePoint.LNAR.Framework.WebParts;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public static class QuickLaunchManager
    {
        internal const string VisibleContextCookieName = "DeutscheBank.SharePoint.LNAR.Framework.QuickLaunch.VisibleContext";

        public static QuickLaunchInitialState QuickLaunchInitialState
        {
            get { return ConfigurationManager.GetFromPropertyBag<QuickLaunchInitialState>(FrameworkConstants.QuickLaunchInitialState); }
        }

        public static bool EnableCollapsedExpanded
        {
            get { return ConfigurationManager.GetFromPropertyBag<bool>(FrameworkConstants.EnableCollapsedExpanded); }
        }

        public static void CreateQuickLaunchDataSource(SPWeb web)
        {
            var list = web.Lists.TryGetList(FrameworkConstants.QuickLaunchListName);

            if (list != null)
            {
                // Remove it
                list.Delete();
            }

            var helper = new ListHelper(web) {Title = FrameworkConstants.QuickLaunchListName};

            helper.AddField(new SingleLineTextFieldCreator("Description"));
            helper.AddField(new SingleLineTextFieldCreator("Url"));
            helper.AddField(new NumberFieldCreator("Position") {Required = true});
            helper.AddField(new LookupFieldCreator("ParentId") {LookupList = FrameworkConstants.QuickLaunchListName, LookupField = "ID"});
            helper.AddField(new SingleLineTextFieldCreator("ListId"));
            helper.AddField(new SingleLineTextFieldCreator("PermissionLevels"));
            helper.AddField(new BooleanFieldCreator("VisibleForAdminOnly"));
            helper.AddField(new BooleanFieldCreator("IsExternalUrl"));
            helper.AddField(new SingleLineTextFieldCreator("VisibleContext"));
            helper.AddField(new BooleanFieldCreator("SetVisibleContext"));
            helper.AddField(new SingleLineTextFieldCreator("TargetVisibleContext"));
            helper.AddField(new BooleanFieldCreator("DefaultCollapsed"));
            list = helper.Apply();

            list.Hidden = true;
            list.Update();

            // Create a page
            WebPageHelper.CreateDefaultWebPage(web, "QuickLaunchManager.aspx", true);
            WebPartHelper.AddWebPart(web, "QuickLaunchManager.aspx", new QuickLaunchManagerWebPart { Title = "Quick Launch Manager WebPart" }, "Main", 0);

            WebPageHelper.CreateDefaultWebPage(web, "QuickLaunchItem.aspx", true);
            WebPartHelper.AddWebPart(web, "QuickLaunchItem.aspx", new QuickLaunchItemWebPart { Title = "Quick Launch Item WebPart" }, "Main", 0);

            WebPageHelper.CreateDefaultWebPage(web, "QuickLaunchContext.aspx", true);
            WebPartHelper.AddWebPart(web, "QuickLaunchContext.aspx", new QuickLaunchContextWebPart { Title = "Quick Launch Context WebPart" }, "Main", 0);
        }

        /// <summary>
        /// Enable quick launch collape expande
        /// </summary>
        /// <param name="web"></param>
        /// <param name="initialState"></param>
        public static void EnabledCollapsedExpanded(SPWeb web, QuickLaunchInitialState initialState)
        {
            ConfigurationManager.SetInPropertyBag(web, FrameworkConstants.EnableCollapsedExpanded, true);
            ConfigurationManager.SetInPropertyBag(web, FrameworkConstants.QuickLaunchInitialState, initialState);
        }

        public static int AddHeading(SPWeb web, QuickLaunchItem item)
        {
            return AddNavigationLink(web, item, 0);
        }

        public static int AddNavigationLink(SPWeb web, QuickLaunchItem item, int parentId)
        {
            if (parentId < 0)
            {
                throw new ArgumentOutOfRangeException("parentId", "The parent id cannot be less than 0.");
            }

            var list = web.Lists[FrameworkConstants.QuickLaunchListName];
            var listItem = list.AddItem();
            listItem["Title"] = item.Title;
            listItem["Description"] = item.Description;

            if (string.IsNullOrEmpty(item.Url) && !item.SetVisibleContext)
            {
                listItem["Url"] = "javascript:void(0)";
                listItem["IsExternalUrl"] = true;
            }
            else
            {
                listItem["Url"] = item.Url;
                listItem["IsExternalUrl"] = item.IsExternalUrl;
            }
            
            listItem["Position"] = item.Position;

            if (parentId > 0)
            {
                listItem["ParentId"] = parentId;    
            }
            
            listItem["ListId"] = item.ListId;
            listItem["VisibleForAdminOnly"] = item.VisibleForAdminOnly;
            listItem["PermissionLevels"] = item.PermissionLevels;

            listItem["VisibleContext"] = item.VisibleContext;
            listItem["SetVisibleContext"] = item.SetVisibleContext;
            listItem["TargetVisibleContext"] = item.TargetVisibleContext;

            if (parentId == 0)
            {
                listItem["DefaultCollapsed"] = item.DefaultCollapsed;
            }

            listItem.Update();

            // Update id
            item.Id = listItem.ID;

            return listItem.ID;
        }

        public static IList<QuickLaunchItem> GetAllQuickLaunchHeading(SPWeb web)
        {
            return GetAllQuickLaunchItems(web).Where(item => item.ParentId == 0).OrderBy(item => item.Title).ToList();
        }

        public static IList<QuickLaunchItem> GetAllQuickLaunchItems(SPWeb web)
        {
            if (!web.DoesUserHavePermissions(SPBasePermissions.ManageWeb))
            {
                return GetAllQuickLaunchItems(web.Site.ID, web.ID);
            }

            var list = web.Lists[FrameworkConstants.QuickLaunchListName];
            return (from SPListItem item in list.Items select new QuickLaunchItem(item)).ToList();
        }

        private static IList<QuickLaunchItem> GetAllQuickLaunchItems(Guid siteId, Guid webId)
        {
            IList<QuickLaunchItem> items = null;
            SPSecurity.RunWithElevatedPrivileges(()=>
                                                     {
                                                         using (var site = new SPSite(siteId))
                                                         {
                                                             using (var web = site.OpenWeb(webId))
                                                             {
                                                                 items = GetAllQuickLaunchItems(web);
                                                             }
                                                         }
                                                     });
            return items;
        }

        public static QuickLaunchItem GetQuickLaunchItem(SPWeb web, int id)
        {
            if (!web.DoesUserHavePermissions(SPBasePermissions.ManageWeb))
            {
                return GetQuickLaunchItem(web.Site.ID, web.ID, id);
            }

            var list = web.Lists[FrameworkConstants.QuickLaunchListName];
            return new QuickLaunchItem(list.GetItemById(id));
        }

        private static QuickLaunchItem GetQuickLaunchItem(Guid siteId, Guid webId, int id)
        {
            QuickLaunchItem item = null;
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        item = GetQuickLaunchItem(web, id);
                    }
                }
            });
            return item;
        }
    }
}