﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Navigation;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class QuickLaunchProvider : SPNavigationProvider
    {
        private const string EmptyVisibleContextCamlQuery = "<IsNull><FieldRef Name='VisibleContext' /></IsNull>";
        private const string EqualVisibleContextCamlQuery = "<Eq><FieldRef Name='VisibleContext' /><Value Type='Text'>{0}</Value></Eq>";
        private const string EmptyParentHeadingCamlQuery = "<IsNull><FieldRef Name='ParentId' /></IsNull>";
        private const string EqualParentHeadingCamlQuery = "<Eq><FieldRef Name='ParentId' LookupId='TRUE' /><Value Type='Lookup'>{0}</Value></Eq>";
        private const string OrderByCamlQuery = "<OrderBy><FieldRef Name='Position' /></OrderBy>";

        private Hashtable permissions;
        
        public override SiteMapNodeCollection GetChildNodes(SiteMapNode node)
        {
            var web = SPContext.Current.Web;
            var list = web.Lists[FrameworkConstants.QuickLaunchListName];

            var cookie = HttpContext.Current.Request.Cookies[QuickLaunchManager.VisibleContextCookieName];
            var visibleContext = cookie == null ? string.Empty : cookie.Value;
            return GetChildNodes(0, web, list, visibleContext);
        }

        private SiteMapNodeCollection GetChildNodes(int parentId, SPWeb web, SPList list, string visibleContext)
        {
            var sb = new StringBuilder();
            sb.Append("<Where><And>");

            if (parentId > 0)
            {
                sb.AppendFormat(EqualParentHeadingCamlQuery, parentId);
            }
            else
            {
                sb.Append(EmptyParentHeadingCamlQuery);
            }

            if (string.IsNullOrEmpty(visibleContext))
            {
                sb.Append(EmptyVisibleContextCamlQuery);
            }
            else
            {
                sb.AppendFormat(EqualVisibleContextCamlQuery, visibleContext);
            }

            sb.Append("</And></Where>");
            sb.Append(OrderByCamlQuery);

            var nodes = new SiteMapNodeCollection();

            var query = new SPQuery
                            {
                                Query = sb.ToString(),
                                QueryThrottleMode = SPQueryThrottleOption.Override
                            };

            var items = list.GetItems(query);

            if (items.Count == 0)
            {
                return nodes;
            }

            var webUrl = web.Url;

            foreach (SPListItem item in items)
            {
                var quickLaunchItem = new QuickLaunchItem(item);

                if (quickLaunchItem.VisibleForAdminOnly)
                {
                    if (!DoesUserHavePermissions(web))
                    {
                        continue;
                    }
                }

                if (quickLaunchItem.ListId != Guid.Empty)
                {
                    if (!DoesUserHavePermissions(web, quickLaunchItem.ListId, quickLaunchItem.PermissionLevels))
                    {
                        continue;
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(quickLaunchItem.PermissionLevels))
                    {
                        if (!DoesUserHavePermissions(web, quickLaunchItem.PermissionLevels))
                        {
                            continue;
                        }
                    }
                }

                string url;

                if (quickLaunchItem.SetVisibleContext)
                {
                    string location;

                    if (!string.IsNullOrEmpty(quickLaunchItem.Url))
                    {
                        location = quickLaunchItem.IsExternalUrl ? quickLaunchItem.Url : webUrl + quickLaunchItem.Url;
                    }
                    else
                    {
                        location = HttpContext.Current.Request.RawUrl;
                    }

                    location = SPEncode.UrlEncode(location);

                    url = string.Format("{0}/QuickLaunchContext.aspx?TargetVisibleContext={1}&ReturnUrl={2}", webUrl, SPEncode.UrlEncode(quickLaunchItem.TargetVisibleContext), location);
                }
                else
                {
                    url = quickLaunchItem.IsExternalUrl
                              ? quickLaunchItem.Url
                              : webUrl + quickLaunchItem.Url;    
                }

                var childNode = new SiteMapNode(this, item.ID.ToString(), url, quickLaunchItem.Title,
                                                quickLaunchItem.Description)
                                    {
                                        ChildNodes = GetChildNodes(item.ID, web, list, visibleContext)
                                    };
                childNode["DefaultCollapsed"] = quickLaunchItem.DefaultCollapsed ? "True" : "False";
                nodes.Add(childNode);
            }

            return nodes;
        }

        private bool DoesUserHavePermissions(SPWeb web, string permissionLevels)
        {
            if (permissions == null)
            {
                permissions = new Hashtable();
            }

            var levels = permissionLevels.Split(new[] {";"}, StringSplitOptions.RemoveEmptyEntries);

            foreach (var level in levels)
            {
                var key = string.Format("{0}_{1}", web.ID, level);
                if (permissions.Contains(key))
                {
                    var result = (bool) permissions[key];
                    if (result)
                    {
                        return true;
                    }
                    
                    continue;
                }

                try
                {
                    //var roleDefinition = web.RoleDefinitions[level];
                    //var flag = web.DoesUserHavePermissions(roleDefinition.BasePermissions);
                    
                    // Check base permission level name
                    var flag = SecurityHelper.DoesUserHavePermissionLevel(web, level);
                    
                    permissions[key] = flag;

                    if (flag)
                    {
                        return true;
                    }
                }
                catch
                {
                    permissions[key] = false;
                }
            }

            return false;
        }

        private bool DoesUserHavePermissions(SPWeb web)
        {
            if (permissions == null)
            {
                permissions = new Hashtable();
            }

            var key = web.ID.ToString();
            if (permissions.Contains(key))
            {
                return (bool)permissions[key];
            }

            try
            {
                var flag = web.DoesUserHavePermissions(SPBasePermissions.ManageWeb);
                permissions[key] = flag;
                return flag;
            }
            catch
            {
                permissions[key] = false;
                return false;
            }
        }

        private bool DoesUserHavePermissions(SPWeb web, Guid listId, string permissionLevels)
        {
            if (permissions == null)
            {
                permissions = new Hashtable();
            }

            SPList list;
            try
            {
                list = web.Lists[listId];
            }
            catch(ArgumentException)
            {
                return false;
            }

            if (string.IsNullOrEmpty(permissionLevels))
            {
                var key = list.ID.ToString();

                if (permissions.Contains(key))
                {
                    return (bool) permissions[key];
                }

                var flag = list.DoesUserHavePermissions(SPBasePermissions.ViewListItems);
                permissions[key] = flag;
                return flag;
            }

            var levels = permissionLevels.Split(new[] {";"}, StringSplitOptions.RemoveEmptyEntries);
            var flags = new List<bool>();

            foreach (var level in levels)
            {
                var key = string.Format("{0}_{1}", listId, level);

                if (permissions.Contains(key))
                {
                    flags.Add((bool)permissions[key]);
                }
                else
                {
                    try
                    {
                        // Check base permission
                        // var roleDefinition = web.RoleDefinitions[level];
                        //var flag = list.DoesUserHavePermissions(roleDefinition.BasePermissions);

                        // Check base permission level name
                        var flag = SecurityHelper.DoesUserHavePermissionLevel(list, level);

                        permissions[key] = flag;
                        flags.Add(flag);
                    }
                    catch
                    {
                        permissions[key] = false;
                    }
                }
            }

            return flags.Any(item => item);
        }
    }
}