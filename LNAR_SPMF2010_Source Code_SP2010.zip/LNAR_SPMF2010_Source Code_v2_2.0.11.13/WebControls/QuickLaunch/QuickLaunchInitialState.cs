﻿namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public enum QuickLaunchInitialState
    {
        Expanded = 1,
        Collapsed = 2
    }
}
