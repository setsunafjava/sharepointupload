﻿using System;
using System.ComponentModel;
using System.Text;
using System.Web.UI.WebControls;
using DeutscheBank.SharePoint.LNAR.Framework.Common;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class QuickLaunchDefaultDataSource : SiteMapDataSource
    {
        public override string SiteMapProvider
        {
            get { return "SPNavigationProvider"; }
            set { base.SiteMapProvider = value; }
        }

        public override bool ShowStartingNode
        {
            get { return false; }
            set { base.ShowStartingNode = value; }
        }

        public override string StartingNodeUrl
        {
            get { return "sid:1025"; }
            set { base.StartingNodeUrl = value; }
        }

        [DefaultValue(false)]
        public virtual bool EnableCollapsedExpanded
        {
            get
            {
                var obj = ViewState["EnableCollapsedExpanded"];
                if (obj != null)
                {
                    return (bool) obj;
                }
                return false;
            }
            set
            {
                if (value != EnableCollapsedExpanded)
                {
                    ViewState["EnableCollapsedExpanded"] = value;
                }
            }
        }

        [DefaultValue(false)]
        public virtual bool DefaultCollapsed
        {
            get
            {
                var obj = ViewState["DefaultCollapsed"];
                if (obj != null)
                {
                    return (bool)obj;
                }
                return false;
            }
            set
            {
                if (value != DefaultCollapsed)
                {
                    ViewState["DefaultCollapsed"] = value;
                }
            }
        }

        /// <summary>
        /// Multiple heading will expanded if DefaultCollapsed sets is True
        /// </summary>
        /// <remarks>Each heading separate by semicolon (;)</remarks>
        public virtual string ExpandedHeadings
        {
            get
            {
                var obj = ViewState["ExpandedHeadings"];
                if (obj != null)
                {
                    return (string)obj;
                }
                return string.Empty;
            }
            set
            {
                if (value != ExpandedHeadings)
                {
                    ViewState["ExpandedHeadings"] = value;
                }
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (EnableCollapsedExpanded)
            {
                if (!Page.ClientScript.IsClientScriptIncludeRegistered("Cookies.js"))
                {
                    Page.ClientScript.RegisterClientScriptInclude("Cookies.js", Page.ClientScript.GetWebResourceUrl(GetType(), FrameworkConstants.WebResources.Scripts.Cookies));
                }

                var scriptCollapsedExpansed = new StringBuilder();

                scriptCollapsedExpansed.Append("$(document).ready(function(){");
                
                scriptCollapsedExpansed.Append("$.each($(\"div[id*='QuickLaunchMenu'] > div.menu > ul.root > li > a\"), function(index, value){");
                scriptCollapsedExpansed.Append("var next = $(value).next();");
                scriptCollapsedExpansed.Append("if(next.length > 0){");

                scriptCollapsedExpansed.Append("$(value).click(function(){");
                scriptCollapsedExpansed.Append("var hash = $(this).text().hashCode();");
                scriptCollapsedExpansed.Append("var state = $.cookies.get('QuickLaunchHeadingState' + hash);");
                scriptCollapsedExpansed.Append("if(state == null || state == 'False'){$.cookies.set('QuickLaunchHeadingState' + hash, 'True');}else{$.cookies.set('QuickLaunchHeadingState' + hash, 'False');}");
                scriptCollapsedExpansed.Append("$(this).next().toggle('fast');");
                scriptCollapsedExpansed.Append("return false;});");

                // Restore collapsed/expanded mode
                scriptCollapsedExpansed.Append("var heading = $(this).text();");
                scriptCollapsedExpansed.Append("var hash = heading.hashCode();");
                scriptCollapsedExpansed.Append("var state = $.cookies.get('QuickLaunchHeadingState' + hash);");
                
                if (DefaultCollapsed)
                {
                    var expandedHeadings = ExpandedHeadings.Split(new [] {";"}, StringSplitOptions.RemoveEmptyEntries);
                    scriptCollapsedExpansed.Append("if(state == null){");
                    foreach (var expandedHeading in expandedHeadings)
                    {
                        scriptCollapsedExpansed.AppendFormat("if(heading == '{0}'){{state = 'False';}}", expandedHeading);
                    }
                    scriptCollapsedExpansed.Append("}");

                    scriptCollapsedExpansed.Append("if(state == null){state = 'True';}");
                }

                scriptCollapsedExpansed.Append("if(state == 'True'){$(value).next().hide();}");

                scriptCollapsedExpansed.Append("}");
                scriptCollapsedExpansed.Append("});");
                scriptCollapsedExpansed.Append("});");

                Page.ClientScript.RegisterStartupScript(GetType(), "Quick Launch Collapsed Expanded", scriptCollapsedExpansed.ToString(), true);

                // HashCode
                Page.ClientScript.RegisterStartupScript(GetType(), "getHashCode", "String.prototype.hashCode = function(){var hash = 0;if (this.length == 0) return hash; for (i = 0; i < this.length; i++) {char = this.charCodeAt(i);hash = 31*hash+char;hash = hash & hash;}return hash;};", true);
            }
        }
    }
}