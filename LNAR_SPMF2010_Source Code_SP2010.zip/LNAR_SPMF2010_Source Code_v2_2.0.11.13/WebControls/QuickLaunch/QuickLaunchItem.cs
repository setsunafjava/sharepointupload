﻿using System;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class QuickLaunchItem
    {
        public QuickLaunchItem(string title)
        {
            Title = title;
        }

        internal QuickLaunchItem(SPListItem item)
        {
            Id = item.ID;
            Title = item.Title;
            Description = item.GetItemValue<string>("Description");
            Url = item.GetItemValue<string>("Url");
            IsExternalUrl = item.GetItemValue<bool>("IsExternalUrl");
            ListId = new Guid(item.GetItemValue<string>("ListId"));
            ParentId = item.GetItemLookupIdValue("ParentId");
            Position = item.GetItemValue<int>("Position");
            VisibleForAdminOnly = item.GetItemValue<bool>("VisibleForAdminOnly");
            PermissionLevels = item.GetItemValue<string>("PermissionLevels");
            VisibleContext = item.GetItemValue<string>("VisibleContext");
            SetVisibleContext = item.GetItemValue<bool>("SetVisibleContext");
            TargetVisibleContext = item.GetItemValue<string>("TargetVisibleContext");
            DefaultCollapsed = item.GetItemValue<bool>("DefaultCollapsed");
        }

        public int Id { get; internal set; }

        public string Title { get; set; }

        public string Description { get; set; }

        public string Url { get; set; }

        public bool IsExternalUrl { get; set; }

        public int Position { get; set; }

        public int ParentId { get; internal set; }

        public Guid ListId { get; set; }

        public string VisibleContext { get; set; }

        public bool SetVisibleContext { get; set; }

        public string TargetVisibleContext { get; set; }

        public bool DefaultCollapsed { get; set; }

        /// <summary>
        ///   Multiple permission levels, separated by semicolon (;)
        /// </summary>
        public string PermissionLevels { get; set; }

        public bool VisibleForAdminOnly { get; set; }

        internal void Update(SPWeb web)
        {
            var list = web.Lists[FrameworkConstants.QuickLaunchListName];
            var item = list.GetItemById(Id);

            item["Title"] = Title;
            item["Url"] = Url;
            item["IsExternalUrl"] = IsExternalUrl;
            item["Position"] = Position;

            if (ParentId > 0)
            {
                item["ParentId"] = ParentId;
            }
            else
            {
                item["ParentId"] = null;
            }

            item.Update();
        }

        internal void Delete(SPWeb web)
        {
            var list = web.Lists[FrameworkConstants.QuickLaunchListName];
            var item = list.GetItemById(Id);
            item.Delete();
        }
    }
}