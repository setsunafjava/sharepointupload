﻿using System;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DeutscheBank.SharePoint.LNAR.Framework.Common;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class QuickLaunchDataSource : SiteMapDataSource
    {
        private SiteMapNodeCollection nodes;
        private SiteMapProvider provider;

        public override string SiteMapProvider
        {
            get
            {
                var str = ViewState["SiteMapProvider"] as string;
                return !string.IsNullOrEmpty(str) ? str : typeof (QuickLaunchProvider).AssemblyQualifiedName;
            }
            set
            {
                if (SiteMapProvider != value)
                {
                    provider = null;
                    ViewState["SiteMapProvider"] = value;
                }
            }
        }

        private void BuildProvider()
        {
            if (provider == null)
            {
                provider = (SiteMapProvider) Activator.CreateInstance(Type.GetType(SiteMapProvider));
                Provider = provider;
            }
        }

        protected override HierarchicalDataSourceView GetHierarchicalView(string viewPath)
        {
            if (nodes == null)
            {
                BuildProvider();

                // ReSharper disable AssignNullToNotNullAttribute
                nodes = provider.GetChildNodes(null);
                // ReSharper restore AssignNullToNotNullAttribute
            }
            return nodes != null ? nodes.GetHierarchicalDataSourceView() : null;
        }

        protected override void OnLoad(EventArgs e)
        {
            if (nodes == null)
            {
                BuildProvider();
                // ReSharper disable AssignNullToNotNullAttribute
                nodes = provider.GetChildNodes(null);
                // ReSharper restore AssignNullToNotNullAttribute
            }

            if (QuickLaunchManager.EnableCollapsedExpanded)
            {
                if (!Page.ClientScript.IsClientScriptIncludeRegistered("Cookies.js"))
                {
                    Page.ClientScript.RegisterClientScriptInclude("Cookies.js", Page.ClientScript.GetWebResourceUrl(GetType(), FrameworkConstants.WebResources.Scripts.Cookies));
                }

                var script = new StringBuilder();

                script.Append("$(document).ready(function(){");
                
                // Set default collapsed mode)
                foreach (var node in from SiteMapNode node in nodes
                                     let defaultCollapsed = node["DefaultCollapsed"]
                                     where defaultCollapsed == "True"
                                     select node)
                {
                    script.AppendFormat("var hash = '{0}'.hashCode();", node.Title);
                    script.Append("var state = $.cookies.get('QuickLaunchHeadingState' + hash);");
                    script.Append("if(state == null) {$.cookies.set('QuickLaunchHeadingState' + hash, 'True');}");
                }

                script.Append("});");

                Page.ClientScript.RegisterStartupScript(Page.GetType(),
                                                        "Default Collapsed mode for quick launch heading",
                                                        script.ToString(), true);

                var scriptCollapsedExpansed = new StringBuilder();

                scriptCollapsedExpansed.Append("$(document).ready(function(){");

                scriptCollapsedExpansed.Append("$.each($(\"div[id*='QuickLaunchMenu'] > div.menu > ul.root > li > a\"), function(index, value){");
                scriptCollapsedExpansed.Append("var next = $(value).next();");
                scriptCollapsedExpansed.Append("if(next.length > 0){");

                scriptCollapsedExpansed.Append("$(value).click(function(){");
                scriptCollapsedExpansed.Append("var hash = $(this).text().hashCode();");
                scriptCollapsedExpansed.Append("var state = $.cookies.get('QuickLaunchHeadingState' + hash);");
                scriptCollapsedExpansed.Append("if(state == null || state == 'False'){$.cookies.set('QuickLaunchHeadingState' + hash, 'True');}else{$.cookies.set('QuickLaunchHeadingState' + hash, 'False');}");
                scriptCollapsedExpansed.Append("$(this).next().toggle('fast');");
                scriptCollapsedExpansed.Append("return false;});");

                // Restore collapsed/expanded mode
                scriptCollapsedExpansed.Append("var heading = $(this).text();");
                scriptCollapsedExpansed.Append("var hash = heading.hashCode();");
                scriptCollapsedExpansed.Append("var state = $.cookies.get('QuickLaunchHeadingState' + hash);");

                scriptCollapsedExpansed.Append("if(state == 'True'){$(value).next().hide();}");

                scriptCollapsedExpansed.Append("}");
                scriptCollapsedExpansed.Append("});");
                scriptCollapsedExpansed.Append("});");

                Page.ClientScript.RegisterStartupScript(GetType(), "Quick Launch Collapsed Expanded", scriptCollapsedExpansed.ToString(), true);

                // HashCode
                Page.ClientScript.RegisterStartupScript(GetType(), "getHashCode", "String.prototype.hashCode = function(){var hash = 0;if (this.length == 0) return hash; for (i = 0; i < this.length; i++) {char = this.charCodeAt(i);hash = 31*hash+char;hash = hash & hash;}return hash;};", true);
            }

            // Selected item
            var rawUrl = Page.Request.Url.GetLeftPart(UriPartial.Path);

            var scriptSelected = new StringBuilder();
            scriptSelected.Append("$(document).ready(function(){");
            scriptSelected.AppendFormat(
                "var items = $(\"div[id*='QuickLaunchMenu'] > div.menu > ul.root > li > ul > li > a[href^='{0}']\");",
                rawUrl);
            scriptSelected.Append("if(items.length == 1){items.addClass('selected');}");
            scriptSelected.Append("else{");
            scriptSelected.AppendFormat(
                "$(\"div[id*='QuickLaunchMenu'] > div.menu > ul.root > li > a[href^='{0}']\").addClass('selected');",
                rawUrl);
            scriptSelected.Append("}");
            scriptSelected.Append("});");

            Page.ClientScript.RegisterStartupScript(Page.GetType(), "Quick Launch Selected Item",
                                                    scriptSelected.ToString(), true);

            base.OnLoad(e);
        }        
    }
}