﻿namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    /// <summary>
    ///   Renders a calculated field on a form page (not a list view page).
    /// </summary>
    public class CalculatedField : Microsoft.SharePoint.WebControls.CalculatedField
    {
    }
}