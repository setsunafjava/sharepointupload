﻿using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class RichTextField : Microsoft.SharePoint.WebControls.RichTextField
    {
        protected override void RenderFieldForDisplay(HtmlTextWriter writer)
        {
            if (SPContext.Current.FormContext.FormMode == SPControlMode.New)
            {
                writer.Write("&nbsp;");
            }
            else
            {
                base.RenderFieldForDisplay(writer);
            }
        }
    }
}