﻿using System.Data;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public interface IDataGridDataProvider
    {
        DataTable GetDataSource(DataGrid dataGrid);
    }
}