﻿using System;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class NumberField : Microsoft.SharePoint.WebControls.NumberField
    {
        /// <summary>
        ///   Gets or sets the custom number format when display.
        /// </summary>
        public string NumberFormat { get; set; }

        protected override void RenderFieldForDisplay(HtmlTextWriter writer)
        {
            if (SPContext.Current.FormContext.FormMode == SPControlMode.New)
            {
                writer.Write("&nbsp;");
            }
            else
            {
                if (string.IsNullOrEmpty(NumberFormat))
                {
                    base.RenderFieldForDisplay(writer);
                }
                else
                {
                    var value = ItemFieldValue;
                    writer.Write(value == null ? "&nbsp;" : Convert.ToDouble(value).ToString(NumberFormat));
                }
            }
        }
    }
}