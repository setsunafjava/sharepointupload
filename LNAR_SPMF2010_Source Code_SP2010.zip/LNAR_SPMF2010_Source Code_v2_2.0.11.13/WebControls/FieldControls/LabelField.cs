﻿using System.Web.UI;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class LabelField : FieldLabel
    {
        public string Text
        {
            get
            {
                var value = ViewState["Text"];
                if (value == null)
                {
                    return string.Empty;
                }
                return (string) value;
            }
            set { ViewState["Text"] = value; }
        }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-standardheader");
            writer.RenderBeginTag(HtmlTextWriterTag.H3);
            if (ControlMode == SPControlMode.Display)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Name, string.Format("SPBookmark_{0}", Field.InternalName));
                writer.RenderBeginTag(HtmlTextWriterTag.A);
                writer.RenderEndTag(); // a 
            }

            writer.RenderBeginTag(HtmlTextWriterTag.Nobr);

            writer.Write(!string.IsNullOrEmpty(Text) ? SPEncode.HtmlEncode(Text) : SPEncode.HtmlEncode(Field.Title));

            if (Field.Required && ControlMode != SPControlMode.Display)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Title, LocalizationHelper.GetString("wss", "requiredfld_tooltip"));
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-formvalidation");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write(" *");
                writer.RenderEndTag(); // span
            }

            writer.RenderEndTag(); // nobr   
            writer.RenderEndTag(); //h3
        }
    }
}