﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class MultipleAttachmentField : BaseFieldControl, IPostBackDataHandler
    {
        private List<string> attachmentFiles;
        
        #region IPostBackDataHandler Members

        public bool LoadPostData(string postDataKey, NameValueCollection postCollection)
        {
            var name = postDataKey + "$";
            var keys = Page.Request.Files.AllKeys.Where(k => k != null && k.StartsWith(name));
            var attachments = ItemContext.ListItem.Attachments;
            attachmentFiles = new List<string>();
            if (ItemFieldValue != null)
            {
                attachmentFiles.AddRange(ItemFieldValue.ToString().Split(new[] { ";#" }, StringSplitOptions.RemoveEmptyEntries));
            }

            // Deleted files
            var deletedFiles = postCollection[postDataKey + "$DeletedFiles"];
            if (!string.IsNullOrEmpty(deletedFiles))
            {
                var split = deletedFiles.Split(new [] {";#"}, StringSplitOptions.RemoveEmptyEntries);
                foreach (var str in split)
                {
                    attachmentFiles.Remove(str);
                    attachments.Delete(str);
                }
            }

            foreach (var key in keys)
            {
                var file = Page.Request.Files[key];
                var fileName = Path.GetFileName(file.FileName);
                if (file.ContentLength > 0 && !attachmentFiles.Any(f => f.Equals(fileName, StringComparison.InvariantCultureIgnoreCase)))
                {
                    if (!attachments.Cast<string>().Any(f => f.Equals(fileName, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        var ms = new MemoryStream();
                        var buffer = new byte[32768];
                        while (true)
                        {
                            var read = file.InputStream.Read(buffer, 0, buffer.Length);
                            if (read <= 0)
                                break;
                            ms.Write(buffer, 0, read);
                        }

                        attachments.Add(fileName, ms.ToArray());
                        ms.Close();
                    }
                    attachmentFiles.Add(fileName);
                }

                RemoveHttpFile(Page.Request.Files, key);
            }

            return false;
        }

        public void RaisePostDataChangedEvent()
        {
        }

        #endregion

        private static void RemoveHttpFile(HttpFileCollection files, string name)
        {
            var type = files.GetType();
            var method = type.GetMethod("BaseRemove", BindingFlags.Instance | BindingFlags.NonPublic);
            method.Invoke(files, new object[] {name});
        }

        protected override void OnPreRender(EventArgs e)
        {
            attachmentFiles = new List<string>();
            if (ItemFieldValue != null)
            {
                attachmentFiles.AddRange(ItemFieldValue.ToString().Split(new[] {";#"},
                                                                         StringSplitOptions.RemoveEmptyEntries));
            }

            if (ControlMode != SPControlMode.Display)
            {
                var pageType = Page.GetType();
                if (!Page.ClientScript.IsClientScriptIncludeRegistered(pageType, "MultipleAttachmentField.js"))
                {
                    Page.ClientScript.RegisterClientScriptInclude(pageType, "MultipleAttachmentField.js",
                                                                  Page.ClientScript.GetWebResourceUrl(GetType(), FrameworkConstants.WebResources.Scripts.MultipleAttachmentField));
                }
            }
        }

        protected override void RenderFieldForDisplay(HtmlTextWriter writer)
        {
            RenderAttachmentsTable(writer, false);
        }

        protected override void RenderFieldForInput(HtmlTextWriter writer)
        {
            RenderAttachmentsTable(writer, true);

            writer.AddAttribute(HtmlTextWriterAttribute.Alt, "Add new attachment");
            writer.AddAttribute(HtmlTextWriterAttribute.Src, "/_layouts/images/rect.gif");
            writer.RenderBeginTag(HtmlTextWriterTag.Img);
            writer.RenderEndTag(); // img

            writer.AddAttribute("onmouseover", string.Format("{0}_Object.onMouseOver(event)", ClientID));
            writer.AddAttribute(HtmlTextWriterAttribute.Href, "javascript:void(0)");
            writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingLeft, "2px");
            writer.RenderBeginTag(HtmlTextWriterTag.A);
            writer.Write("Add attachment");
            writer.RenderEndTag(); //a

            writer.AddStyleAttribute(HtmlTextWriterStyle.Position, "absolute");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Left, "-10000px");
            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID + "_HiddenContainer");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);

            writer.AddAttribute(HtmlTextWriterAttribute.Type, "file");
            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID + "_FileUpload");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "80px");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Position, "relative");
            writer.AddStyleAttribute(HtmlTextWriterStyle.ZIndex, "2");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Cursor, "pointer");
            writer.AddStyleAttribute("opacity", "0");
            writer.AddStyleAttribute("-moz-opacity", "0");
            writer.AddStyleAttribute("filter", "alpha(opacity: 0)");
            writer.RenderBeginTag(HtmlTextWriterTag.Input);
            writer.RenderEndTag(); // input

            writer.RenderEndTag(); // div

            writer.AddAttribute(HtmlTextWriterAttribute.Type, "hidden");
            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID + "_UniqueId");
            writer.AddAttribute(HtmlTextWriterAttribute.Value, UniqueID);
            writer.RenderBeginTag(HtmlTextWriterTag.Input);
            writer.RenderEndTag(); // input

            writer.AddAttribute(HtmlTextWriterAttribute.Type, "hidden");
            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID);
            writer.AddAttribute(HtmlTextWriterAttribute.Name, UniqueID);
            writer.RenderBeginTag(HtmlTextWriterTag.Input);
            writer.RenderEndTag(); // input

            writer.AddAttribute(HtmlTextWriterAttribute.Type, "hidden");
            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID + "_DeletedFiles");
            writer.AddAttribute(HtmlTextWriterAttribute.Name, UniqueID + "$DeletedFiles");
            writer.RenderBeginTag(HtmlTextWriterTag.Input);
            writer.RenderEndTag(); // input

            writer.AddAttribute(HtmlTextWriterAttribute.Type, "text/javascript");
            writer.RenderBeginTag(HtmlTextWriterTag.Script);

            writer.WriteLine(string.Format("var {0}_Object = null;", ClientID));
            writer.Write("$(document).ready(function(){");
            writer.Write(string.Format("{0}_Object = new DeutscheBank.SharePoint.LNAR.Framework.MultipleAttachments('{0}');", ClientID));
            writer.Write("});");

            writer.RenderEndTag(); // script
        }

        public override void UpdateFieldValueInItem()
        {
            ItemFieldValue = string.Join(";#", attachmentFiles.ToArray());
        }

        private void RenderAttachmentsTable(HtmlTextWriter writer, bool renderDeleteButtons)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "2");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.AddStyleAttribute(HtmlTextWriterStyle.MarginBottom, "5px");
            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID + "_Attachments");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            string urlPrefix;
            try
            {
                urlPrefix = ItemContext.ListItem.Attachments.UrlPrefix;
            }
            catch(ArgumentException)
            {
                urlPrefix = string.Empty;
            }

            foreach (var file in attachmentFiles)
            {
                var id = Guid.NewGuid().ToString("N");

                writer.AddAttribute(HtmlTextWriterAttribute.Id, id + "_Tr");
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-vb");
                writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingLeft, "0");
                writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingRight, "10px");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);

                writer.RenderBeginTag(HtmlTextWriterTag.Span);

                writer.AddAttribute(HtmlTextWriterAttribute.Href, urlPrefix + file);
                writer.RenderBeginTag(HtmlTextWriterTag.A);
                writer.Write(SPEncode.HtmlEncode(file));
                writer.RenderEndTag(); // a

                writer.RenderEndTag(); // span

                writer.RenderEndTag(); // td

                if (renderDeleteButtons)
                {
                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-propertysheet");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);

                    writer.AddAttribute(HtmlTextWriterAttribute.Alt, "Delete");
                    writer.AddAttribute(HtmlTextWriterAttribute.Src, "/_layouts/images/rect.gif");
                    writer.RenderBeginTag(HtmlTextWriterTag.Img);
                    writer.RenderEndTag(); // img

                    writer.AddAttribute(HtmlTextWriterAttribute.Onclick, string.Format("{0}_Object.deleteAttachment('{1}', '{2}');", ClientID, id, file));
                    writer.AddAttribute(HtmlTextWriterAttribute.Href, "javascript:void(0)");
                    writer.AddStyleAttribute(HtmlTextWriterStyle.MarginLeft, "2px");
                    writer.RenderBeginTag(HtmlTextWriterTag.A);
                    writer.Write("Delete");
                    writer.RenderEndTag(); // a

                    writer.RenderEndTag(); // td    
                }

                writer.RenderEndTag(); // tr
            }

            writer.RenderEndTag(); // table
        }
    }
}