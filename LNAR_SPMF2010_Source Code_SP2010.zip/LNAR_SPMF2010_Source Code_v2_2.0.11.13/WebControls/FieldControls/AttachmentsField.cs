﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class AttachmentsField : WebControl
    {
        public AttachmentsField() : base(HtmlTextWriterTag.Div)
        {
            
        }

        protected override void AddAttributesToRender(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Id, "divAttachments");
        }
    }
}