﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class LookupBoundField : BoundField
    {
        public override void RenderCell(HtmlTextWriter writer, DataRowView row)
        {
            var value = row[Name];
            if (value is DBNull)
            {
                writer.Write("&nbsp;");
                return;
            }

            string[] values;
            if (value is SPFieldLookupValueCollection)
            {
                values = ((SPFieldLookupValueCollection) value).Select(obj => obj.LookupValue).ToArray();
            }
            else
            {
                values =
                    value.ToString().Split(new[] {";#"}, StringSplitOptions.None).Where((item, i) => i%2 != 0).Select(
                        SPEncode.HtmlEncode).ToArray();
            }

            writer.Write(string.Join("; ", values));
        }

        public override string[] GetSelectedValues(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return new string[0];
            }

            var split = value.Split(new[] {";#"}, StringSplitOptions.None);
            if (split.Length%2 != 0)
            {
                throw new ArgumentOutOfRangeException("value", "The value not correct format.");
            }

            var values = new List<string>();
            for (var i = 0; i < split.Length; i++)
            {
                if (i%2 == 0)
                {
                    values.Add(split[i] + ";#" + split[i + 1]);
                }
            }
            return values.ToArray();
        }

        public override void SplitValues(DataTable dt, SPListItem item, string separateCharacter, ArrayList columns)
        {
            var obj = item[Name];
            if (obj == null)
            {
                var row = dt.NewRow();
                foreach (var column in columns.Cast<BoundField>())
                {
                    row[column.Name] = item[column.Name];
                }
                dt.Rows.Add(row);
            }
            else
            {
                if (obj is SPFieldUserValueCollection)
                {
                    var users = (SPFieldUserValueCollection) obj;
                    foreach (var user in users)
                    {
                        var row = dt.NewRow();
                        foreach (var column in columns.Cast<BoundField>())
                        {
                            row[column.Name] = item[column.Name];
                        }
                        row[Name] = user.LookupId + ";#" + user.LookupValue;
                        dt.Rows.Add(row);
                    }
                }
                else if (obj is SPFieldLookupValueCollection)
                {
                    var lookupValue = (SPFieldLookupValueCollection)obj;
                    foreach (var user in lookupValue)
                    {
                        var row = dt.NewRow();
                        foreach (var column in columns.Cast<BoundField>())
                        {
                            row[column.Name] = item[column.Name];
                        }
                        row[Name] = user.LookupId + ";#" + user.LookupValue;
                        dt.Rows.Add(row);
                    }
                }
                else
                {
                    var row = dt.NewRow();
                    foreach (var column in columns.Cast<BoundField>())
                    {
                        row[column.Name] = item[column.Name];
                    }
                }
            }
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendFormat("<fw:LookupBoundField Name=\"{0}\" Header=\"{1}\" />", Name, Header);
            return sb.ToString();
        }
    }
}