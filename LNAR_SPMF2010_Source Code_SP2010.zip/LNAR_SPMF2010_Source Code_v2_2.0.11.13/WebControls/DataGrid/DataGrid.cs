﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Drawing.Design;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    /// <summary>
    ///   A data bound list control that displays the items from data source in a table. The DataGrid control allows you to select these items.
    /// </summary>
    public class DataGrid : WebControl, IPostBackDataHandler
    {
        private ArrayList columns;
        private string dataValueField;
        private IList<string> selectedValues;

        public string DataProvider { get; set; }
        
        public string DataTextField { get; set; }

        public string DataValueField
        {
            get { return string.IsNullOrEmpty(dataValueField) ? DataTextField : dataValueField; }
            set { dataValueField = value; }
        }

        public bool ShowHeader { get; set; }

        public IList<string> SelectedValues
        {
            get { return selectedValues ?? (selectedValues = new List<string>()); }
        }

        public string LookupList { get; set; }

        /// <summary>
        ///   The CAML
        /// </summary>
        public string WhereCondition { get; set; }

        /// <summary>
        ///   Gets or sets a value indicating whether value separate character.
        /// </summary>
        public string SeparateCharacter { get; set; }

        /// <summary>
        ///   Gets or sets a value indicating whether the control can selectable.
        /// </summary>
        public bool Selectable { get; set; }

        /// <summary>
        ///   Gets or sets a value indicating whether the control can select multi values.
        /// </summary>
        public bool AllowMultipleValues { get; set; }
        
        /// <summary>
        /// Gets or sets a value indicating whether the data grid will remove duplicate rows by DataValueField property.
        /// </summary>
        public bool RemoveDuplicateRows { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the data grid will lookup values with high permission.
        /// </summary>
        public bool LookupWithHighPermission { get; set; }

        /// <summary>
        ///   Collection of choices, separated by ;#
        /// </summary>
        public string Choices { get; set; }

        public string DataProviderParameters { get; set; }

        [Browsable(true)]
        [DisplayName("Columns")]
        [PersistenceMode(PersistenceMode.InnerDefaultProperty)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Editor(typeof (BoundFieldCollectionEditor), typeof (UITypeEditor))]
        [MergableProperty(false)]
        public ArrayList Columns
        {
            get { return columns ?? (columns = new ArrayList()); }
        }

        public DataTable DataSource { get; set; }

        public bool ValueSelected { get; private set; }

        #region IPostBackDataHandler Members

        public bool LoadPostData(string postDataKey, NameValueCollection postCollection)
        {
            selectedValues = new List<string>();

            var keyPrefix = postDataKey + "$Choice";
            var keys = postCollection.AllKeys.Where(key => key != null && key.StartsWith(keyPrefix));
            foreach (var key in keys)
            {
                selectedValues.Add(postCollection[key]);
            }
            return false;
        }

        public void RaisePostDataChangedEvent()
        {
        }

        #endregion

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            Page.RegisterRequiresPostBack(this);
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            DataBind();

            CssRegistration.RegisterCore();

            if (!Page.ClientScript.IsClientScriptIncludeRegistered("DataGrid.js"))
            {
                var url = Page.ClientScript.GetWebResourceUrl(GetType(), FrameworkConstants.WebResources.Scripts.DataGrid);
                Page.ClientScript.RegisterClientScriptInclude("DataGrid.js", url);
            }
        }

        public override void DataBind()
        {
            if (string.IsNullOrEmpty(DataProvider))
            {
                DataSource = new DefaultDataGridDataProvider().GetDataSource(this);
            }
            else
            {
                var instance = (IDataGridDataProvider)Activator.CreateInstance(Type.GetType(DataProvider));
                DataSource = instance.GetDataSource(this);
            }
        }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID);
            writer.AddStyleAttribute(HtmlTextWriterStyle.BorderCollapse, "collapse");

            if (!Width.IsEmpty)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Width, Width.ToString());
            }

            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            if (ShowHeader)
            {
                RenderHeader(writer);
            }

            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);

            var rowIndex = 0;
            foreach (DataRowView row in DataSource.DefaultView)
            {
                var value = Convert.ToString(row[DataValueField]);
                var selected = SelectedValues.Contains(value);
                if (selected)
                {
                    ValueSelected = true;
                }

                if (Selectable)
                {
                    writer.AddAttribute("onmouseover", "$(this).addClass('ms-itmhover');");
                    writer.AddAttribute("onmouseout", "$(this).removeClass('ms-itmhover');");

                    writer.AddAttribute("onclick", AllowMultipleValues
                                                       ? "$(this).toggleClass('s4-itm-selected');if($(this).hasClass('s4-itm-selected')){$('input', this).attr('checked', 'checked');}else{$('input', this).removeAttr('checked');}"
                                                       : "$('tr.row', $(this).parent()).removeClass('s4-itm-selected');$(this).addClass('s4-itm-selected');if($(this).hasClass('s4-itm-selected')){$('input', this).attr('checked', 'checked');}");
                }

                writer.AddAttribute(HtmlTextWriterAttribute.Class, selected ? "row s4-itm-selected" : "row");

                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                if (Selectable)
                {
                    if (AllowMultipleValues)
                    {
                        writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "20px");
                        writer.RenderBeginTag(HtmlTextWriterTag.Td);

                        writer.AddAttribute(HtmlTextWriterAttribute.Value, value);
                        writer.AddAttribute(HtmlTextWriterAttribute.Type, "checkbox");
                        writer.AddAttribute(HtmlTextWriterAttribute.Name, UniqueID + "$Choice$" + rowIndex);

                        if (selected)
                        {
                            writer.AddAttribute(HtmlTextWriterAttribute.Checked, "checked");
                        }

                        writer.RenderBeginTag(HtmlTextWriterTag.Input);
                        writer.RenderEndTag(); // input    

                        writer.RenderEndTag(); // td
                    }
                    else
                    {
                        writer.AddStyleAttribute(HtmlTextWriterStyle.Display, "none");
                        writer.RenderBeginTag(HtmlTextWriterTag.Td);

                        writer.AddAttribute(HtmlTextWriterAttribute.Value, value);
                        writer.AddAttribute(HtmlTextWriterAttribute.Type, "radio");
                        writer.AddAttribute(HtmlTextWriterAttribute.Name, UniqueID + "$Choice");

                        if (selected)
                        {
                            writer.AddAttribute(HtmlTextWriterAttribute.Checked, "checked");
                        }

                        writer.RenderBeginTag(HtmlTextWriterTag.Input);
                        writer.RenderEndTag(); // input

                        writer.RenderEndTag(); // td
                    }
                }

                foreach (var column in Columns.Cast<BoundField>())
                {
                    writer.AddStyleAttribute(HtmlTextWriterStyle.Padding, "5px");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    column.RenderCell(writer, row);
                    writer.RenderEndTag();
                }

                writer.RenderEndTag(); // tr

                rowIndex++;
            }

            writer.RenderEndTag(); // tbody

            writer.RenderEndTag(); // table
        }

        private void RenderHeader(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Thead);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            if (Selectable && AllowMultipleValues)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.Write("&nbsp;");
                writer.RenderEndTag(); // td
            }

            foreach (var column in Columns.Cast<BoundField>())
            {
                writer.AddStyleAttribute(HtmlTextWriterStyle.TextAlign, "left");
                writer.RenderBeginTag(HtmlTextWriterTag.Th);
                writer.Write(column.Header);
                writer.RenderEndTag(); // th
            }

            writer.RenderEndTag(); // tr
            writer.RenderEndTag(); // thead
        }

        public void SetSelectedValues(string value)
        {
            var column = Columns.Cast<BoundField>().First(item => item.Name == DataValueField);
            var values = column.GetSelectedValues(value);
            foreach (var val in values)
            {
                SelectedValues.Add(val);
            }    
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendFormat("<fw:DataGrid runat=\"server\" DataTextField=\"{0}\" DataValueField=\"{1}\" ShowHeader=\"{2}\" LookupList=\"{3}\" WhereCondition=\"{4}\" SeparateCharacter=\"{5}\" Selectable=\"{6}\" AllowMultipleValues=\"{7}\" RemoveDuplicateRows=\"{8}\" LookupWithHighPermission=\"{9}\" Choices=\"{10}\" DataProvider=\"{11}\" DataProviderParameters=\"{12}\">",
                DataTextField, DataValueField, ShowHeader, LookupList, WhereCondition, SeparateCharacter, Selectable, AllowMultipleValues, RemoveDuplicateRows, LookupWithHighPermission, Choices, DataProvider, DataProviderParameters);
            sb.Append("<Columns>");
            foreach (var column in Columns)
            {
                sb.Append(column.ToString());
            }
            sb.Append("</Columns>");
            sb.Append("</fw:DataGrid>");
            return sb.ToString();
        }

        #region Nested type: BoundFieldCollectionEditor

        public class BoundFieldCollectionEditor : CollectionEditor
        {
            public BoundFieldCollectionEditor(Type type)
                : base(type)
            {
            }

            protected override bool CanSelectMultipleInstances()
            {
                return false;
            }

            protected override Type CreateCollectionItemType()
            {
                return typeof (BoundField);
            }
        }

        #endregion

        private class DataColumnComparer : IEqualityComparer<DataRow>
        {
            private readonly string columnName;

            public DataColumnComparer(string columnName)
            {
                this.columnName = columnName;
            }

            public bool Equals(DataRow x, DataRow y)
            {
                var value1 = x[columnName];
                var value2 = y[columnName];
                return value1.Equals(value2);
            }

            public int GetHashCode(DataRow obj)
            {
                var value = obj[columnName];
                if (value is DBNull)
                {
                    return -1;
                }

                return value.GetHashCode();
            }
        }

        private class DefaultDataGridDataProvider : IDataGridDataProvider
        {
            public DataTable GetDataSource(DataGrid dataGrid)
            {
                // Verify correct settings)))
                if (!string.IsNullOrEmpty(dataGrid.LookupList))
                {
                    if (!dataGrid.Columns.Cast<BoundField>().Any(item => item.Name == dataGrid.DataTextField))
                    {
                        throw new ArgumentException("The DataTextField must be inside Columns.");
                    }
                }
                else
                {
                    dataGrid.DataTextField = "Title";
                    dataGrid.Columns.Clear();
                    dataGrid.Columns.Add(new BoundField { Name = "Title", });
                }

                var dataSource = new DataTable();
                foreach (var column in dataGrid.Columns.Cast<BoundField>())
                {
                    dataSource.Columns.Add(column.Name, typeof(object));
                }

                if (!string.IsNullOrEmpty(dataGrid.LookupList))
                {
                    dataSource.DefaultView.Sort = string.Format("[{0}] ASC", dataGrid.DataTextField);
                }

                // Bind choices
                if (!string.IsNullOrEmpty(dataGrid.Choices))
                {
                    var values = dataGrid.Choices.Split(new[] { ";#" }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var value in values)
                    {
                        var row = dataSource.NewRow();
                        row[dataGrid.DataTextField] = value;
                        dataSource.Rows.Add(row);
                    }
                }

                if (!string.IsNullOrEmpty(dataGrid.LookupList))
                {
                    var items = SelectItems(dataGrid);
                    foreach (SPListItem item in items)
                    {
                        if (string.IsNullOrEmpty(dataGrid.SeparateCharacter))
                        {
                            var row = dataSource.NewRow();
                            foreach (var column in dataGrid.Columns.Cast<BoundField>())
                            {
                                row[column.Name] = item[column.Name];
                            }
                            dataSource.Rows.Add(row);
                        }
                        else
                        {
                            var column = dataGrid.Columns.Cast<BoundField>().First(c => c.Name == dataGrid.DataValueField);
                            column.SplitValues(dataSource, item, dataGrid.SeparateCharacter, dataGrid.Columns);
                        }
                    }
                }

                if (dataGrid.Columns.Count == 1)
                {
                    dataGrid.ShowHeader = false;
                }

                if (dataGrid.RemoveDuplicateRows)
                {
                    var rows = dataSource.AsEnumerable().Distinct(new DataColumnComparer(dataGrid.DataValueField)).ToList();
                    var dt = dataSource.Clone();
                    dt.DefaultView.Sort = dataSource.DefaultView.Sort;

                    foreach (var dataRow in rows)
                    {
                        dt.ImportRow(dataRow);
                    }

                    dataSource = dt;
                }

                return dataSource;
            }

            private static SPListItemCollection SelectItems(DataGrid dataGrid)
            {
                if (dataGrid.LookupWithHighPermission)
                {
                    var siteId = SPContext.Current.Site.ID;
                    var webId = SPContext.Current.Web.ID;
                    SPListItemCollection items = null;
                    SPSecurity.RunWithElevatedPrivileges(() =>
                    {
                        using (var site = new SPSite(siteId))
                        {
                            using (var web = site.OpenWeb(webId))
                            {
                                items = SelectItems(web, dataGrid);
                            }
                        }
                    });
                    return items;
                }

                return SelectItems(SPContext.Current.Web, dataGrid);
            }

            private static SPListItemCollection SelectItems(SPWeb web, DataGrid dataGrid)
            {
                var list = web.Lists[dataGrid.LookupList];
                var query = new SPQuery { ViewFields = BuildViewFields(list, dataGrid), Query = BuildQuery(list, dataGrid), QueryThrottleMode = SPQueryThrottleOption.Override };
                return list.GetItems(query);
            }

            private static string BuildQuery(SPList list, DataGrid dataGrid)
            {
                var sb = new StringBuilder();
                sb.Append(dataGrid.WhereCondition);

                if (string.IsNullOrEmpty(dataGrid.WhereCondition) || !dataGrid.WhereCondition.Contains("<OrderBy>"))
                {
                    var field = list.Fields[dataGrid.DataTextField];
                    sb.AppendFormat("<OrderBy><FieldRef Name='{0}' /></OrderBy>", field.InternalName);
                }

                return sb.ToString();
            }

            private static string BuildViewFields(SPList list, DataGrid dataGrid)
            {
                var sb = new StringBuilder();
                foreach (var field in dataGrid.Columns.Cast<BoundField>().Select(column => list.Fields[column.Name]))
                {
                    sb.AppendFormat("<FieldRef Name='{0}' />", field.InternalName);
                }
                return sb.ToString();
            }
        }
    }
}