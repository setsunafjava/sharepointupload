﻿using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Text;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class BoundField
    {
        private string header;

        /// <summary>
        ///   Column bound name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        ///   Column header
        /// </summary>
        public string Header
        {
            get { return header ?? Name; }
            set { header = value; }
        }

        public virtual void RenderCell(HtmlTextWriter writer, DataRowView row)
        {
            var value = row[Name];
            if (value is DBNull)
            {
                writer.Write("&nbsp;");
                return;
            }
            
            writer.Write(SPEncode.HtmlEncode(Convert.ToString(value)));
        }

        public virtual string[] GetSelectedValues(string value)
        {
            return value.Split(new[] { "; ", ";#" }, StringSplitOptions.RemoveEmptyEntries);
        }

        public virtual void SplitValues(DataTable dt, SPListItem item, string separateCharacter, ArrayList columns)
        {
            var value = Convert.ToString(item[Name]);
            if (string.IsNullOrEmpty(value))
            {
                var row = dt.NewRow();
                foreach (var column in columns.Cast<BoundField>())
                {
                    row[column.Name] = item[column.Name];
                }
                dt.Rows.Add(row);
            }
            else
            {
                var values = separateCharacter == "\\r\\n" ? value.Split(new [] {'\n', '\r'}, StringSplitOptions.RemoveEmptyEntries) : value.Split(new [] { separateCharacter }, StringSplitOptions.RemoveEmptyEntries);

                foreach (var str in values)
                {
                    if (string.IsNullOrEmpty(str.Trim()))
                    {
                        continue;
                    }

                    var row = dt.NewRow();
                    foreach (var column in columns.Cast<BoundField>())
                    {
                        row[column.Name] = item[column.Name];
                    }
                    row[Name] = str.Trim();
                    dt.Rows.Add(row);
                }
            }
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendFormat("<fw:BoundField Name=\"{0}\" Header=\"{1}\" />", Name, Header);
            return sb.ToString();
        }
    }
}