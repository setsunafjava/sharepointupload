﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Web.UI;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebControls
{
    public class MultiValueBoundField : BoundField
    {
        public override void RenderCell(HtmlTextWriter writer, DataRowView row)
        {
            var value = row[Name];
            if (value is DBNull)
            {
                writer.Write("&nbsp;");
                return;
            }

            var values = value.ToString().Split(new[] {";#"}, StringSplitOptions.RemoveEmptyEntries);
            writer.Write(string.Join("; ", values.Select(SPEncode.HtmlEncode).ToArray()));
        }

        public override string[] GetSelectedValues(string value)
        {
            return value.Split(Environment.NewLine.ToCharArray(), StringSplitOptions.RemoveEmptyEntries)
                .SelectMany(v => v.Split(new [] {";#"}, StringSplitOptions.RemoveEmptyEntries)).ToArray();
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendFormat("<fw:MultiValueBoundField Name=\"{0}\" Header=\"{1}\" />", Name, Header);
            return sb.ToString();
        }
    }
}