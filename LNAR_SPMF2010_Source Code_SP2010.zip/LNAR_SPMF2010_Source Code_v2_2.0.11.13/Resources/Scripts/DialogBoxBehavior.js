﻿DialogBox = function (id) {
    this.initialize(id);
};

DialogBox.prototype = {
    initialize: function (id) {
        this.id = id;
    },
    setValue: function (value) {
        document.getElementById(this.id).value = value;
        document.getElementById(this.id + '_Input').value = value;
    }
};