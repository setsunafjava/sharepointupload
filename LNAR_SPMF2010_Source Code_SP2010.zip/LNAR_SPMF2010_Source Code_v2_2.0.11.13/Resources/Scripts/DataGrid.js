﻿DataGrid = function (id) {
    this.initialize(id);
};

DataGrid.prototype = {
    initialize: function (id) {
        this.id = id;
    },
    getSelectedValues: function () {
        var selected = [];
        var items = $("input:checked", $("#" + this.id)).each(function (i, item) {
            var value = $(this).val();
            if (value != "") {
                selected.push($(this).val());
            }
        });
        return selected;
    },
    clearSelectedValues: function () {
        $("input", $("#" + this.id)).removeAttr('checked');
        $("tr.row", $("#" + this.id)).removeClass('s4-itm-selected');
    }
};