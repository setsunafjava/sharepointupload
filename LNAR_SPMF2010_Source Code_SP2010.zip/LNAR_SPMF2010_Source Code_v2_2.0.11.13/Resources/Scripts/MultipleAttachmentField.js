﻿Type.registerNamespace("DeutscheBank.SharePoint.LNAR.Framework");

DeutscheBank.SharePoint.LNAR.Framework.MultipleAttachments = function (id) {
    this.initialize(id);
};

DeutscheBank.SharePoint.LNAR.Framework.MultipleAttachments.prototype = {
    initialize: function (id) {
        this.id = id;
        this.counter = 1;
        this.uniqueId = $("#" + id + "_UniqueId").val();
        this.createCurrentFileUpload();
    },
    createCurrentFileUpload: function () {
        var input = $("#" + this.id + "_FileUpload").clone();
        var id = this.id + "_" + this.counter;
        input.attr("id", id);
        input.attr("name", this.uniqueId + "$" + this.counter);
        var self = this;
        input.change(function () {
            self.addAttachment(id, input.val());
            self.createCurrentFileUpload();
        });
        $("#" + this.id + "_HiddenContainer").append(input);
        this.currentFileUpload = input;
        this.counter = this.counter + 1;
    },
    onMouseOver: function (e) {
        if (!e) e = window.event;
        this.currentFileUpload.offset({ top: e.clientY - 10, left: e.clientX - 30 });
    },
    fireEvent: function (element, event) {
        if (document.createEvent) {
            // dispatch for firefox + others
            var evt = document.createEvent("HTMLEvents");
            evt.initEvent(event, true, true); // event type,bubbling,cancelable
            return !element.dispatchEvent(evt);
        } else {
            // dispatch for IE
            var evt = document.createEventObject();
            return element.fireEvent('on' + event, evt)
        }
    },
    addAttachment: function (id, fileName) {
        var table = $("#" + this.id + "_Attachments");
        table.show();

        var row = $("<tr></tr>").attr("id", id + "_Tr");
        var td1 = $("<td></td>").html(fileName).addClass("ms-vb").css({ "padding-left": "0", "padding-right": "10px" });

        var lnkDelete = $("<a></a>").html("Delete").attr("href", "javascript:void(0)").click(function () {
            $("#" + id).remove();
            $("#" + id + "_Tr").remove();
        }).css("margin-left", "2px");

        var td2 = $("<td></td>").addClass("ms-propertysheet");
        td2.append("<img alt='Delete' src='/_layouts/images/rect.gif' />");
        td2.append(lnkDelete);

        row.append(td1);
        row.append(td2);

        table.append(row);

        $("form").attr("enctype", "multipart/form-data").attr("encoding", "multipart/form-data");
    },
    deleteAttachment: function (id, fileName) {
        $("#" + id).remove();
        $("#" + id + "_Tr").remove();
        var hiddenField = $("#" + this.id + "_DeletedFiles");
        var oldValue = hiddenField.val();
        hiddenField.val(oldValue + ";#" + fileName);
    }
};