namespace DeutscheBank.SharePoint.LNAR.Framework.Common
{
    /// <summary>
    ///   Class that holds the constants for the SharePoint.Common project.
    /// </summary>
    public static class FrameworkConstants
    {
        /// <summary>
        ///   Constant that specifies the default category name.
        /// </summary>
        public const string DefaultCategoryName = "DeutscheBank.SharePoint.LNAR.Framework";

        /// <summary>
        ///   Constant that defines the default area name.
        /// </summary>
        public const string DefaultAreaName = "DeutscheBank.SharePoint.LNAR.Framework";

        /// <summary>
        ///   Constant that specifies the name of the configuration key for searching the areas and categories section.
        /// </summary>
        public const string AreasConfigKey = "DeutscheBank.SharePoint.LNAR.Framework.Diagnostics";

        public const int DefaultEventId = 2900;

        /// <summary>
        ///   Constant that specifies the name of the event log in which the event sources will be created for logging.
        /// </summary>
        public const string EventLogName = "SharePoint Event Log";

        /// <summary>
        ///   Constant that defines the path separator for categories (Area/Category).
        /// </summary>
        public const char CategoryPathSeparator = '/';

        #region Quick Launch

        public const string EnableCollapsedExpanded = "DeutscheBank.SharePoint.LNAR.Framework.QuickLaunch.EnableCollapsedExpanded";

        public const string QuickLaunchInitialState = "DeutscheBank.SharePoint.LNAR.Framework.QuickLaunch.QuickLaunchInitialState";

        public const string QuickLaunchListName = "DeutscheBank.SharePoint.LNAR.Framework.QuickLaunch";

        #endregion

        #region Archive

        public const string ArchiveRoleDefinition = "Archive";

        #endregion

        #region Audit

        public const string AuditRoleDefinition = "Audit";
        public const string AuditList = "Audit Export Files";

        #endregion

        public const uint FrameworkTraceId = 2357;

        #region Web Resources

        public static class WebResources
        {
            public static class Images
            {
                public const string Print = "DeutscheBank.SharePoint.LNAR.Framework.Resources.Images.Print.png";
                public const string Send = "DeutscheBank.SharePoint.LNAR.Framework.Resources.Images.Send.png";    
            }

            public static class Scripts
            {
                public const string DataViewBehavior = "DeutscheBank.SharePoint.LNAR.Framework.Resources.Scripts.DataViewBehavior.js";
                public const string MultipleAttachmentField = "DeutscheBank.SharePoint.LNAR.Framework.Resources.Scripts.MultipleAttachmentField.js";
                public const string DataGrid = "DeutscheBank.SharePoint.LNAR.Framework.Resources.Scripts.DataGrid.js";
                public const string DialogQuickSearch = "DeutscheBank.SharePoint.LNAR.Framework.Resources.Scripts.DialogQuickSearch.js";
                public const string Cookies = "DeutscheBank.SharePoint.LNAR.Framework.Resources.Scripts.Cookies.js";
                public const string DialogBoxBehavior = "DeutscheBank.SharePoint.LNAR.Framework.Resources.Scripts.DialogBoxBehavior.js";
            }
        }

        #endregion
    }
}