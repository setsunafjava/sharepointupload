﻿using System.Text;

namespace DeutscheBank.SharePoint.LNAR.Framework.Common
{
    public static class JavaScriptBuilderExtension
    {
        public static void BeginFunction(this StringBuilder builder)
        {
            builder.Append("{");
        }

        public static void BeginFunction(this StringBuilder builder, string function)
        {
            builder.Append(function).Append("{");
        }

        public static void EndFunction(this StringBuilder builder)
        {
            builder.Append("}");
        }
    }
}