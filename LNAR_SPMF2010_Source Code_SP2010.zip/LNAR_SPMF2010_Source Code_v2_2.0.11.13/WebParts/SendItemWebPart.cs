﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebParts
{
    public class SendItemWebPart : WebPart, IValidator
    {
        private Button btnSend;
        private RequiredFieldValidator rfvSubject;
        private RequiredFieldValidator rfvTo;
        private InputFormTextBox txtBody;
        private TextBox txtSubject;
        private TextBox txtTo;

        private IList<string> emailAddress;

        public override PartChromeType ChromeType
        {
            get { return PartChromeType.None; }
            set { base.ChromeType = value; }
        }

        #region IValidator Members

        public string ErrorMessage { get; set; }

        public bool IsValid { get; set; }

        public void Validate()
        {
            IsValid = true;

            if (string.IsNullOrEmpty(txtTo.Text.Trim()))
            {
                IsValid = false;
                rfvTo.IsValid = false;
                rfvTo.ErrorMessage = LocalizationHelper.GetString("SendItemWebPart_MS001");
                return;
            }

            if (string.IsNullOrEmpty(txtSubject.Text.Trim()))
            {
                IsValid = false;
                rfvSubject.IsValid = false;
                rfvSubject.ErrorMessage = LocalizationHelper.GetString("SendItemWebPart_MS002");
                return;
            }

            // Validate email format
            emailAddress = new List<string>();
            var inValidEmails = new List<string>();

            var emailregex = new Regex("(?<user>[^@]+)@(?<host>.+)");
            var split = txtTo.Text.Trim().Split(new [] {";"}, StringSplitOptions.RemoveEmptyEntries);
            foreach (var input in split.Select(str => str.Trim()).Where(input => !string.IsNullOrEmpty(input)))
            {
                if (emailregex.IsMatch(input))
                {
                    emailAddress.Add(input);
                }
                else
                {
                    inValidEmails.Add(input);
                }
            }

            if (inValidEmails.Count > 0)
            {
                IsValid = false;
                rfvTo.IsValid = false;
                rfvTo.ErrorMessage = LocalizationHelper.GetString("SendItemWebPart_MS003");

                txtTo.Text = string.Join("; ", emailAddress.Union(inValidEmails).ToArray());
                return;
            }

            if (emailAddress.Count == 0)
            {
                IsValid = false;
                rfvTo.IsValid = false;
                rfvTo.ErrorMessage = LocalizationHelper.GetString("SendItemWebPart_MS004");
            }
        }

        #endregion

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            var ribbon = SPRibbon.GetCurrent(Page);
            if (ribbon != null)
            {
                ribbon.CommandUIVisible = false;
            }

            // Fix width for rich text control
            var pageHead = Page.Master.FindControl("PlaceHolderAdditionalPageHead");
            if (pageHead != null)
            {
                var control = new HtmlGenericControl("style");
                control.Attributes.Add("type", "text/css");
                control.InnerHtml = "table.ms-rtetoolbarmenu{width:100%;} iframe.ms-rtelong{width:100%;}";
                pageHead.Controls.Add(control);
            }
        }

        protected override void CreateChildControls()
        {
            txtTo = new TextBox {ID = "txtTo", CssClass = "ms-long"};
            txtTo.Style.Add(HtmlTextWriterStyle.Display, "block");
            Controls.Add(txtTo);

            rfvTo = new RequiredFieldValidator
                        {
                            ControlToValidate = "txtTo",
                            ErrorMessage = LocalizationHelper.GetString("SendItemWebPart_MS005"),
                            Display = ValidatorDisplay.Dynamic
                        };
            Controls.Add(rfvTo);

            txtSubject = new TextBox {ID = "txtSubject", CssClass = "ms-long"};
            txtSubject.Style.Add(HtmlTextWriterStyle.Display, "block");
            Controls.Add(txtSubject);

            rfvSubject = new RequiredFieldValidator
                             {
                                 ControlToValidate = "txtSubject",
                                 ErrorMessage = LocalizationHelper.GetString("SendItemWebPart_MS005"),
                                 Display = ValidatorDisplay.Dynamic
                             };
            Controls.Add(rfvSubject);

            txtBody = new InputFormTextBox
                          {
                              ID = "txtBody",
                              TextMode = TextBoxMode.MultiLine,
                              RichText = true,
                              RichTextMode = SPRichTextMode.Compatible,
                              Rows = 15
                          };
            Controls.Add(txtBody);

            btnSend = new Button { ID = "btnSend", Text = LocalizationHelper.GetString("SendItemWebPart_MS006") };
            btnSend.Click += SendMail;
            Controls.Add(btnSend);
        }

        private void SendMail(object sender, EventArgs e)
        {
            Validate();

            if (!IsValid)
            {
                return;
            }

            var web = SPContext.Current.Web;
            var split = Page.Request.QueryString["Items"].Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries);
            var items = (from item in split
                         select item.Split(new[] {":"}, StringSplitOptions.None)
                         into subSplit
                         let list = web.Lists[new Guid(subSplit[0].TrimStart('['))]
                         select list.GetItemById(Convert.ToInt32(subSplit[1].TrimEnd(']')))).ToList();
            
            var from = web.CurrentUser.Email;
            var to = string.Join("; ", emailAddress.ToArray());
            var subject = txtSubject.Text.Trim();
            var body = txtBody.Text;

            bool result;

            var templatePath = Page.Request.QueryString["TemplatePath"];
            if (!string.IsNullOrEmpty(templatePath))
            {
                result = SendItemHelper.SendItemWithTemplatePath(web, items, templatePath, from, to, subject, body);    
                goto Close;
            }

            var templateList = Page.Request.QueryString["TemplateList"];
            if (!string.IsNullOrEmpty(templateList))
            {
                var templateName = Page.Request.QueryString["TemplateName"];
                if (string.IsNullOrEmpty(templateName))
                {
                    throw new ArgumentException();
                }

                var templateContentFieldName = Page.Request.QueryString["TemplateContentFieldName"];
                if (string.IsNullOrEmpty(templateContentFieldName))
                {
                    throw new ArgumentException();
                }

                var list = web.Lists[templateList];
                var query = new SPQuery
                {
                    Query = string.Format("<Where><Eq><FieldRef Name='Title'/><Value Type='Text'>{0}</Value></Eq></Where>", templateName),
                    QueryThrottleMode = SPQueryThrottleOption.Override
                };
                
                var listItems = list.GetItems(query);
                if (listItems.Count == 0)
                {
                    throw new ArgumentException(string.Format(LocalizationHelper.GetString("SendItemWebPart_MS007"), templateName));
                }
                
                var htmlTemplate = Convert.ToString(listItems[0][templateContentFieldName]);
                result = SendItemHelper.SendItemWithTemplate(web, items, htmlTemplate, from, to, subject, body);    
                goto Close;
            }

            result = SendItemHelper.SendItemWithDefaultTemplate(web, items, from, to, subject, body);

            // Close dialog
            Close:
            Page.Response.Clear();

            Page.Response.Write(result
                                    ? string.Format("<script type='text/javascript'>alert('{0}');window.frameElement.commitPopup();</script>", LocalizationHelper.GetString("SendItemWebPart_MS008"))
                                    : string.Format("<script type='text/javascript'>alert('{0}');window.frameElement.commitPopup();</script>", LocalizationHelper.GetString("SendItemWebPart_MS009")));

            Page.Response.Flush();
            Page.Response.End();
        }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            #region Row #1

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Rowspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddStyleAttribute(HtmlTextWriterStyle.Padding, "5px 10px 5px 10px");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Cursor, "pointer");
            btnSend.RenderControl(writer);

            writer.RenderEndTag(); // td

            writer.AddStyleAttribute(HtmlTextWriterStyle.Padding, "5px");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(LocalizationHelper.GetString("SendItemWebPart_MS010"));
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            txtTo.RenderControl(writer);
            rfvTo.RenderControl(writer);
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            #endregion

            #region Row #2

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddStyleAttribute(HtmlTextWriterStyle.Padding, "5px");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(LocalizationHelper.GetString("SendItemWebPart_MS011"));
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            txtSubject.RenderControl(writer);
            rfvSubject.RenderControl(writer);
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            #endregion

            #region Row #3

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("&nbsp;");
            writer.RenderEndTag(); // td

            writer.AddStyleAttribute(HtmlTextWriterStyle.Padding, "5px");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(LocalizationHelper.GetString("SendItemWebPart_MS012"));
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(LocalizationHelper.GetString("SendItemWebPart_MS013"));
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            #endregion

            #region Row #4

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "3");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            txtBody.RenderControl(writer);
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            #endregion

            writer.RenderEndTag(); // table
        }
    }
}