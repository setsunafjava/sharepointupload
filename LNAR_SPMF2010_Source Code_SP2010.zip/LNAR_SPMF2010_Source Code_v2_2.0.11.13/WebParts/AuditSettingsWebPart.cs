﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using DeutscheBank.SharePoint.LNAR.Framework.WebControls;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.WebControls;
using System.Globalization;
namespace DeutscheBank.SharePoint.LNAR.Framework.WebParts
{
    public class AuditSettingsWebPart : WebPart
    {
        private DropDownList ddlList;
        private CheckBoxList checkBoxMask;
        private Button btnGoDetail;
        private PropertySheetSection targetObjectSection;
        private PropertySheetSection flagAuditSection;
        private PropertySheet propertySheet;

        public override PartChromeType ChromeType
        {
            get { return PartChromeType.None; }
            set { base.ChromeType = value; }
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            var control = Page.Master.FindControl("PlaceHolderPageTitle");
            if (control != null)
            {
                control.Controls.Add(new LiteralControl(LocalizationHelper.GetString("AuditSettingWebPart_MS001")));
            }

            ddlList = new DropDownList { AutoPostBack = true };
            ddlList.SelectedIndexChanged += DdlListSelectedIndexChanged;
            Controls.Add(ddlList);

            checkBoxMask = new CheckBoxList();
            Controls.Add(checkBoxMask);

            #region run elevated get lists

            BindingToCheckBoxList();

            #endregion

            BindingToDropDownList(SPContext.Current.Web);

            propertySheet = new PropertySheet();
            Controls.Add(propertySheet);

            targetObjectSection = new PropertySheetSection { Header = LocalizationHelper.GetString("AuditSettingWebPart_MS002") };
            targetObjectSection.SectionRender += TargetObjSectionSectionRender;
            propertySheet.AddSection(targetObjectSection);

            flagAuditSection = new PropertySheetSection { Header = LocalizationHelper.GetString("AuditSettingWebPart_MS005"), Description = LocalizationHelper.GetString("AuditSettingWebPart_MS007") };
            flagAuditSection.SectionRender += AuditFlagSectionRender;
            propertySheet.AddSection(flagAuditSection);

            btnGoDetail = new Button { ID = "btnUpdateNow", Text = LocalizationHelper.GetString("AuditSettingWebPart_MS003") };
            btnGoDetail.Style.Add(HtmlTextWriterStyle.MarginRight, "100px");
            btnGoDetail.Click += BtnClick;
            propertySheet.AddButton(btnGoDetail);
        }

        void DdlListSelectedIndexChanged(object sender, EventArgs e)
        {
            BindingToCheckBoxList(GetCurrentObjectMask());
        }

        private int GetCurrentObjectMask()
        {
            var targetObj = ddlList.SelectedValue;

            int value;
            if (targetObj == "web")
            {
                value = AuditHelper.GetAuditStatus(SPContext.Current.Web, SPContext.Current.Web);
            }
            else
            {
                if (targetObj == "site")
                {
                    value = AuditHelper.GetAuditStatus(SPContext.Current.Web, SPContext.Current.Site);
                }
                else
                {
                    value = AuditHelper.GetAuditStatus(SPContext.Current.Web, SPContext.Current.Web.Lists[new Guid(targetObj)]);
                }
            }
            return value;
        }

        private void BtnClick(object sender, EventArgs e)
        {
            int flag = 0;
            foreach (ListItem item in checkBoxMask.Items)
            {
                if (item.Selected)
                {
                    flag |= Convert.ToInt32(item.Value, CultureInfo.InvariantCulture);
                }
            }
            SetFlag(flag);
        }

        protected override void OnLoad(EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (!SecurityHelper.DoesUserHavePermissionLevel(SPContext.Current.Web, FrameworkConstants.AuditRoleDefinition))
                {
                    SPUtility.HandleAccessDenied(null);
                }
            }

            base.OnLoad(e);
        }

        private void BindingToDropDownList(SPWeb spWeb)
        {
            var siteId = spWeb.Site.ID;
            var webId = spWeb.ID;
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        ddlList.Items.Add(new ListItem(LocalizationHelper.GetString("AuditSettingWebPart_MS008"), "site"));
                        ddlList.Items.Add(new ListItem(LocalizationHelper.GetString("AuditSettingWebPart_MS009"), "web"));
                        foreach (SPList list in web.Lists)
                        {
                            if (list.Hidden == false)
                                ddlList.Items.Add(new ListItem(string.Format(CultureInfo.InvariantCulture, "{0} {1}", LocalizationHelper.GetString("AuditSettingWebPart_MS010"), list.Title), list.ID.ToString()));
                        }
                    }
                }
            });
        }

        private void BindingToCheckBoxList()
        {
            foreach (int value in Enum.GetValues(typeof(SPAuditMaskType)))
            {
                if (value != 0)
                {
                    checkBoxMask.Items.Add(new ListItem(string.Format(CultureInfo.InvariantCulture, " {0}",Enum.GetName(typeof (SPAuditMaskType), value)), Convert.ToString(value, CultureInfo.InvariantCulture)));
                }
            }

            if (!Page.IsPostBack)
            {
                BindingToCheckBoxList(AuditHelper.GetAuditStatus(SPContext.Current.Web, SPContext.Current.Site));
            }
        }

        private void BindingToCheckBoxList(int value)
        {
            string tmpflag = IntegerToBin(value);

            foreach (ListItem item in checkBoxMask.Items)
            {
                item.Selected = false;
                item.Enabled = true;
            }

            if (tmpflag == "1111111111111111")
            {
                checkBoxMask.SelectedIndex = 14;
            }
            else
            {
                for (int i = 15; i > 0; i--)
                {
                    if (tmpflag[i] == '1')
                    {
                        checkBoxMask.Items[15 - i].Selected = true;
                    }
                }
            }
        }

        private static string IntegerToBin(int input)
        {
            string bitstring = null;
            for (int i = 15; i >= 0; i--)
            {
                string result = ((input >> i) & 1) == 1 ? "1" : "0";
                bitstring += result;
            }
            return bitstring;
        }

        private void TargetObjSectionSectionRender(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Span);
            writer.Write(LocalizationHelper.GetString("AuditSettingWebPart_MS004"));
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Br);
            writer.RenderEndTag();
            ddlList.RenderControl(writer);
        }

        private void AuditFlagSectionRender(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Span);
            writer.Write(LocalizationHelper.GetString("AuditSettingWebPart_MS006"));
            writer.RenderEndTag();

            writer.RenderBeginTag(HtmlTextWriterTag.Br);
            writer.RenderEndTag();

            if (ddlList.SelectedIndex == 0 || ddlList.SelectedIndex == 1)
            {
                checkBoxMask.Items[8].Enabled = !checkBoxMask.Items[8].Selected;
            }
            checkBoxMask.RenderControl(writer);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            propertySheet.RenderControl(writer);
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            var placeHolderAdditionalPageHead = Page.Master.FindControl("PlaceHolderAdditionalPageHead");
            if (placeHolderAdditionalPageHead != null)
            {
                placeHolderAdditionalPageHead.Controls.Add(new CssRegistration { Name = "layouts.css" });
            }

            Page.ClientScript.RegisterStartupScript(GetType(), "Remove WBBody css class",
                                                    "$(document).ready(function(){$('.ms-WPBody').removeClass('ms-WPBody');});",
                                                    true);

            CssRegistration.Register("datepickerv4.css", true);
        }

        private void SetFlag(int flag)
        {
            if (ddlList.SelectedValue == "site")
            {
                AuditHelper.ModifyConfigAudit(SPContext.Current.Web, SPContext.Current.Site, flag);
            }
            else
            {
                if (ddlList.SelectedValue == "web")
                {
                    AuditHelper.ModifyConfigAudit(SPContext.Current.Web, SPContext.Current.Web, flag);
                }
                else
                {
                    AuditHelper.ModifyConfigAudit(SPContext.Current.Web, SPContext.Current.Web.Lists[new Guid(ddlList.SelectedValue)], flag);
                }
            }
        }

    }
}
