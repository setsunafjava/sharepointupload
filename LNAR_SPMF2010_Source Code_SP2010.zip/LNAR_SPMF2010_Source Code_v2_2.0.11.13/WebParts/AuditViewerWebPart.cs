﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using System.Collections.Generic;
using System.IO;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Ap = DocumentFormat.OpenXml.ExtendedProperties;
using Vt = DocumentFormat.OpenXml.VariantTypes;
using A = DocumentFormat.OpenXml.Drawing;
using FontSize = DocumentFormat.OpenXml.Spreadsheet.FontSize;
using System.Collections.ObjectModel;
using System.Globalization;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebParts
{
    public class AuditViewerWebPart : WebPart
    {
        #region Main Webpart
        private DateTimeControl startDateSelector;
        private DateTimeControl endDateSelector;
        private PeopleEditor restrictToUser;
        private DropDownList ddlScope;
        //private DropDownList ddlLists;
        private Button btnGetReport;
        private DataTable table;
        private GridView dataGrid;
        private DropDownList reportType;
        private Button btnExportToExcel;
        private HyperLink excelLink;

        private readonly List<ReportType> listReport = new List<ReportType>{
               new ReportType
                {
                    ReportName = LocalizationHelper.GetString("AuditViewerReportType_MS003"), ReportId = 3
                },
                new ReportType
                {
                    ReportName = LocalizationHelper.GetString("AuditViewerReportType_MS005"), ReportId = 0
                }
        };

        private readonly List<ReportType> actorReport = new List<ReportType> {
            new ReportType
                {
                    ReportName = LocalizationHelper.GetString("AuditViewerReportType_MS002"), ReportId = 3
                },
            new ReportType
                {
                    ReportName = LocalizationHelper.GetString("AuditViewerReportType_MS005"), ReportId = 0
                }
        };

        private readonly List<ReportType> victimReport = new List<ReportType> { 
            new ReportType
                {
                    ReportName = LocalizationHelper.GetString("AuditViewerReportType_MS001"), ReportId = 3
                },
                // Todo: Enable or diable All audit entity report
            /*new ReportType
             {
                 ReportName = LocalizationHelper.GetString("AuditViewerReportType_MS005"), ReportId = 0
             }*/
        };

        private readonly List<ReportType> appReport = new List<ReportType> { 
            new ReportType
                {
                    ReportName = LocalizationHelper.GetString("AuditViewerReportType_MS004"), ReportId = 3
                },
         new ReportType
             {
                 ReportName = LocalizationHelper.GetString("AuditViewerReportType_MS005"), ReportId = 0
             },
             new ReportType
             {
                 ReportName = "User Last Access", ReportId = 9
             }
        };

        public override PartChromeType ChromeType
        {
            get { return PartChromeType.None; }
            set { base.ChromeType = value; }
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            var control = Page.Master.FindControl("PlaceHolderPageTitle");
            if (control != null)
            {
                control.Controls.Add(new LiteralControl("Audit Log Viewer"));
            }

            var placeHolderAdditionalPageHead = Page.Master.FindControl("PlaceHolderAdditionalPageHead");
            if (placeHolderAdditionalPageHead != null)
            {
                placeHolderAdditionalPageHead.Controls.Add(new CssRegistration { Name = "layouts.css" });
            }

            ddlScope = new DropDownList {AutoPostBack = true, Width = 165};
            ddlScope.SelectedIndexChanged += DdlScopeSelectedIndexChanged;

            ddlScope.Items.Add(LocalizationHelper.GetString("AuditViewerWebPart_MS006"));
            ddlScope.Items.Add(LocalizationHelper.GetString("AuditViewerWebPart_MS007"));

            // Todo: Enable or diable List audit type
            //ddlScope.Items.Add(LocalizationHelper.GetString("AuditViewerWebPart_MS008"));
            ddlScope.Items.Add(LocalizationHelper.GetString("AuditViewerWebPart_MS009"));
            Controls.Add(ddlScope);

            //ddlLists = new DropDownList { ID = "ddlLists"};
            //ddlScope.Width = 165;
            //Controls.Add(ddlLists);

            var datePickerFrameUrl = string.Format(CultureInfo.InvariantCulture,"{0}/_layouts/iframe.aspx", SPContext.Current.Web.Url);

            startDateSelector = new DateTimeControl
            {
                DateOnly = true,
                DatePickerFrameUrl = datePickerFrameUrl
            };
            Controls.Add(startDateSelector);

            endDateSelector = new DateTimeControl
            {
                DateOnly = true,
                DatePickerFrameUrl = datePickerFrameUrl,
            };
            
            Controls.Add(endDateSelector);

            restrictToUser = new PeopleEditor
                                 {
                                     MultiSelect = false,
                                     SelectionSet = "User",
                                     Width = new Unit(250, UnitType.Pixel),
                                 };
            Controls.Add(restrictToUser);

            btnGetReport = new Button { Text = LocalizationHelper.GetString("AuditViewerWebPart_MS013") };
            btnGetReport.Click += BtnGetReportClick;
            Controls.Add(btnGetReport);

            dataGrid = new GridView {AllowPaging = true, AutoGenerateColumns = true, PageSize = 25, EnableViewState = false};

            dataGrid.PagerSettings.Mode = PagerButtons.Numeric;
            dataGrid.PageIndexChanging += DataGridPageIndexChanging;
            dataGrid.GridLines = GridLines.Both;
            dataGrid.SkinID = "myGrid";
            dataGrid.CssClass = "myGrid";
            dataGrid.PagerStyle.HorizontalAlign = HorizontalAlign.Center;
            
           
            Controls.Add(dataGrid);

            reportType = new DropDownList {Width = 250};
            Controls.Add(reportType);
            SelectReport();

            btnExportToExcel = new Button { Text = LocalizationHelper.GetString("AuditViewerWebPart_MS014") };
            btnExportToExcel.Click += BtnExportToExcelClick;
            Controls.Add(btnExportToExcel);

            excelLink = new HyperLink();
            Controls.Add(excelLink);
        }
    
        private static string IsolateString(string input)
        {
            return input.Replace(" ", "_").Replace(":", "_").Replace("\\", "_").Replace("/", "_");
        }

        #region Event Handler
        void DdlScopeSelectedIndexChanged(object sender, EventArgs e)
        {
            SelectReport();
        }

        void DataGridPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
           if (e.NewPageIndex == -1)
           {
               e.Cancel = true;
           }
           else
           {
               dataGrid.PageIndex = e.NewPageIndex;
               dataGrid.DataSource = GetDataTable();
               dataGrid.DataBind();
           }
        }

        void BtnGetReportClick(object sender, EventArgs e)
        {
            if (startDateSelector.IsValid && endDateSelector.IsValid)
            {
                if (ValidDateTimeRange(startDateSelector.SelectedDate, endDateSelector.SelectedDate))
                {
                    table = GetDataTable();
                }
                else
                {
                    startDateSelector.IsValid = false;
                    startDateSelector.ErrorMessage = LocalizationHelper.GetString("AuditViewerWebPart_MS016");
                }
            }

            if (table != null)
            {
                dataGrid.DataSource = table;
                dataGrid.DataBind();    
            }
        }

        void BtnExportToExcelClick(object sender, EventArgs e)
        {
            if (startDateSelector.IsValid && endDateSelector.IsValid)
            {
                if (ValidDateTimeRange(startDateSelector.SelectedDate, endDateSelector.SelectedDate))
                {
                    #region

                    string returnUrl = string.Format(CultureInfo.InvariantCulture, "{0}/AuditLogViewer.aspx?report=", SPContext.Current.Web.Url);
                    try
                    {
                        using (var operation = new SPLongOperation(Page))
                        {
                            operation.LeadingHTML = LocalizationHelper.GetString("AuditViewerWebPart_MS005");
                            operation.Begin();
                            table = GetDataTable();
                            var headers = new List<string>();
                            foreach (DataColumn dataColumn in table.Columns)
                            {
                                headers.Add(dataColumn.ColumnName);
                            }
                            byte[] contentFile = CreatePackage(reportType.SelectedItem.Text, table, headers.ToArray());

                            var reportUrl = string.Empty;
                            var siteId = SPContext.Current.Web.Site.ID;
                            var webId = SPContext.Current.Web.ID;
                            SPSecurity.RunWithElevatedPrivileges(() =>
                            {
                                using (var site = new SPSite(siteId))
                                {
                                    using (var web = site.OpenWeb(webId))
                                    {
                                        var allowUnsafe = SecurityHelper.SetAllowUnsafeUpdates(web);
                                         var docLib = web.Lists[FrameworkConstants.AuditList];
                                        SPFolder folder = docLib.RootFolder;
                                        SPFileCollection fcol = folder.Files;
                                        reportUrl = String.Concat(folder.Url,
                                                         string.Format(CultureInfo.InvariantCulture ,"/{0}_{1}.xlsx", IsolateString(reportType.SelectedItem.Text),
                                                                       IsolateString(DateTime.Now.ToString())));
                                        SPFile addedFile = fcol.Add(reportUrl, contentFile);
                                        SPItem newItem = addedFile.Item;
                                        newItem.Update();
                                        SecurityHelper.RollbackAllowUnsafeUpdates(web, allowUnsafe);
                                    }
                                }
                            });
                            operation.End(returnUrl + reportUrl);
                        }
                    }
                    catch (Exception ex)
                    {
                        SPUtility.TransferToErrorPage(ex.ToString());
                    }

                    #endregion
                }
                else
                {
                    startDateSelector.IsValid = false;
                    startDateSelector.ErrorMessage = LocalizationHelper.GetString("AuditViewerWebPart_MS016");
                }
            }
        }

        #endregion

        private DataTable GetDataTable()
        {
            var useridCol = new Collection <int>();
          
            if (!string.IsNullOrEmpty(restrictToUser.CommaSeparatedAccounts))

            foreach (PickerEntity objEntity in restrictToUser.ResolvedEntities)
            {
                useridCol.Add(Convert.ToInt32(objEntity.EntityData["SPUserID"], CultureInfo.InvariantCulture));
            }
            
            var userNameCol = new Collection<string>();
           
            foreach (PickerEntity objEntity in restrictToUser.ResolvedEntities)
            {
                userNameCol.Add(Convert.ToString(objEntity.EntityData["AccountName"], CultureInfo.InvariantCulture).Replace(@"\\", @"\"));
            }

            var auditHelper = new AuditHelper();
            int selectReport = Convert.ToInt32(reportType.SelectedValue, CultureInfo.InvariantCulture);
            if (!startDateSelector.IsDateEmpty)
                auditHelper.StartDate = startDateSelector.SelectedDate;
            if (!endDateSelector.IsDateEmpty)
                auditHelper.EndDate = endDateSelector.SelectedDate;
            switch (ddlScope.SelectedIndex)
            {
                case 0:
                    {
                        // Victim
                        if (userNameCol.Count == 0)
                        {
                            restrictToUser.IsValid = false;
                            restrictToUser.ErrorMessage = LocalizationHelper.GetString("ArchiveListWebPart_MS018");
                        }
                        else
                        {
                            table = auditHelper.GetAuditUserByUser(SPContext.Current.Web, userNameCol, selectReport);
                        }
                        break;
                    }
                case 1:
                    {
                        // Actor
                        table = auditHelper.GetAuditActorData(SPContext.Current.Web, useridCol, selectReport);                       
                        break;
                    }
                case 2:
                    {
                        // Run around the app
                        table = auditHelper.GetAllWebAudit(SPContext.Current.Web, selectReport);
                        break;
                    }
                default:
                    {
                        //table = auditHelper.GetAuditListData(SPContext.Current.Web, new Collection<Guid> { new Guid(ddlLists.SelectedItem.Value) }, selectReport);                     
                        throw new NotSupportedException();
                    }
            }
            return table;            
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (!Page.IsPostBack)
            {
                if (!SecurityHelper.DoesUserHavePermissionLevel(SPContext.Current.Web, FrameworkConstants.AuditRoleDefinition))
                {
                    SPUtility.HandleAccessDenied(null);
                }
                
                EnsureChildControls();
                  
                // Todo: Enable or disable List scope
                //BindingForListsDropdown(SPContext.Current.Web);
            }          
        }

        /*private void BindingForListsDropdown(SPWeb spWeb)
        {
            var siteId = spWeb.Site.ID;
            var webId = spWeb.ID;
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        ddlLists.Items.Clear();
                        foreach (SPList list in web.Lists)
                        {
                            if (list.Hidden == false)
                                ddlLists.Items.Add(new ListItem(list.Title, list.ID.ToString()));
                        }   
                    }
                }
            });
        }*/


        protected override void Render(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "5");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            
            // Tr #1
            #region
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "12%");
            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(LocalizationHelper.GetString("AuditViewerWebPart_MS001"));
            writer.RenderEndTag(); // td

            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "20%");
            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            ddlScope.RenderControl(writer);
            writer.RenderEndTag(); // td

            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "15%");
            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            if (ddlScope.SelectedIndex == 2)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Id, "lblLists");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write(LocalizationHelper.GetString("AuditViewerWebPart_MS012"));
                writer.RenderEndTag(); // span
            }

            if (ddlScope.SelectedIndex == 0)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write(LocalizationHelper.GetString("AuditViewerWebPart_MS010"));
                writer.RenderEndTag(); // span
            }

            if (ddlScope.SelectedIndex == 1)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write(LocalizationHelper.GetString("AuditViewerWebPart_MS011"));
                writer.RenderEndTag(); // span
            }
            if (ddlScope.SelectedIndex == 3)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write("&nbsp;");
                writer.RenderEndTag(); // span
            }
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            
            //if (ddlScope.SelectedIndex == 2)
            //{
            //    ddlLists.RenderControl(writer);
            //}

            if (ddlScope.SelectedIndex == 1 || ddlScope.SelectedIndex == 0)
            {
                restrictToUser.RenderControl(writer);
            }
            if (ddlScope.SelectedIndex == 3)
            {
                writer.Write("&nbsp;");
            }       
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr
            #endregion

            // Tr #2
            #region
            writer.AddAttribute(HtmlTextWriterAttribute.Valign,"top");
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(LocalizationHelper.GetString("AuditViewerWebPart_MS002"));
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            startDateSelector.RenderControl(writer);
            writer.RenderEndTag(); // td

         

            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(LocalizationHelper.GetString("AuditViewerWebPart_MS003"));
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            endDateSelector.RenderControl(writer);
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr
 
            #endregion

          //   Tr #3
            
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(LocalizationHelper.GetString("AuditViewerWebPart_MS004"));
            writer.RenderEndTag();

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            reportType.RenderControl(writer);
            writer.RenderEndTag();

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            btnGetReport.RenderControl(writer);
            writer.RenderEndTag();

            writer.RenderBeginTag(HtmlTextWriterTag.Td);          
            btnExportToExcel.RenderControl(writer);          
            writer.RenderEndTag();
         
            writer.RenderEndTag();

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.RenderEndTag();
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            if (!string.IsNullOrEmpty(Page.Request.QueryString["report"]) && (!Page.IsPostBack))
            {
                excelLink.Text = LocalizationHelper.GetString("AuditViewerWebPart_MS015");
                excelLink.NavigateUrl = string.Format(CultureInfo.InvariantCulture,"{0}/{1}", SPContext.Current.Web.Url, Page.Request.QueryString["report"]);
                excelLink.RenderControl(writer);
                writer.Write("&nbsp;");
            }
            writer.RenderEndTag();
            writer.RenderEndTag();

            writer.RenderEndTag(); // table

            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "98%");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.RenderBeginTag(HtmlTextWriterTag.Center);
            writer.AddStyleAttribute(HtmlTextWriterStyle.Color, "#0018a8");
            writer.AddAttribute(HtmlTextWriterAttribute.Style,"font-size:20px");
            writer.RenderBeginTag(HtmlTextWriterTag.Span);
            if (table != null)
            {
                writer.Write(reportType.SelectedItem.Text);
            }
            writer.RenderEndTag();// span
            writer.RenderEndTag();
            writer.RenderEndTag();
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            dataGrid.RenderControl(writer);
            writer.RenderEndTag();
            writer.RenderEndTag();
            writer.RenderEndTag();
       
            RenderStyle(writer);
            //RenderScript(writer);

        }

        //private void RenderScript(HtmlTextWriter writer)
        //{
        //    writer.AddAttribute(HtmlTextWriterAttribute.Type, "text/javascript");
        //    writer.RenderBeginTag(HtmlTextWriterTag.Script);
        //    writer.Write("function onScopeChanged(value){");
        //    writer.Write(string.Format(CultureInfo.InvariantCulture ,"if(value == 'List'){{document.getElementById('lblUsers').style.display = 'none';document.getElementById('lblLists').style.display = 'block';document.getElementById('{0}').style.display = 'block';}};", ddlLists.ClientID));
        //    writer.Write(string.Format(CultureInfo.InvariantCulture, "else{{document.getElementById('lblUsers').style.display = 'block';document.getElementById('lblLists').style.display = 'none';document.getElementById('{0}').style.display = 'none';}};", ddlLists.ClientID));
        //    writer.Write("}");
        //    writer.RenderEndTag(); // script
        //}

        private static void RenderStyle (HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Type, "text/css");
            writer.RenderBeginTag(HtmlTextWriterTag.Style);
            writer.Write(@".myGrid{margin: 0px;width: 98%;
                        	font: 12px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	                       }");
            writer.Write(@" .myGrid tr{border: solid 1px #307196;valign:top;}
                            .myGrid td{padding: 3px;font-weight: normal;border: solid 1px #0018a8; valign:top;}
                            .myGrid td.right{	color: Red;}.myGrid td.wrong{color: Green;}
                            .myGrid th{font-weight: bold;padding: 6px 3px;background: #0018a8;color: White;}
                            .myGridItem
                            {background-color:#C6DCEA;	color:#333;border-top:1px solid Black;}
                            .myGridItem:hover{background-color:#FBC9A4;}
                            .myGridAltItem{background:#EAF1F7;color:#333;}
                            .myGridAltItem:hover{background-color:#0018a8;}
                            .myGridHeader{border-top: groove 2px #0018a8;}");
            writer.RenderEndTag(); 
        }
        
        private void SelectReport ()
        {
            switch (ddlScope.SelectedIndex)
            {
                case 1:
                    {
                        BindingReportDropDown(actorReport);
                        break;
                    }
                case 0:
                    {
                        BindingReportDropDown(victimReport);
                        break;
                    }
                case 2:
                    {
                        BindingReportDropDown(listReport);
                        break;
                    }
                default:
                    {
                        BindingReportDropDown(appReport);
                        break;
                    }
            }
        }

        private void BindingReportDropDown(IEnumerable<ReportType> list)
        {
            reportType.Items.Clear();
            foreach (ReportType type in list)
            {
                reportType.Items.Add(new ListItem(type.ReportName, Convert.ToString(type.ReportId, CultureInfo.InvariantCulture)));
            }
            reportType.DataBind();
        }

        private static bool ValidDateTimeRange(DateTime startDate, DateTime endDate)
        {
            if (startDate > endDate)
                return false;
            return true;
        }
        
        #endregion
              
        #region Export Excel
        #region Private Property

        private const int StartDataRowIndex = 6; // The data starts at row 6
        private const int StartDataColIndex = 2;
        private const string colHeader = "ABCDEFGHIJKLMNOPQRSTUVQXYZ"; // start column of data if B
        private int countColData;
        private DataTable dataContent; // Content of file
        private string fileTitle;
        private string[] headerTitles; // header text of data

        #endregion

        // Creates a SpreadsheetDocument.
        public byte[] CreatePackage(string title, DataTable dataSource, string[] headerTexts)
        {
            fileTitle = title;
            dataContent = dataSource;
            countColData = dataSource.Columns.Count;

            headerTitles = new string[countColData];
            headerTexts.CopyTo(headerTitles, 0);

            var ms = new MemoryStream();

            using (SpreadsheetDocument package = SpreadsheetDocument.Create(ms, SpreadsheetDocumentType.Workbook))
            {
                CreateParts(package);
                package.Close();
            }
            ms.Seek(0, SeekOrigin.Begin);
            var buffer = new byte[ms.Length];
            ms.Read(buffer, 0, buffer.Length);
            return buffer;
        }

        #region Private Methods: Export Excel File

        // Adds child parts and generates content of the specified part.
        private void CreateParts(SpreadsheetDocument document)
        {
            WorkbookPart workbookPart1 = document.AddWorkbookPart();
            GenerateWorkbookPart1Content(workbookPart1);

            var workbookStylesPart1 = workbookPart1.AddNewPart<WorkbookStylesPart>("rId3");
            GenerateWorkbookStylesPart1Content(workbookStylesPart1);

            var worksheetPart1 = workbookPart1.AddNewPart<WorksheetPart>("rId1");
            GenerateWorksheetPart1Content(worksheetPart1);

            var spreadsheetPrinterSettingsPart1 = worksheetPart1.AddNewPart<SpreadsheetPrinterSettingsPart>("rId1");
            GenerateSpreadsheetPrinterSettingsPart1Content(spreadsheetPrinterSettingsPart1);

            var sharedStringTablePart1 = workbookPart1.AddNewPart<SharedStringTablePart>("rId4");
            GenerateSharedStringTablePart1Content(sharedStringTablePart1);
        }

        // Generates content of workbookPart1.
        private static void GenerateWorkbookPart1Content(WorkbookPart workbookPart1)
        {
            var workbook1 = new Workbook();
            workbook1.AddNamespaceDeclaration("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");

            var workbookProperties1 = new WorkbookProperties { DefaultThemeVersion = 124226U };

            var bookViews1 = new BookViews();
            var workbookView1 = new WorkbookView { XWindow = 0, YWindow = 90, WindowWidth = 15480U, WindowHeight = 8700U };

            bookViews1.Append(workbookView1);

            var sheets1 = new Sheets();
            var sheet1 = new Sheet { Name = "Sheet1", SheetId = 1U, Id = "rId1" };

            sheets1.Append(sheet1);
            var calculationProperties1 = new CalculationProperties { CalculationId = 125725U };

            workbook1.Append(workbookProperties1);
            workbook1.Append(bookViews1);
            workbook1.Append(sheets1);
            workbook1.Append(calculationProperties1);

            workbookPart1.Workbook = workbook1;
        }

        // Generates content of workbookStylesPart1.
        private static void GenerateWorkbookStylesPart1Content(WorkbookStylesPart workbookStylesPart1)
        {
            var stylesheet1 = new Stylesheet();

            var fonts1 = new Fonts { Count = 5U };

            var font1 = new Font();
            var fontSize1 = new FontSize { Val = 11D };
            var color1 = new Color { Theme = 1U };
            var fontName1 = new FontName { Val = "Calibri" };
            var fontFamilyNumbering1 = new FontFamilyNumbering { Val = 2 };
            var fontScheme1 = new FontScheme { Val = FontSchemeValues.Minor };

            font1.Append(fontSize1);
            font1.Append(color1);
            font1.Append(fontName1);
            font1.Append(fontFamilyNumbering1);
            font1.Append(fontScheme1);

            var font2 = new Font();
            var bold1 = new Bold();
            var fontSize2 = new FontSize { Val = 12D };
            var color2 = new Color { Theme = 1U };
            var fontName2 = new FontName { Val = "Arial" };
            var fontFamilyNumbering2 = new FontFamilyNumbering { Val = 2 };

            font2.Append(bold1);
            font2.Append(fontSize2);
            font2.Append(color2);
            font2.Append(fontName2);
            font2.Append(fontFamilyNumbering2);

            var font3 = new Font();
            var fontSize3 = new FontSize { Val = 11D };
            var color3 = new Color { Theme = 1U };
            var fontName3 = new FontName { Val = "Arial" };
            var fontFamilyNumbering3 = new FontFamilyNumbering { Val = 2 };

            font3.Append(fontSize3);
            font3.Append(color3);
            font3.Append(fontName3);
            font3.Append(fontFamilyNumbering3);

            var font4 = new Font();
            var fontSize4 = new FontSize { Val = 10D };
            var color4 = new Color { Theme = 1U };
            var fontName4 = new FontName { Val = "Arial" };
            var fontFamilyNumbering4 = new FontFamilyNumbering { Val = 2 };

            font4.Append(fontSize4);
            font4.Append(color4);
            font4.Append(fontName4);
            font4.Append(fontFamilyNumbering4);

            var font5 = new Font();
            var bold2 = new Bold();
            var fontSize5 = new FontSize { Val = 10D };
            var color5 = new Color { Theme = 1U };
            var fontName5 = new FontName { Val = "Arial" };
            var fontFamilyNumbering5 = new FontFamilyNumbering { Val = 2 };

            font5.Append(bold2);
            font5.Append(fontSize5);
            font5.Append(color5);
            font5.Append(fontName5);
            font5.Append(fontFamilyNumbering5);

            fonts1.Append(font1);
            fonts1.Append(font2);
            fonts1.Append(font3);
            fonts1.Append(font4);
            fonts1.Append(font5);

            var fills1 = new Fills { Count = 3U };

            var fill1 = new Fill();
            var patternFill1 = new PatternFill { PatternType = PatternValues.None };

            fill1.Append(patternFill1);

            var fill2 = new Fill();
            var patternFill2 = new PatternFill { PatternType = PatternValues.Gray125 };

            fill2.Append(patternFill2);

            var fill3 = new Fill();

            var patternFill3 = new PatternFill { PatternType = PatternValues.Solid };
            var foregroundColor1 = new ForegroundColor { Theme = 0U, Tint = -0.14999847407452621D };
            var backgroundColor1 = new BackgroundColor { Indexed = 64U };

            patternFill3.Append(foregroundColor1);
            patternFill3.Append(backgroundColor1);

            fill3.Append(patternFill3);

            fills1.Append(fill1);
            fills1.Append(fill2);
            fills1.Append(fill3);

            var borders1 = new Borders { Count = 2U };

            var border1 = new Border();
            var leftBorder1 = new LeftBorder();
            var rightBorder1 = new RightBorder();
            var topBorder1 = new TopBorder();
            var bottomBorder1 = new BottomBorder();
            var diagonalBorder1 = new DiagonalBorder();

            border1.Append(leftBorder1);
            border1.Append(rightBorder1);
            border1.Append(topBorder1);
            border1.Append(bottomBorder1);
            border1.Append(diagonalBorder1);

            var border2 = new Border();

            var leftBorder2 = new LeftBorder { Style = BorderStyleValues.Thin };
            var color6 = new Color { Theme = 0U, Tint = -0.34998626667073579D };

            leftBorder2.Append(color6);

            var rightBorder2 = new RightBorder { Style = BorderStyleValues.Thin };
            var color7 = new Color { Theme = 0U, Tint = -0.34998626667073579D };

            rightBorder2.Append(color7);

            var topBorder2 = new TopBorder { Style = BorderStyleValues.Thin };
            var color8 = new Color { Theme = 0U, Tint = -0.34998626667073579D };

            topBorder2.Append(color8);

            var bottomBorder2 = new BottomBorder { Style = BorderStyleValues.Thin };
            var color9 = new Color { Theme = 0U, Tint = -0.34998626667073579D };

            bottomBorder2.Append(color9);
            var diagonalBorder2 = new DiagonalBorder();

            border2.Append(leftBorder2);
            border2.Append(rightBorder2);
            border2.Append(topBorder2);
            border2.Append(bottomBorder2);
            border2.Append(diagonalBorder2);

            borders1.Append(border1);
            borders1.Append(border2);

            var cellStyleFormats1 = new CellStyleFormats { Count = 1U };
            var cellFormat1 = new CellFormat { NumberFormatId = 0U, FontId = 0U, FillId = 0U, BorderId = 0U };

            cellStyleFormats1.Append(cellFormat1);

            var cellFormats1 = new CellFormats { Count = 6U };
            var cellFormat2 = new CellFormat { NumberFormatId = 0U, FontId = 0U, FillId = 0U, BorderId = 0U, FormatId = 0U };
            var cellFormat3 = new CellFormat
            {
                NumberFormatId = 0U,
                FontId = 1U,
                FillId = 0U,
                BorderId = 0U,
                FormatId = 0U,
                ApplyFont = true
            };
            var cellFormat4 = new CellFormat
            {
                NumberFormatId = 0U,
                FontId = 2U,
                FillId = 0U,
                BorderId = 0U,
                FormatId = 0U,
                ApplyFont = true
            };
            var cellFormat5 = new CellFormat
            {
                NumberFormatId = 0U,
                FontId = 3U,
                FillId = 0U,
                BorderId = 0U,
                FormatId = 0U,
                ApplyFont = true
            };
            var cellFormat6 = new CellFormat
            {
                NumberFormatId = 0U,
                FontId = 4U,
                FillId = 2U,
                BorderId = 1U,
                FormatId = 0U,
                ApplyFont = true,
                ApplyFill = true,
                ApplyBorder = true
            };
            var cellFormat7 = new CellFormat
            {
                NumberFormatId = 0U,
                FontId = 3U,
                FillId = 0U,
                BorderId = 1U,
                FormatId = 0U,
                ApplyFont = true,
                ApplyBorder = true
            };

            cellFormats1.Append(cellFormat2);
            cellFormats1.Append(cellFormat3);
            cellFormats1.Append(cellFormat4);
            cellFormats1.Append(cellFormat5);
            cellFormats1.Append(cellFormat6);
            cellFormats1.Append(cellFormat7);

            var cellStyles1 = new CellStyles { Count = 1U };
            var cellStyle1 = new CellStyle { Name = "Normal", FormatId = 0U, BuiltinId = 0U };

            cellStyles1.Append(cellStyle1);
            var differentialFormats1 = new DifferentialFormats { Count = 0U };
            var tableStyles1 = new TableStyles
            {
                Count = 0U,
                DefaultTableStyle = "TableStyleMedium9",
                DefaultPivotStyle = "PivotStyleLight16"
            };

            stylesheet1.Append(fonts1);
            stylesheet1.Append(fills1);
            stylesheet1.Append(borders1);
            stylesheet1.Append(cellStyleFormats1);
            stylesheet1.Append(cellFormats1);
            stylesheet1.Append(cellStyles1);
            stylesheet1.Append(differentialFormats1);
            stylesheet1.Append(tableStyles1);

            workbookStylesPart1.Stylesheet = stylesheet1;
        }

        // Generates content of spreadsheetPrinterSettingsPart1.
        private void GenerateSpreadsheetPrinterSettingsPart1Content(
            SpreadsheetPrinterSettingsPart spreadsheetPrinterSettingsPart1)
        {
            Stream data = GetBinaryDataStream(spreadsheetPrinterSettingsPart1Data);
            spreadsheetPrinterSettingsPart1.FeedData(data);
            data.Close();
        }

        // Generates content of worksheetPart1.
        private void GenerateWorksheetPart1Content(WorksheetPart worksheetPart1)
        {
            // count numbers of rows of records
            int countData = dataContent.Rows.Count;

            // end row index of data range
            int endRowIndex = StartDataRowIndex + countData - 1;
            // end col index of data range
            char endColIndex = colHeader[StartDataColIndex + -1];

            var worksheet1 = new Worksheet();
            worksheet1.AddNamespaceDeclaration("r",
                                               "http://schemas.openxmlformats.org/officeDocument/2006/relationships");

            string dataRange = string.Format(CultureInfo.InvariantCulture,"B2:{0}{1}", endColIndex, endRowIndex);
            var sheetDimension1 = new SheetDimension { Reference = dataRange };

            var sheetViews1 = new SheetViews();
            var sheetView1 = new SheetView { ShowGridLines = false, TabSelected = true, WorkbookViewId = 0U };
            var selection1 = new Selection
            {
                ActiveCell = "B6",
                SequenceOfReferences = new ListValue<StringValue> { InnerText = "B6" }
            };
            sheetView1.Append(selection1);
            sheetViews1.Append(sheetView1);

            var columns1 = new Columns();
            // [Number] column
            var column1 = new Column { Min = 1U, Max = 1U, Width = 3.5D, Style = 3U, CustomWidth = true };
            columns1.Append(column1);

            for (uint i = 1; i < countColData; i++)
            {
                var value = new UInt32Value(i + 2);
                var column = new Column { Min = value, Max = value, Width = 34D, Style = 3U, CustomWidth = true };
                columns1.Append(column);
            }

            var sheetData1 = new SheetData();

            var row1 = new Row { RowIndex = 2U, Height = 14.25D };
            var cell1 = new Cell { CellReference = "B2", StyleIndex = 2U, DataType = CellValues.SharedString };
            cell1.Append(new CellValue("0"));
            row1.Append(cell1);

            var row2 = new Row { RowIndex = 3U, Height = 15.75D };
            var cell2 = new Cell { CellReference = "B3", StyleIndex = 1U, DataType = CellValues.SharedString };
            cell2.Append(new CellValue("1"));
            row2.Append(cell2);

            // Create header text of content table
            var row3 = new Row { RowIndex = 5U, Height = 17.25D, CustomHeight = true };
            int headerRowIndex = StartDataRowIndex - 1;
            for (int i = 0; i < countColData; i++)
            {
                var cell = new Cell
                {
                    CellReference = colHeader[i + 1] + "" + headerRowIndex,
                    StyleIndex = 4U,
                    DataType = CellValues.SharedString
                };
                cell.Append(new CellValue(Convert.ToString(i + 2, CultureInfo.InvariantCulture)));
                row3.Append(cell);
            }
            sheetData1.Append(row1);
            sheetData1.Append(row2);
            sheetData1.Append(row3);

            // Create content for table
            int startShareValueIndex = 2 + countColData;
            if (dataContent != null)
            {
                for (int i = StartDataRowIndex, j = 0; i <= endRowIndex; i++, j++)
                {
                    Row row = CreateContentRowCell((UInt32)i, (UInt32)(j * countColData + startShareValueIndex));
                    sheetData1.Append(row);
                }
            }

            worksheet1.Append(sheetDimension1);
            worksheet1.Append(sheetViews1);
            worksheet1.Append(columns1);
            worksheet1.Append(sheetData1);

            worksheetPart1.Worksheet = worksheet1;
        }

        // Create rows that contain the data
        private Row CreateContentRowCell(UInt32Value rowIndex, UInt32Value cellIndex)
        {
            //Create the new row.
            var row = new Row { RowIndex = rowIndex };

            Cell cell;
            // Create cells that contain the data
            for (int i = 0; i < countColData; i++)
            {
                cell = new Cell
                {
                    CellReference = colHeader[i + 1] + "" + rowIndex,
                    StyleIndex = 5U,
                    DataType = CellValues.SharedString
                };

                cell.Append(new CellValue(Convert.ToString(cellIndex + i, CultureInfo.InvariantCulture)));
                row.Append(cell);
            }

            return row;
        }

        // Generates content template of sharedStringTablePart1.
        private void GenerateSharedStringTablePart1Content(SharedStringTablePart sharedStringTablePart1)
        {
            var sharedStringTable1 = new SharedStringTable { Count = 6U, UniqueCount = 6U };

            var sharedStringItem1 = new SharedStringItem();
            var text1 = new Text();
            text1.Text = string.Format(CultureInfo.InvariantCulture, "Update from {0}", DateTime.Now);
            sharedStringItem1.Append(text1);

            var sharedStringItem2 = new SharedStringItem();
            var text2 = new Text();
            text2.Text = fileTitle;
            sharedStringItem2.Append(text2);

            sharedStringTable1.Append(sharedStringItem1);
            sharedStringTable1.Append(sharedStringItem2);

            // Populate header text
            for (int i = 0; i < countColData; i++)
            {
                var sharedStringItem = new SharedStringItem(new Text(headerTitles[i]));
                sharedStringTable1.Append(sharedStringItem);
            }

            // Count numbers of rows of data
            int countData = dataContent.Rows.Count;
            // For each row in the datatable, add a row to spreadsheet.
            for (int i = 0; i < countData; i++)
            {
                DataRow row = dataContent.Rows[i];
                for (int j = 0; j < countColData; j++)
                {
                    var sharedStringItem = new SharedStringItem(new Text(Convert.ToString(row[j], CultureInfo.InvariantCulture)));
                    sharedStringTable1.Append(sharedStringItem);
                }
            }

            sharedStringTablePart1.SharedStringTable = sharedStringTable1;
        }

        #endregion

        #region Binary Data

        private string spreadsheetPrinterSettingsPart1Data =
            "UwBuAGEAZwBJAHQAIAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEEAAbcAOwCQ++ABQEAAQDqCm8IZAABAA8AyAACAAEAyAACAAEATABlAHQAdABlAHIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAABAAAAAgAAAAEAAAD/////AAAAAAAAAAAAAAAAAAAAAERJTlUiALAA7AIAAMGVHPsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgAAAAEAAAAAAAAAAgABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAsAAAAFNNVEoAAAAAEACgAFMAbgBhAGcASQB0ACAAOAAgAFAAcgBpAG4AdABlAHIAAABJbnB1dEJpbgBNQU5VQUwAUkVTRExMAFVuaXJlc0RMTABPcmllbnRhdGlvbgBQT1JUUkFJVABQYXBlclNpemUATEVUVEVSAFJlc29sdXRpb24AT3B0aW9uMwBDb2xvck1vZGUAMjRicHAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=";

        private static Stream GetBinaryDataStream(string base64String)
        {
            return new MemoryStream(Convert.FromBase64String(base64String));
        }

        #endregion
        #endregion
    }

    public class ReportType
    {
       public string ReportName { get; set; }
       public int ReportId { get; set; }
    }
}