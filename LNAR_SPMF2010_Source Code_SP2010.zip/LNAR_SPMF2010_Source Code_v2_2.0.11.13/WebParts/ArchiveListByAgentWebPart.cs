﻿using System;
using System.Threading;
using System.Web.UI.WebControls.WebParts;
using DeutscheBank.SharePoint.DSpace.Diagnostics;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebParts
{
    /// <summary>
    /// A webpart support archive list by agent
    /// </summary>
    public class ArchiveListByAgentWebPart : WebPart
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (Page.Request.RequestType != "POST" ||
                !SecurityHelper.DoesUserHavePermissionLevel(SPContext.Current.Web, FrameworkConstants.ArchiveRoleDefinition))
            {
                Page.Response.Clear();
                Page.Response.StatusCode = 401;
                Page.Response.End();
            }
            else
            {
                Archive();
            }
        }

        private void Archive()
        {
            var webId = SPContext.Current.Web.ID;
            var siteId = SPContext.Current.Site.ID;
            var archiveByCondition = string.Empty;
            var rawUrl = string.Empty;
            var sourceListID = Guid.Empty;
            var targetListID = Guid.Empty;

            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        var sourceListName = Page.Request.QueryString["SourceList"];
                        var targetListName = Page.Request.QueryString["TargetList"];
                        var archiveByField = Page.Request.QueryString["ArchiveByField"];
                        var archiveByFieldValue = Page.Request.QueryString["ArchiveByFieldValue"];
                        archiveByCondition = Page.Request.QueryString["ArchiveByCondition"];

                        var sourceList = web.Lists[sourceListName];
                        var targetList = web.Lists.TryGetList(targetListName);
                        
                        if (targetList == null)
                        {
                            var targetListId = ArchiveHelper.CreateArchiveList(web, sourceList.ID, targetListName);
                            targetList = web.Lists[targetListId];
                        }

                        sourceListID = sourceList.ID;
                        targetListID = targetList.ID;

                        rawUrl = SPContext.Current.Site.MakeFullUrl(targetList.DefaultViewUrl);

                        if (string.IsNullOrEmpty(archiveByCondition))
                        {
                            var field = sourceList.Fields[archiveByField];

                            archiveByCondition = string.Format(field.Type == SPFieldType.DateTime ? 
                                "<Lt><FieldRef Name='{0}' /><Value IncludeTimeValue='FALSE' Type='DateTime'>{1}</Value></Lt>" : 
                                "<Eq><FieldRef Name='{0}' /><Value Type='Text'><![CDATA[{1}]]></Value></Eq>", field.InternalName, archiveByFieldValue);
                        }
                    }
                }
            });

            try
            {
                using (var operation = new SPLongOperation(Page))
                {
                    operation.LeadingHTML = LocalizationHelper.GetString("ArchiveListWebPart_MS010");
                    operation.Begin();
                    ArchiveHelper.Archive(SPContext.Current.Web, sourceListID, targetListID, archiveByCondition);
                    operation.End(rawUrl);
                }
            }
            catch (Exception ex)
            {
                Trace.LogException(FrameworkConstants.FrameworkTraceId, ex);
            }
        }
    }
}
