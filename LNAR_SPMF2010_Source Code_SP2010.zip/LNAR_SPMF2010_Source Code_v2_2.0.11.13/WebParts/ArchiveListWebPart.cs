﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using DeutscheBank.SharePoint.DSpace.Diagnostics;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using DeutscheBank.SharePoint.LNAR.Framework.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using System.Linq;
using System.Text;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebParts
{
    public class ArchiveListWebPart : WebPart, IValidator
    {
        private DateTimeControl dateSelector;
        private PropertySheetSection dateSelectorSection;
        private DropDownList ddlTargetLists;
        private ValidatorControl validatorControlForTargetLists;
        private PropertySheet propertySheet;
        private PropertySheetSection sourceListSection;
        private PropertySheetSection targetListSection;
        private TextBox txtArchiveList;
        private ValidatorControl validatorControlForArchiveList;
        private Button btnArchive;
        private FormDigest formDigest;
        private RadioButton rbtArchiveToExistList;
        private RadioButton rbtArchiveToNewList;
        private DropDownList ddlFields;
        private ValidatorControl validatorControlForFields;
        private TextBox txtValue;
        private ValidatorControl validatorControlForValue;
        private RadioButton rbtArchiveByCreatedDate;
        private RadioButton rbtArchiveByOtherField;
        private DateTimeControl dateSelectorValue;
        private string archiveByField;
        private object archiveByValue;
        private bool? isRestoreMode;
        private bool? isItemsMode;
        
        #region Privates

        private SPList list;

        #endregion

        private bool IsRestoreMode
        {
            get
            {
                if (isRestoreMode.HasValue)
                {
                    return isRestoreMode.Value;
                }

                var isRestore = Page.Request.QueryString["IsRestore"];
                isRestoreMode = !string.IsNullOrEmpty(isRestore) && isRestore.Equals("True", StringComparison.InvariantCultureIgnoreCase);
                return isRestoreMode.Value;
            }
        }

        private bool IsItemsMode
        {
            get
            {
                if (isItemsMode.HasValue)
                {
                    return isItemsMode.Value;
                }

                isItemsMode = !string.IsNullOrEmpty(Page.Request.QueryString["Items"]);
                return isItemsMode.Value;
            }
        }

        public override PartChromeType ChromeType
        {
            get { return PartChromeType.None; }
            set { base.ChromeType = value; }
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            var control = Page.Master.FindControl("PlaceHolderPageTitle");
            if (control != null)
            {
                control.Controls.Add(IsRestoreMode
                                         ? new LiteralControl(LocalizationHelper.GetString("ArchiveListWebPart_MS027"))
                                         : new LiteralControl(LocalizationHelper.GetString("ArchiveListWebPart_MS009")));
            }

            propertySheet = new PropertySheet();
            Controls.Add(propertySheet);

            #region Archive from list

            sourceListSection = new PropertySheetSection { Header = IsRestoreMode ? LocalizationHelper.GetString("ArchiveListWebPart_MS019") : LocalizationHelper.GetString("ArchiveListWebPart_MS002") };
            sourceListSection.SectionRender += sourceListSection_SectionRender;
            propertySheet.AddSection(sourceListSection);

            #endregion

            #region Archive condition

            if (!IsItemsMode)
            {
                dateSelectorSection = new PropertySheetSection
                {
                    Header = IsRestoreMode ? LocalizationHelper.GetString("ArchiveListWebPart_MS020") : LocalizationHelper.GetString("ArchiveListWebPart_MS014"),
                    Description = IsRestoreMode ? LocalizationHelper.GetString("ArchiveListWebPart_MS021") : LocalizationHelper.GetString("ArchiveListWebPart_MS015")
                };
                dateSelectorSection.SectionRender += dateSelectorSection_SectionRender;
                propertySheet.AddSection(dateSelectorSection);

                rbtArchiveByCreatedDate = new RadioButton { GroupName = "Archive By", Checked = true };
                Controls.Add(rbtArchiveByCreatedDate);

                dateSelector = new DateTimeControl
                {
                    ID = "dateSelector",
                    DateOnly = true,
                    OnValueChangeClientScript = string.Format("document.getElementById('{0}').checked = true;", rbtArchiveByCreatedDate.ClientID),
                    DatePickerFrameUrl = string.Format("{0}/_layouts/iframe.aspx", SPContext.Current.Web.Url)
                };
                Controls.Add(dateSelector);

                rbtArchiveByOtherField = new RadioButton { GroupName = "Archive By" };
                Controls.Add(rbtArchiveByOtherField);

                ddlFields = new DropDownList { AutoPostBack = true };
                ddlFields.Attributes.Add("onclick", string.Format("document.getElementById('{0}').checked = true;", rbtArchiveByOtherField.ClientID));
                Controls.Add(ddlFields);

                validatorControlForFields = new ValidatorControl();

                txtValue = new TextBox { CssClass = "ms-input", Columns = 40, MaxLength = 255 };
                Controls.Add(txtValue);

                validatorControlForValue = new ValidatorControl();

                dateSelectorValue = new DateTimeControl
                {
                    DateOnly = true,
                    DatePickerFrameUrl = string.Format("{0}/_layouts/iframe.aspx", SPContext.Current.Web.Url)
                };
                Controls.Add(dateSelectorValue);
            }

            #endregion

            #region Archive to list

            targetListSection = new PropertySheetSection { Header = IsRestoreMode ? LocalizationHelper.GetString("ArchiveListWebPart_MS024") : LocalizationHelper.GetString("ArchiveListWebPart_MS006") };
            targetListSection.SectionRender += targetListSection_SectionRender;
            propertySheet.AddSection(targetListSection);

            if (!IsRestoreMode)
            {
                rbtArchiveToExistList = new RadioButton
                {
                    GroupName = "Target List",
                    Checked = true
                };
                Controls.Add(rbtArchiveToExistList);

                rbtArchiveToNewList = new RadioButton
                {
                    GroupName = "Target List"
                };
                Controls.Add(rbtArchiveToNewList);

                ddlTargetLists = new DropDownList { ID = "ddlTargetLists" };
                ddlTargetLists.Attributes.Add("onclick", string.Format("document.getElementById('{0}').checked = true;", rbtArchiveToExistList.ClientID));
                Controls.Add(ddlTargetLists);

                validatorControlForTargetLists = new ValidatorControl();

                txtArchiveList = new TextBox
                {
                    ID = "txtArchiveList",
                    CssClass = "ms-input",
                    MaxLength = 255,
                    Columns = 40
                };
                txtArchiveList.Attributes.Add("onclick", string.Format("document.getElementById('{0}').checked = true;", rbtArchiveToNewList.ClientID));
                Controls.Add(txtArchiveList);

                validatorControlForArchiveList = new ValidatorControl();
            }

            #endregion

            btnArchive = new Button { ID = "btnArchive", Text = IsRestoreMode ? LocalizationHelper.GetString("ArchiveListWebPart_MS025") : LocalizationHelper.GetString("ArchiveListWebPart_MS001") };
            btnArchive.Style.Add(HtmlTextWriterStyle.MarginRight, "100px");
            btnArchive.Click += btnArchive_Click;
            propertySheet.AddButton(btnArchive);

            formDigest = new FormDigest();
            Controls.Add(formDigest);
        }

        private void btnArchive_Click(object sender, EventArgs e)
        {
            Validate();

            if (!IsValid)
            {
                return;
            }

            Guid targetListId;

            if (IsRestoreMode)
            {
                targetListId = ArchiveHelper.GetParentOfArchiveList(SPContext.Current.Web, list.ID);
            }
            else
            {
                if (rbtArchiveToExistList.Checked)
                {
                    targetListId = new Guid(ddlTargetLists.SelectedValue);
                }
                else
                {
                    // Create new archive list
                    try
                    {
                        targetListId = ArchiveHelper.CreateArchiveList(SPContext.Current.Web, list.ID,
                                                                           txtArchiveList.Text.Trim());
                    }
                    catch (Exception ex)
                    {
                        validatorControlForArchiveList.IsValid = false;
                        validatorControlForArchiveList.ErrorMessage = ex.Message;
                        return;
                    }
                }
            }

            var targetArchiveList = Utils.SafeGetList(SPContext.Current.Web, targetListId);
            var rawUrl = SPContext.Current.Site.MakeFullUrl(targetArchiveList.DefaultViewUrl);

            try
            {
                using (var operation = new SPLongOperation(Page))
                {
                    operation.LeadingHTML = IsRestoreMode ? LocalizationHelper.GetString("ArchiveListWebPart_MS026") : LocalizationHelper.GetString("ArchiveListWebPart_MS010");
                    operation.Begin();

                    if (IsItemsMode)
                    {
                        ArchiveHelper.Archive(SPContext.Current.Web, list.ID, targetListId, BuildItemsQuery());
                    }
                    else
                    {
                        if (IsRestoreMode)
                        {
                            ArchiveHelper.Restore(SPContext.Current.Web, list.ID, targetListId, archiveByField,
                                                  archiveByValue);
                        }
                        else
                        {
                            ArchiveHelper.Archive(SPContext.Current.Web, list.ID, targetListId, archiveByField,
                                                  archiveByValue);
                        }
                    }
                    operation.End(rawUrl);
                }
            }          
            catch (Exception ex)
            {
                SPUtility.TransferToErrorPage(ex.ToString());
            }
        }

        private string BuildItemsQuery()
        {
            var items = Page.Request.QueryString["Items"].Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            var flag = false;
            var builder = new StringBuilder();

            foreach (var item in items)
            {
                if (flag)
                {
                    builder.Insert(0, "<Or>");
                }

                builder.AppendFormat("<Eq><FieldRef Name='ID' /><Value Type='Counter'>{0}</Value></Eq>", item);

                if (flag)
                {
                    builder.Append("</Or>");
                }

                flag = true;
            }

            builder.Insert(0, "<Where>");
            builder.Append("</Where>");

            return builder.ToString();
        }

        protected override void OnLoad(EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                // Check security
                if (!SecurityHelper.DoesUserHavePermissionLevel(SPContext.Current.Web, FrameworkConstants.ArchiveRoleDefinition))
                {
                    SPUtility.HandleAccessDenied(null);
                }
            }

            base.OnLoad(e);
            try
            {
                var listId = new Guid(Page.Request.QueryString["ListId"]);
                list = SPContext.Current.Web.Lists[listId];
            }
            catch (Exception)
            {
                SPUtility.TransferToErrorPage(LocalizationHelper.GetString("ArchiveListWebPart_MS011"));
            }

            if (!Page.IsPostBack)
            {
                if (IsRestoreMode)
                {
                    var parentListId = ArchiveHelper.GetParentOfArchiveList(SPContext.Current.Web, list.ID);
                    if (parentListId == Guid.Empty)
                    {
                        SPUtility.TransferToErrorPage(LocalizationHelper.GetString("ArchiveListWebPart_MS028"));
                    }
                }

                EnsureChildControls();

                // Bind data for Drop Down List
                if (!IsRestoreMode)
                {
                    BindDataForTargetList();
                }
                if (!IsItemsMode)
                    BindDataForFields();
            }

            var ribbon = SPRibbon.GetCurrent(Page);
            if (ribbon != null)
            {
                ribbon.TrimById("Ribbon.Read");
                ribbon.TrimById("Ribbon.WebPartPage");
            }
        }

        private void BindDataForFields()
        {
            var fields = new List<SPField>();
            foreach (var field in
                list.Fields.Cast<SPField>().Where(field => (!field.Hidden && !field.ReadOnlyField) && field.Group != "_Hidden"))
            {
                switch (field.Type)
                {
                    case SPFieldType.Text:
                    case SPFieldType.DateTime:
                    case SPFieldType.Choice:
                        fields.Add(field);
                        break;
                }
            }

            fields.Add(list.Fields.GetFieldByInternalName("Modified"));

            ddlFields.Items.Clear();
            foreach (var field in fields.OrderBy(f => f.Title))
            {
                ddlFields.Items.Add(new ListItem(field.Title, field.InternalName));
            }
        }

        private void BindDataForTargetList()
        {
            ddlTargetLists.Items.Clear();

            var web = SPContext.Current.Web;

            var guids = ArchiveHelper.GetArchiveLists(web, list.ID);
            if (guids != null && guids.Length > 0)
            {
                var lists = new List<SPList>();
                foreach (var guid in guids)
                {
                    try
                    {
                        lists.Add(web.Lists[guid]);
                    }
                    catch (SPException)
                    {
                        Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, string.Format("The list with guid is {0} no longer exist ", guid));
                    }
                }

                foreach (var listItem in
                    lists.OrderBy(item => item.Title).Select(item => new ListItem(item.Title, item.ID.ToString())))
                {
                    ddlTargetLists.Items.Add(listItem);
                }
            }
        }

        private void sourceListSection_SectionRender(HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Span);
            writer.RenderBeginTag(HtmlTextWriterTag.Strong);
            writer.Write(list.Title);
            writer.RenderEndTag();
            writer.RenderEndTag();
        }

        private void dateSelectorSection_SectionRender(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            // Row #1
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.RenderBeginTag(HtmlTextWriterTag.Span);
            writer.Write(IsRestoreMode
                             ? LocalizationHelper.GetString("ArchiveListWebPart_MS022")
                             : LocalizationHelper.GetString("ArchiveListWebPart_MS016"));

            writer.RenderEndTag(); // span
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            // Row #2
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(
                "<img width=\"1\" height=\"3\" style=\"display: block;\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            // Row #3
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "11");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(
                "<img width=\"11\" height=\"1\" style=\"display: block;\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
            writer.RenderEndTag(); // td

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "99%");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddStyleAttribute(HtmlTextWriterStyle.VerticalAlign, "top");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            rbtArchiveByCreatedDate.RenderControl(writer);
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            dateSelector.RenderControl(writer);
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr
            writer.RenderEndTag(); // table

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("&nbsp;");
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            // Row #1
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
            writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.RenderBeginTag(HtmlTextWriterTag.Span);
            writer.Write(IsRestoreMode
                             ? LocalizationHelper.GetString("ArchiveListWebPart_MS023")
                             : LocalizationHelper.GetString("ArchiveListWebPart_MS017"));
            writer.RenderEndTag(); // span
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            // Row #2
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"1\" height=\"3\" style=\"display: block;\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            // Row #3
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "11");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("<img width=\"11\" height=\"1\" style=\"display: block;\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
            writer.RenderEndTag(); // td

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "99%");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddStyleAttribute(HtmlTextWriterStyle.VerticalAlign, "top");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            rbtArchiveByOtherField.RenderControl(writer);
            validatorControlForFields.RenderControl(writer);
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.RenderBeginTag(HtmlTextWriterTag.Span);
            ddlFields.RenderControl(writer);
            writer.RenderEndTag(); // span
            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("&nbsp;");
            writer.RenderEndTag(); // td

            writer.AddAttribute(HtmlTextWriterAttribute.Width, "99%");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
            writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingTop, "5px");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            var field = list.Fields.GetFieldByInternalName(ddlFields.SelectedValue);
            if (field.Type == SPFieldType.DateTime)
            {
                dateSelectorValue.RenderControl(writer);
            }
            else
            {
                txtValue.RenderControl(writer);
                validatorControlForValue.RenderControl(writer);
            }

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            writer.RenderEndTag(); // table

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr

            writer.RenderEndTag(); // table
        }

        private void targetListSection_SectionRender(HtmlTextWriter writer)
        {
            if (IsRestoreMode)
            {
                var parentListId = ArchiveHelper.GetParentOfArchiveList(SPContext.Current.Web, list.ID);
                var parentList = SPContext.Current.Web.Lists[parentListId];

                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.RenderBeginTag(HtmlTextWriterTag.Strong);
                writer.Write(parentList.Title);
                writer.RenderEndTag();
                writer.RenderEndTag();
            }
            else
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
                writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
                writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
                writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
                writer.RenderBeginTag(HtmlTextWriterTag.Table);

                // Row #
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
                writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write(LocalizationHelper.GetString("ArchiveListWebPart_MS007"));
                writer.RenderEndTag(); // span
                writer.RenderEndTag(); // td

                writer.RenderEndTag(); // tr

                // Row #2
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.Write(
                    "<img width=\"1\" height=\"3\" style=\"display: block;\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
                writer.RenderEndTag(); // td
                writer.RenderEndTag(); // tr

                // Row #3
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.AddAttribute(HtmlTextWriterAttribute.Width, "11");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.Write(
                    "<img width=\"11\" height=\"1\" style=\"display: block;\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
                writer.RenderEndTag(); // td

                writer.AddAttribute(HtmlTextWriterAttribute.Width, "99%");
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);

                writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
                writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
                writer.RenderBeginTag(HtmlTextWriterTag.Table);
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.AddStyleAttribute(HtmlTextWriterStyle.VerticalAlign, "top");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                rbtArchiveToExistList.RenderControl(writer);
                writer.RenderEndTag(); //td

                writer.RenderBeginTag(HtmlTextWriterTag.Td);

                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                ddlTargetLists.RenderControl(writer);
                writer.RenderEndTag(); // span
                validatorControlForTargetLists.RenderControl(writer);

                writer.RenderEndTag(); // td

                writer.RenderEndTag();
                writer.RenderEndTag(); // table

                writer.RenderEndTag(); // td

                writer.RenderEndTag(); // tr

                var archiveOption = ArchiveHelper.GetArchiveListOption(list) ?? new ArchiveListOption();
                if (archiveOption.AllowCreateNewArchiveList)
                {
                    #region Add New List

                    writer.RenderBeginTag(HtmlTextWriterTag.Tr);
                    writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    writer.Write("&nbsp;");
                    writer.RenderEndTag(); // td
                    writer.RenderEndTag(); // tr

                    writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
                    writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    writer.Write(string.Format("<span>{0}</span>", LocalizationHelper.GetString("ArchiveListWebPart_MS008")));
                    writer.RenderEndTag(); // td

                    writer.RenderEndTag(); // tr

                    writer.RenderBeginTag(HtmlTextWriterTag.Tr);
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    writer.Write("<img width=\"1\" height=\"3\" style=\"display: block;\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
                    writer.RenderEndTag(); // td
                    writer.RenderEndTag(); // tr

                    writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                    writer.AddAttribute(HtmlTextWriterAttribute.Width, "11px");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    writer.Write("<img width=\"11\" height=\"1\" style=\"display: block;\" alt=\"\" src=\"/_layouts/images/blank.gif\" complete=\"complete\"/>");
                    writer.RenderEndTag(); // td

                    writer.AddAttribute(HtmlTextWriterAttribute.Width, "99%");
                    writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-authoringcontrols");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);

                    writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
                    writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
                    writer.RenderBeginTag(HtmlTextWriterTag.Table);
                    writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                    writer.AddStyleAttribute(HtmlTextWriterStyle.VerticalAlign, "top");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    rbtArchiveToNewList.RenderControl(writer);
                    writer.RenderEndTag(); // td

                    writer.RenderBeginTag(HtmlTextWriterTag.Td);

                    writer.RenderBeginTag(HtmlTextWriterTag.Span);
                    txtArchiveList.RenderControl(writer);
                    writer.RenderEndTag(); // span
                    validatorControlForArchiveList.RenderControl(writer);

                    writer.RenderEndTag(); // td

                    writer.RenderEndTag(); // tr
                    writer.RenderEndTag(); // table

                    writer.RenderEndTag(); // td

                    writer.RenderEndTag(); // tr  

                    #endregion    
                }

                writer.RenderEndTag(); // table
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            var placeHolderAdditionalPageHead = Page.Master.FindControl("PlaceHolderAdditionalPageHead");
            if (placeHolderAdditionalPageHead != null)
            {
                placeHolderAdditionalPageHead.Controls.Add(new CssRegistration { Name = "layouts.css" });
            }

            Page.ClientScript.RegisterStartupScript(GetType(), "Remove WBBody css class",
                                                    "$(document).ready(function(){$('.ms-WPBody').removeClass('ms-WPBody');});",
                                                    true);

            CssRegistration.Register("datepickerv4.css", true);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            propertySheet.RenderControl(writer);

            formDigest.RenderControl(writer);
        }

        public string ErrorMessage { get; set; }

        public bool IsValid { get; set; }

        public void Validate()
        {
            IsValid = true;
            if (!IsItemsMode)
            {
                #region Archive condition
                if (rbtArchiveByCreatedDate.Checked)
                {
                    if (!dateSelector.IsValid)
                    {
                        IsValid = false;
                    }

                    if (dateSelector.IsDateEmpty)
                    {
                        IsValid = false;
                        dateSelector.IsValid = false;
                        dateSelector.ErrorMessage = LocalizationHelper.GetString("ArchiveListWebPart_MS018");
                    }

                    archiveByField = "Created";
                    archiveByValue = dateSelector.SelectedDate;
                }

                if (rbtArchiveByOtherField.Checked)
                {
                    if (ddlFields.SelectedIndex < 0)
                    {
                        IsValid = false;
                        validatorControlForFields.IsValid = false;
                        validatorControlForFields.ErrorMessage = LocalizationHelper.GetString("ArchiveListWebPart_MS018");
                    }
                    else
                    {
                        var field = list.Fields.GetFieldByInternalName(ddlFields.SelectedValue);
                        if (field.Type == SPFieldType.DateTime)
                        {
                            if (!dateSelectorValue.IsValid)
                            {
                                IsValid = false;
                            }
                            else
                            {
                                if (dateSelectorValue.IsDateEmpty)
                                {
                                    IsValid = false;
                                    dateSelectorValue.IsValid = false;
                                    dateSelectorValue.ErrorMessage = LocalizationHelper.GetString("ArchiveListWebPart_MS018");
                                }
                            }

                            archiveByValue = dateSelectorValue.SelectedDate;
                        }
                        else
                        {
                            if (string.IsNullOrEmpty(txtValue.Text.Trim()))
                            {
                                IsValid = false;
                                validatorControlForValue.IsValid = false;
                                validatorControlForValue.ErrorMessage = LocalizationHelper.GetString("ArchiveListWebPart_MS018");
                            }

                            archiveByValue = txtValue.Text.Trim();
                        }

                        archiveByField = ddlFields.SelectedValue;
                    }
                }
                #endregion
            }


            if (!IsRestoreMode)
            {
                if (rbtArchiveToExistList.Checked && ddlTargetLists.SelectedIndex < 0)
                {
                    IsValid = false;
                    validatorControlForTargetLists.IsValid = false;
                    validatorControlForTargetLists.ErrorMessage = LocalizationHelper.GetString("ArchiveListWebPart_MS012");
                }

                if (rbtArchiveToNewList.Checked && string.IsNullOrEmpty(txtArchiveList.Text.Trim()))
                {
                    IsValid = false;
                    validatorControlForArchiveList.IsValid = false;
                    validatorControlForArchiveList.ErrorMessage = LocalizationHelper.GetString("ArchiveListWebPart_MS013");
                }
            }
        }
    }
}