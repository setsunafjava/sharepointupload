﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebParts
{
    public class ArchiveEditWebPart : WebPart
    {
        public override PartChromeType ChromeType
        {
            get { return PartChromeType.None; }
            set { base.ChromeType = value; }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            var ribbon = SPRibbon.GetCurrent(Page);
            if (ribbon != null)
            {
                ribbon.Visible = false;
            }
        }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "500px");
            writer.AddStyleAttribute(HtmlTextWriterStyle.MarginLeft, "auto");
            writer.AddStyleAttribute(HtmlTextWriterStyle.MarginRight, "auto");
            writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingTop, "100px");
            writer.AddStyleAttribute(HtmlTextWriterStyle.PaddingBottom, "100px");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            writer.RenderBeginTag(HtmlTextWriterTag.Center);

            switch (SPContext.Current.FormContext.FormMode)
            {
                case SPControlMode.New:
                    writer.Write(LocalizationHelper.GetString("ArchiveEditWebPart_MS001"));
                    break;
                case SPControlMode.Edit:
                    writer.Write(LocalizationHelper.GetString("ArchiveEditWebPart_MS002"));
                    break;
                default:
                    writer.Write(LocalizationHelper.GetString("ArchiveEditWebPart_MS003"));
                    break;
            }
            
            writer.RenderEndTag(); // center
            writer.RenderEndTag(); // div
        }
    }
}