﻿using System;
using System.Linq;
using System.Web.UI.WebControls.WebParts;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebParts
{
    public class PrintPreviewWebPart : WebPart
    {
        public override PartChromeType ChromeType
        {
            get { return PartChromeType.None; }
            set { base.ChromeType = value; }
        }

        protected override void OnLoad(EventArgs e)
        {
            var web = SPContext.Current.Web;

            // Template path
            
            var itemsQueryString = Page.Request.QueryString["Items"];
            if (string.IsNullOrEmpty(itemsQueryString))
            {
                return;
            }

            var split = itemsQueryString.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            var items = (from item in split
                         select item.Split(new[] {":"}, StringSplitOptions.None)
                         into subSplit let list = web.Lists[new Guid(subSplit[0].TrimStart('['))] 
                         select list.GetItemById(Convert.ToInt32(subSplit[1].TrimEnd(']')))).ToList();

            string html;

            var templatePath = Page.Request.QueryString["TemplatePath"];
            if (!string.IsNullOrEmpty(templatePath))
            {
                html = PrintPreviewHelper.Printer(SPContext.Current.Web, items, templatePath);    
                goto Write;
            }

            var templateList = Page.Request.QueryString["TemplateList"];
            if (!string.IsNullOrEmpty(templateList))
            {
                var templateName = Page.Request.QueryString["TemplateName"];
                if (string.IsNullOrEmpty(templateName))
                {
                    throw new ArgumentException();
                }

                var templateContentFieldName = Page.Request.QueryString["TemplateContentFieldName"];
                if (string.IsNullOrEmpty(templateContentFieldName))
                {
                    throw new ArgumentException();
                }

                var list = web.Lists[templateList];
                var query = new SPQuery
                                {
                                    Query = string.Format("<Where><Eq><FieldRef Name='Title'/><Value Type='Text'>{0}</Value></Eq></Where>", templateName),
                                    QueryThrottleMode = SPQueryThrottleOption.Override
                                };
                var listItems = list.GetItems(query);
                if (listItems.Count == 0)
                {
                    throw new ArgumentException(string.Format(LocalizationHelper.GetString("PrintPreviewWebPart_MS001"), templateName));
                }

                var htmlTemplate = Convert.ToString(listItems[0][templateContentFieldName]);

                html = PrintPreviewHelper.Printer(items, htmlTemplate);
                goto Write;
            }
            
            // Using default template
            html = PrintPreviewHelper.Printer(items);

            Write:
            // Write to response stream and flush to client browser
            Page.Response.Clear();
            Page.Response.ContentType = "text/html";
            Page.Response.BufferOutput = true;
            Page.Response.Write(html);
            Page.Response.End();
        }
    }
}