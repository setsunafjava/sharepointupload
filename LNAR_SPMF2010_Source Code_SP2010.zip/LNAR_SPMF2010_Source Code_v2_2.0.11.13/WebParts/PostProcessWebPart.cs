﻿using System;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using DeutscheBank.SharePoint.LNAR.Framework.Citus;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebParts
{
    public class PostProcessWebPart : WebPart, IValidator
    {
        #region Delegates

        public delegate void AsyncMethodCaller(Guid siteId, Guid webId);

        #endregion

        private readonly Button btnPostProcess = new Button();
        private readonly FileUpload fCitusConfiguration = new FileUpload();
        private readonly FileUpload fMappingFile = new FileUpload();
        private readonly Label lblStatus = new Label();
        private string configName = "";
        private string mappingName = "";
        private readonly CheckBox chkReset = new CheckBox();

        public override PartChromeType ChromeType
        {
            get { return PartChromeType.None; }
            set { base.ChromeType = value; }
        }

        #region IValidator Members

        public string ErrorMessage { get; set; }

        public bool IsValid { get; set; }

        public void Validate()
        {
            IsValid = true;
        }

        #endregion

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            Control control = Page.Master.FindControl("PlaceHolderPageTitle");
            if (control != null)
            {
                control.Controls.Add(new LiteralControl("Citus Post Processing"));
            }

            Controls.Add(lblStatus);
            Controls.Add(fCitusConfiguration);
            Controls.Add(fMappingFile);
            chkReset.Text = "Reset Post-process";
            Controls.Add(chkReset);
            Controls.Add(btnPostProcess);

            btnPostProcess.Text = "Post process";
            btnPostProcess.Style.Add(HtmlTextWriterStyle.MarginRight, "100px");
            btnPostProcess.Click += btnPostProcess_Click;
        }

        protected override void Render(HtmlTextWriter writer)
        {

            writer.AddAttribute(HtmlTextWriterAttribute.Id, "loadpage");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "5");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            // Tr 0
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "30%");
            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.RenderEndTag(); // td
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            lblStatus.RenderControl(writer);
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            // Tr 1
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "30%");
            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("Citus Configuration File (.xml) ");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Color, "red");
            writer.RenderBeginTag(HtmlTextWriterTag.Span);
            writer.Write("*");
            writer.RenderEndTag(); // span
            writer.RenderEndTag(); // td
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            fCitusConfiguration.RenderControl(writer);
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            // Tr 2
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "30");
            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write("Application Mapping File (.xlsx)");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Color, "red");
            writer.RenderBeginTag(HtmlTextWriterTag.Span);
            writer.Write("*");
            writer.RenderEndTag(); // span
            writer.RenderEndTag(); // td
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            fMappingFile.RenderControl(writer);
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            // Tr 3
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "30%");
            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.RenderEndTag(); // td
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            chkReset.RenderControl(writer);
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr


            // Tr 4
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "30%");
            writer.AddStyleAttribute(HtmlTextWriterStyle.WhiteSpace, "nowrap");

            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.RenderEndTag(); // td
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            btnPostProcess.RenderControl(writer);
            writer.RenderEndTag(); // td
            writer.RenderEndTag(); // tr

            writer.RenderEndTag(); // table
            writer.RenderEndTag();
        }

        private void btnPostProcess_Click(object sender, EventArgs e)
        {
            IsValid = true;
            if (string.IsNullOrEmpty(fCitusConfiguration.FileName) || string.IsNullOrEmpty(fMappingFile.FileName))
            {
                lblStatus.Text = "You must specify a value for the required field.";
                return;
            }

            SPWeb spweb = SPContext.Current.Web;

            SPList docLib = spweb.Lists["DeutscheBankSharePointLNARCitus"];


            Stream fStreamCitus = fCitusConfiguration.PostedFile.InputStream;
            try
            {
                var contents = new byte[fStreamCitus.Length];
                fStreamCitus.Read(contents, 0, (int)fStreamCitus.Length);
                docLib.RootFolder.Files.Add(docLib.RootFolder.Url + "/" + fCitusConfiguration.FileName, contents, true);
                docLib.Update();
                configName = fCitusConfiguration.FileName;
            }
            catch (Exception ex)
            {
                DSpace.Diagnostics.Trace.LogException(Common.FrameworkConstants.FrameworkTraceId, ex.InnerException);
                IsValid = false;
            }
            finally
            {
                if (fStreamCitus != null) fStreamCitus.Close();
            }


            Stream fStreamMapping = fMappingFile.PostedFile.InputStream;
            try
            {
                var contents = new byte[fStreamMapping.Length];
                fStreamMapping.Read(contents, 0, (int)fStreamMapping.Length);
                docLib.RootFolder.Files.Add(docLib.RootFolder.Url + "/" + fMappingFile.FileName, contents, true);
                docLib.Update();
                mappingName = fMappingFile.FileName;
            }
            catch (Exception ex)
            {
                DSpace.Diagnostics.Trace.LogException(Common.FrameworkConstants.FrameworkTraceId, ex.InnerException);
                IsValid = false;
            }
            finally
            {
                if (fStreamMapping != null) fStreamMapping.Close();
            }


            if (!IsValid) return;

            Page.ClientScript.RegisterClientScriptBlock(typeof(string), "Post-process",
                                                                                        "<script type='text/javascript'> var auto_refresh = setInterval('window.location.href= window.location.href;', 30000);</script>");

            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(SPContext.Current.Site.ID))
                {
                    using (SPWeb web = site.OpenWeb(SPContext.Current.Web.ID))
                    {
                        SPList statusList =
                            web.Lists["DeutscheBankSharePointLNARAsyncStatus"];
                        if (statusList.ItemCount == 0)
                        {
                            var caller = new AsyncMethodCaller(AsyncMethod);

                            // Initiate the asychronous call
                            caller.BeginInvoke(SPContext.Current.Site.ID,
                                               SPContext.Current.Web.ID, null,
                                               null);

                            lblStatus.Text = "The Post-process is executing!";
                            // Disable button
                            btnPostProcess.Enabled = false;
                        }
                    }
                }
            });
        }

        public void AsyncMethod(Guid siteId, Guid webId)
        {
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (SPWeb web = site.OpenWeb(webId))
                    {
                        SPList statusList =
                            web.Lists["DeutscheBankSharePointLNARAsyncStatus"];

                        SPListItem statusItem = statusList.AddItem();
                        statusItem["Title"] = "The Post-process is executing!";
                        statusItem.Update();

                        //Run Post process
                        SPList list =
                           web.Lists["DeutscheBankSharePointLNARCitusHistory"];

                        SPListItem item = list.AddItem();

                        var process = new PostProcess();
                        bool status = process.RunPostProcess(site, web, configName,
                                               mappingName, chkReset.Checked);
                        if (status)
                            item["Title"] = "Last post process successfully at " + DateTime.Now.ToString();
                        else
                        {
                            item["Title"] = "Last post process fail at " + DateTime.Now.ToString();
                        }
                        item.Update();

                        // Remove status item when completed
                        statusItem.Delete();
                        configName = "";
                        mappingName = "";
                    }
                }
            });
        }

        protected override void OnLoad(EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                // Check security
                if (!SecurityHelper.DoesUserHavePermissionLevel(SPContext.Current.Web, "CitusPostProcess"))
                {
                    SPUtility.HandleAccessDenied(null);
                }
            }
            base.OnLoad(e);
            if (!Page.IsPostBack)
            {
                EnsureChildControls();


                SPSecurity.RunWithElevatedPrivileges(() =>
                {
                    using (var site = new SPSite(SPContext.Current.Site.ID))
                    {
                        using (
                            SPWeb web = site.OpenWeb(SPContext.Current.Web.ID))
                        {
                            SPList list =
                                web.Lists[
                                    "DeutscheBankSharePointLNARAsyncStatus"];
                            if (list.ItemCount == 0)
                            {
                                lblStatus.Text = "";
                                btnPostProcess.Enabled = true;
                                fCitusConfiguration.Enabled = true;
                                fMappingFile.Enabled = true;
                                chkReset.Enabled = true;

                                list =
                                    web.Lists[
                                        "DeutscheBankSharePointLNARCitusHistory"
                                        ];
                                if (list.ItemCount > 0)
                                {
                                    SPListItem item =
                                        list.Items[list.ItemCount - 1];
                                    lblStatus.Text = item.Title;
                                }


                            }
                            else
                            {
                                SPListItem item = list.Items[0];
                                lblStatus.Text = item.Title;
                                btnPostProcess.Enabled = false;
                                fCitusConfiguration.Enabled = false;
                                fMappingFile.Enabled = false;
                                chkReset.Enabled = false;
                                Page.ClientScript.RegisterClientScriptBlock(typeof(string), "Post-process",
                                   "<script type='text/javascript'> var auto_refresh = setInterval('window.location.href= window.location.href;', 30000);</script>");
                            }
                        }
                    }
                });

            }
            SPRibbon ribbon = SPRibbon.GetCurrent(Page);
            if (ribbon != null)
            {
                ribbon.TrimById("Ribbon.Read");
                ribbon.TrimById("Ribbon.WebPartPage");
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            Control placeHolderAdditionalPageHead = Page.Master.FindControl("PlaceHolderAdditionalPageHead");
            if (placeHolderAdditionalPageHead != null)
            {
                placeHolderAdditionalPageHead.Controls.Add(new CssRegistration { Name = "layouts.css" });
            }

            Page.ClientScript.RegisterStartupScript(GetType(), "Remove WBBody css class",
                                                    "$(document).ready(function(){$('.ms-WPBody').removeClass('ms-WPBody');});",
                                                    true);

        }

    }
}