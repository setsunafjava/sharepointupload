﻿using System;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.Helpers;
using DeutscheBank.SharePoint.LNAR.Framework.WebControls;
using Microsoft.SharePoint.WebControls;
using BoundField = DeutscheBank.SharePoint.LNAR.Framework.WebControls.BoundField;
using DataGrid = DeutscheBank.SharePoint.LNAR.Framework.WebControls.DataGrid;

namespace DeutscheBank.SharePoint.LNAR.Framework.WebParts
{
    public class DialogListWebPart : WebPart
    {
        private bool? allowFillInValue;
        private bool? allowMultipleValues;
        private StringCollection choices;
        private bool? combineDataSources;
        private bool? enableQuickSearch;
        private bool? lookupWithHighPermission;
        private bool? multiLine;
        private DataGrid dataGrid;
        
        public override PartChromeType ChromeType
        {
            get { return PartChromeType.None; }
            set { base.ChromeType = value; }
        }

        public StringCollection Choices
        {
            get
            {
                if (choices == null)
                {
                    choices = new StringCollection();
                    var value = Page.Request.QueryString["Choices"];
                    if (!string.IsNullOrEmpty(value))
                    {
                        var split = value.Split(new[] {";#"}, StringSplitOptions.None);
                        choices.AddRange(split);
                    }
                }
                return choices;
            }
        }

        public bool AllowMultipleValues
        {
            get
            {
                if (!allowMultipleValues.HasValue)
                {
                    var value = Page.Request.QueryString["AllowMultipleValues"];
                    allowMultipleValues = !string.IsNullOrEmpty(value) && Convert.ToBoolean(value);
                }
                return allowMultipleValues.Value;
            }
        }

        public bool LookupWithHighPermission
        {
            get
            {
                if (!lookupWithHighPermission.HasValue)
                {
                    var value = Page.Request.QueryString["LookupWithHighPermission"];
                    lookupWithHighPermission = !string.IsNullOrEmpty(value) && Convert.ToBoolean(value);
                }
                return lookupWithHighPermission.Value;
            }
        }

        public bool AllowFillInValue
        {
            get
            {
                if (!allowFillInValue.HasValue)
                {
                    var value = Page.Request.QueryString["AllowFillInValue"];
                    allowFillInValue = !string.IsNullOrEmpty(value) && Convert.ToBoolean(value);
                }
                return allowFillInValue.Value;
            }
        }

        public bool EnableQuickSearch
        {
            get
            {
                if (!enableQuickSearch.HasValue)
                {
                    var value = Page.Request.QueryString["EnableQuickSearch"];
                    enableQuickSearch = !string.IsNullOrEmpty(value) && Convert.ToBoolean(value);
                }
                return enableQuickSearch.Value;
            }
        }

        public string Value
        {
            get { return Page.Request.QueryString["Value"]; }
        }

        public string LookupList
        {
            get { return Page.Request.QueryString["LookupList"]; }
        }

        public string LookupField
        {
            get { return Page.Request.QueryString["LookupField"]; }
        }

        public string WhereCondition
        {
            get { return Page.Request.QueryString["WhereCondition"]; }
        }

        public string SeparateCharacter
        {
            get { return Page.Request.QueryString["SeparateCharacter"]; }
        }

        public bool CombineDataSources
        {
            get
            {
                if (!combineDataSources.HasValue)
                {
                    var value = Page.Request.QueryString["CombineDataSources"];
                    combineDataSources = !string.IsNullOrEmpty(value) && Convert.ToBoolean(value);
                }
                return combineDataSources.Value;
            }
        }

        public bool MultiLine
        {
            get
            {
                if (!multiLine.HasValue)
                {
                    var value = Page.Request.QueryString["MultiLine"];
                    multiLine = !string.IsNullOrEmpty(value) && Convert.ToBoolean(value);
                }
                return multiLine.Value;
            }
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            var dataGridString = Page.Request.QueryString["DataGrid"];
            if (string.IsNullOrEmpty(dataGridString))
            {
                dataGrid = new DataGrid
                               {
                                   Choices = string.Join(";#", Choices.Cast<string>().ToArray()),
                                   LookupList = LookupList,
                                   WhereCondition = WhereCondition,
                                   DataTextField = LookupField,
                                   RemoveDuplicateRows = true,
                                   LookupWithHighPermission = LookupWithHighPermission,
                                   SeparateCharacter = SeparateCharacter
                               };
                dataGrid.Columns.Add(MultiLine
                                         ? new MultiValueBoundField {Name = LookupField}
                                         : new BoundField {Name = LookupField});
            }
            else
            {
                var builder = new StringBuilder();
                builder.AppendFormat(@"<%@ Register TagPrefix=""fw"" Namespace=""DeutscheBank.SharePoint.LNAR.Framework.WebControls"" Assembly=""{0}"" %>", typeof(DialogListWebPart).Assembly.FullName);
                builder.Append(dataGridString);
                var control = Page.ParseControl(builder.ToString());
                dataGrid = control.Controls.OfType<DataGrid>().First();
            }
            dataGrid.Selectable = true;
            dataGrid.AllowMultipleValues = AllowMultipleValues;
            dataGrid.Width = new Unit(100, UnitType.Percentage);

            if (!string.IsNullOrEmpty(Value))
            {
                dataGrid.SetSelectedValues(Value);
            }
            
            Controls.Add(dataGrid);
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            var script = new StringBuilder();
            script.Append("var dataGrid;");
            script.Append("$(document).ready(function(){");
            script.AppendFormat("dataGrid = new DataGrid('{0}');", dataGrid.ClientID);
            script.Append("});");

            script.Append("function dfCloseModalDialog(){");
            
            script.Append("var items = dataGrid.getSelectedValues();");
            if (AllowFillInValue)
            {
                if (AllowMultipleValues)
                {
                    script.AppendFormat("var value = jQuery.trim($('#{0}').val());", ClientID + "_Keyword");
                    script.Append("if(value != ''){items.push(value);}");    
                }
                else
                {
                    script.Append("if(items.length == 0){");
                    script.AppendFormat("var value = jQuery.trim($('#{0}').val());", ClientID + "_Keyword");
                    script.Append("if(value != ''){items.push(value);}");    
                    script.Append("}");
                }
            }

            script.Append("SP.UI.ModalDialog.commonModalDialogClose(SP.UI.DialogResult.OK, items.join(';#'));");

            script.Append("}"); // end function

            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "DialogListWebPart", script.ToString(), true);

            // Register Quick Search
            if (EnableQuickSearch)
            {
                var scriptControl = new HtmlGenericControl("script");
                scriptControl.Attributes.Add("type", "text/javascript");
                scriptControl.InnerHtml =
                    string.Format("$(document).ready(function(){{$.getScript('{1}', function(){{$('#txtQuickSearch').quicksearch('table#{0} tbody tr');}});}});", dataGrid.ClientID,
                        Page.ClientScript.GetWebResourceUrl(GetType(), FrameworkConstants.WebResources.Scripts.DialogQuickSearch));
                Page.Header.Controls.Add(scriptControl);
            }
        }

        protected override void Render(HtmlTextWriter writer)
        {
            #region Table

            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            #region Quick Search

            if (EnableQuickSearch)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                RenderLiveSearch(writer);
                writer.RenderEndTag(); // td

                writer.RenderEndTag(); // tr
            }

            #endregion

            #region Tr

            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            #region Td #1

            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-input");
            writer.AddStyleAttribute(HtmlTextWriterStyle.VerticalAlign, "top");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.Write(string.Format("<span style=\"display: block; margin-bottom: 5px;\">{0}</span>", LocalizationHelper.GetString("DialogListWebPart_MS002")));

            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "400px");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Height, "250px");
            writer.AddStyleAttribute(HtmlTextWriterStyle.BorderStyle, "solid");
            writer.AddStyleAttribute(HtmlTextWriterStyle.BorderWidth, "1px");
            writer.AddStyleAttribute(HtmlTextWriterStyle.BorderColor, "#C2C2C2");
            writer.AddStyleAttribute(HtmlTextWriterStyle.OverflowY, "scroll");
            writer.AddStyleAttribute(HtmlTextWriterStyle.OverflowX, "auto");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            
            dataGrid.RenderControl(writer);
            
            writer.RenderEndTag(); // div
            
            writer.RenderEndTag(); // td

            #endregion

            #region Td #2

            writer.AddStyleAttribute(HtmlTextWriterStyle.VerticalAlign, "top");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "100px");
            writer.AddStyleAttribute(HtmlTextWriterStyle.TextAlign, "right");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            // Render OK button
            writer.AddAttribute(HtmlTextWriterAttribute.Type, "button");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-ButtonHeightWidth");
            writer.AddAttribute(HtmlTextWriterAttribute.Style, "width: 80px; margin-top: 22px; font: 8pt Tahoma; height: 2.1em;");
            writer.AddAttribute("onclick", "dfCloseModalDialog();");
            writer.RenderBeginTag(HtmlTextWriterTag.Button);
            writer.Write("OK");
            writer.RenderEndTag(); // button

            // Render Cancel button
            writer.AddAttribute(HtmlTextWriterAttribute.Type, "button");
            writer.AddAttribute(HtmlTextWriterAttribute.Class, "ms-ButtonHeightWidth");
            writer.AddAttribute(HtmlTextWriterAttribute.Style, "width: 80px; margin-top: 5px; font: 8pt Tahoma; height: 2.1em;");
            writer.AddAttribute("onclick", "SP.UI.ModalDialog.commonModalDialogClose(SP.UI.DialogResult.cancel, null);");
            writer.RenderBeginTag(HtmlTextWriterTag.Button);
            writer.Write("Cancel");
            writer.RenderEndTag(); // button

            writer.RenderEndTag(); // td

            #endregion

            writer.RenderEndTag(); // tr

            #endregion

            if (AllowFillInValue)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.RenderBeginTag(HtmlTextWriterTag.Td);

                writer.AddStyleAttribute(HtmlTextWriterStyle.MarginTop, "10px");
                writer.AddStyleAttribute(HtmlTextWriterStyle.Display, "block");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write(LocalizationHelper.GetString("DialogListWebPart_MS003"));
                writer.RenderEndTag();

                // Render textbox
                writer.AddAttribute(HtmlTextWriterAttribute.Type, "text");
                writer.AddAttribute(HtmlTextWriterAttribute.Maxlength, "255");
                writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "400px");
                writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID + "_Keyword");
                
                if (!AllowMultipleValues)
                {
                    writer.AddAttribute("onfocus", "dataGrid.clearSelectedValues();");    
                }

                if (!dataGrid.ValueSelected)
                {
                    writer.AddAttribute(HtmlTextWriterAttribute.Value, Value);
                }

                writer.RenderBeginTag(HtmlTextWriterTag.Input);
                writer.RenderEndTag(); // input
                
                writer.RenderEndTag(); // td

                // Empty td
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                writer.Write("&nbsp;");
                writer.RenderEndTag(); // td

                writer.RenderEndTag(); // tr
            }

            writer.RenderEndTag(); // table

            #endregion
        }

        private static void RenderLiveSearch(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "100px");
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(LocalizationHelper.GetString("DialogListWebPart_MS001"));
            writer.RenderEndTag(); // td

            writer.RenderBeginTag(HtmlTextWriterTag.Td);

            writer.AddAttribute(HtmlTextWriterAttribute.Id, "txtQuickSearch");
            writer.AddAttribute(HtmlTextWriterAttribute.Maxlength, "255");
            writer.AddAttribute(HtmlTextWriterAttribute.Type, "text");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "295px");
            writer.RenderBeginTag(HtmlTextWriterTag.Input);
            writer.RenderEndTag(); // input

            writer.RenderEndTag(); // td

            writer.RenderEndTag(); // tr
            writer.RenderEndTag(); // table
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            var ribbon = SPRibbon.GetCurrent(Page);
            if (ribbon != null)
            {
                ribbon.CommandUIVisible = false;
            }
        }
    }
}