﻿using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Xml;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Configuration
{
    public static class ConfigurationManager
    {
        private const string KeyPrefix = "DeutscheBank.SharePoint.LNAR.Framework.Configuration_";

        private static string MakeFullKey(string key)
        {
            return KeyPrefix + key.GetHashCode();
        }

        public static bool ContainsKeyInPropertyBag(string key)
        {
            return ContainsKeyInPropertyBag(SPContext.Current.Web, key);
        }

        public static bool ContainsKeyInPropertyBag(SPWeb web, string key)
        {
            return web.Properties.ContainsKey(MakeFullKey(key));
        }

        public static bool ContainsKeyInPropertyBag(SPSite site, string key)
        {
            return site.RootWeb.Properties.ContainsKey(MakeFullKey(key));
        }

        public static TValue GetFromPropertyBag<TValue>(string key)
        {
            return GetFromPropertyBag<TValue>(SPContext.Current.Web, key);
        }

        public static TValue GetFromPropertyBag<TValue>(SPWeb web, string key)
        {
            var obj = GetFromPropertyBag(web, key);
            return DeserializeObject<TValue>(obj);
        }

        public static TValue GetFromPropertyBag<TValue>(SPSite site, string key)
        {
            var obj = GetFromPropertyBag(site, key);
            return DeserializeObject<TValue>(obj);
        }

        private static TValue DeserializeObject<TValue>(object obj)
        {
            if (obj == null)
            {
                return default(TValue);
            }

            try
            {
                var ms = new MemoryStream(Encoding.UTF8.GetBytes(obj.ToString()));
                var xmlReader = new XmlTextReader(ms);
                var xmlSerializer = XmlSerializerCache.GetSerializer(typeof (TValue));
                return (TValue) xmlSerializer.Deserialize(xmlReader);
            }
            catch
            {
                return default(TValue);
            }
        }

        private static object GetFromPropertyBag(SPWeb web, string key)
        {
            return web.Properties[MakeFullKey(key)];
        }

        private static object GetFromPropertyBag(SPSite site, string key)
        {
            return site.RootWeb.Properties[MakeFullKey(key)];
        }

        public static void RemoveKeyFromPropertyBag(string key)
        {
            RemoveKeyFromPropertyBag(SPContext.Current.Web, key);
        }

        public static void RemoveKeyFromPropertyBag(SPWeb web, string key)
        {
            if (ContainsKeyInPropertyBag(web, key))
            {
                web.Properties.Remove(MakeFullKey(key));
                web.Properties.Update();
            }
        }

        public static void RemoveKeyFromPropertyBag(SPSite site, string key)
        {
            RemoveKeyFromPropertyBag(site.RootWeb, key);
        }

        public static void SetInPropertyBag(string key, object value)
        {
            SetInPropertyBag(SPContext.Current.Web, key, value);
        }

        public static void SetInPropertyBag(SPWeb web, string key, object value)
        {
            if (value == null)
            {
                throw new NullReferenceException();
            }

            web.Properties[MakeFullKey(key)] = SerializeObject(value);
            web.Properties.Update();
        }

        public static void SetInPropertyBag(SPSite site, string key, object value)
        {
            SetInPropertyBag(site.RootWeb, key, value);
        }

        private static string SerializeObject(object value)
        {
            var ms = new MemoryStream();
            var xmlWriter = new XmlTextWriter(ms, Encoding.UTF8);
            var xmlSerializer = XmlSerializerCache.GetSerializer(value.GetType());
            xmlSerializer.Serialize(xmlWriter, value);
            return Encoding.UTF8.GetString(ms.GetBuffer());
        }

        #region Configuration Section

        /*private static readonly Hashtable sections = new Hashtable(StringComparer.InvariantCultureIgnoreCase);

        public static T GetSection<T>(string sectionName) where T : ConfigurationSection
        {
            return GetSection<T>(SPContext.Current.Web, sectionName);
        }

        public static T GetSection<T>(SPWeb web, string sectionName) where T : ConfigurationSection
        {
            if (sections.Contains(sectionName))
            {
                return (T) sections[sectionName];
            }

            var fileContent = web.GetFileAsString("framework.config.xml");
            var document = new XmlDocument();
            document.LoadXml(fileContent);

            var elements = document.GetElementsByTagName(sectionName);
            var obj = (T) Activator.CreateInstance(typeof (T), (XmlElement) elements[0]);
            sections.Add(sectionName, obj);
            return obj;
        }*/

        #endregion
    }
}