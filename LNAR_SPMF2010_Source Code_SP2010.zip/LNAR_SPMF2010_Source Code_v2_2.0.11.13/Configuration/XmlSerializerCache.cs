using System;
using System.Xml.Serialization;

namespace DeutscheBank.SharePoint.LNAR.Framework.Configuration
{
    /// <summary>
    ///   A cache for xml serializers.  Improves performance by caching serialization classes.
    /// </summary>
    internal static class XmlSerializerCache
    {
        /// <summary>
        ///   Caches the XmlSerializer instance for a specific type.
        /// </summary>
        private static readonly XmlSerializerFactory SerializerFactory = new XmlSerializerFactory();

        internal static XmlSerializer GetSerializer(Type type)
        {
            return SerializerFactory.CreateSerializer(type) ?? new XmlSerializer(type);
        }
    }
}