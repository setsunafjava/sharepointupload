﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public class TemplateHelper
    {
        /// <summary>
        /// Transform to html
        /// </summary>
        /// <param name="htmlTemplate"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string TransformHtml(string htmlTemplate, IDictionary<string, string> data)
        {
            var builder = new StringBuilder(htmlTemplate);
            foreach (var pair in data)
            {
                builder.Replace(string.Format("[{0}]", pair.Key), pair.Value);
            }
            return builder.ToString();
        }

        /// <summary>
        /// Transform <see cref="SPListItem"/> into html
        /// </summary>
        /// <param name="item"></param>
        /// <param name="htmlTemplate"></param>
        /// <returns></returns>
        public static string TransformHtml(SPListItem item, string htmlTemplate)
        {
            var data = new Dictionary<string, string>();

            // Change to English culture
            var oldCulture = Thread.CurrentThread.CurrentUICulture.LCID;
            var flag = false;
            if (oldCulture != 1033)
            {
                flag = true;
                Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(1033);
            }

            var fields = GetFields(item);

            foreach (var field in fields)
            {
                try
                {
                    var value = item[field.Title];
                    var valueString = Convert.ToString(value);
                    switch (field.Type)
                    {
                        case SPFieldType.Note:
                            var fieldMultiLineText = (SPFieldMultiLineText) field;
                            data.Add(field.Title, fieldMultiLineText.RichText ? valueString : SPEncode.HtmlEncode(valueString));
                            break;
                        case SPFieldType.Boolean:
                            data.Add(field.Title, Convert.ToBoolean(value) ? "Yes" : "No");
                            break;
                        case SPFieldType.Choice:
                        case SPFieldType.MultiChoice:
                            data.Add(field.Title, SPEncode.HtmlEncode(string.Join("; ", valueString.Split(new[] { ";#" }, StringSplitOptions.RemoveEmptyEntries).ToArray())));
                            break;
                        case SPFieldType.User:
                        case SPFieldType.Lookup:
                            data.Add(field.Title, SPEncode.HtmlEncode(string.Join("; ", valueString.Split(new[] { ";#" }, StringSplitOptions.RemoveEmptyEntries).Where((v, i) => i % 2 != 0).ToArray())));
                            break;
                        case SPFieldType.Calculated:
                            var values = valueString.Split(new [] {";#"}, StringSplitOptions.None);
                            data.Add(field.Title, SPEncode.HtmlEncode(string.Join("", values, 1, values.Length - 1)));
                            break;
                        default:
                            data.Add(field.Title, SPEncode.HtmlEncode(valueString));
                            break;
                    }
                    
                }
                catch(ArgumentException)
                {
                    // When the field doesn't exists.
                    data.Add(field.Title, SPEncode.HtmlEncode("This field doesn't exists"));
                }
            }

            if (flag)
            {
                Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(oldCulture);
            }

            return TransformHtml(htmlTemplate, data);
        }

        internal static IList<SPField> GetFields(SPListItem item)
        {
            const string fieldGroup = "_Hidden";
            var list = item.ParentList;

            var fields =
                list.Fields.Cast<SPField>().Where(field =>
                                                  !field.Hidden && (!field.ReadOnlyField || field is SPFieldCalculated) &&
                                                  field.Group != fieldGroup && !(field is SPFieldAttachments)).ToList();

            // Created By
            fields.Add(list.Fields.GetFieldByInternalName("Author"));

            // Modified By
            fields.Add(list.Fields.GetFieldByInternalName("Editor"));

            // Created
            fields.Add(list.Fields.GetFieldByInternalName("Created"));

            // Modified
            fields.Add(list.Fields.GetFieldByInternalName("Modified"));

            return fields;
        }

        /// <summary>
        /// Extract html body content from html
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public static string ExtractHtmlBody(string html)
        {
            const RegexOptions options = RegexOptions.IgnoreCase | RegexOptions.Singleline;
            var regex = new Regex("<body>(?<BodyContent>.*)</body>", options);
            var match = regex.Match(html);
            return match.Success ? match.Groups["BodyContent"].Value : html;
        }

        /// <summary>
        /// Extract html head content from html
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public static string ExtractHtmlHead(string html)
        {
            const RegexOptions options = RegexOptions.IgnoreCase | RegexOptions.Singleline;
            var regex = new Regex("<head>(?<HeadContent>.*)</head>", options);
            var match = regex.Match(html);
            return match.Success ? match.Groups["HeadContent"].Value : string.Empty;
        }

        /// <summary>
        /// Extract html title content from html
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public static string ExtractHtmlTitle(string html)
        {
            const RegexOptions options = RegexOptions.IgnoreCase | RegexOptions.Singleline;
            var regex = new Regex("<title>(?<TitleContent>.*)</title>", options);
            var match = regex.Match(html);
            return match.Success ? match.Groups["TitleContent"].Value : string.Empty;
        }

        /// <summary>
        /// Get Html template from file store in SharePoint folder
        /// </summary>
        /// <param name="web">The current web</param>
        /// <param name="path">Relative path to file</param>
        /// <returns>Return html template string</returns>
        /// <exception cref="ArgumentException">The path doesn't exists in SharePoint folder</exception>
        public static string GetTemplateFromFile(SPWeb web, string path)
        {
            try
            {
                return web.GetFileAsString(path);
            }
            catch (Exception)
            {
                throw new ArgumentException("The path doesn't exists in SharePoint folder");
            }
        }

        public static string BuildDefaultTemplate(SPListItem item)
        {
            var builder = new StringBuilder();
            builder.Append("<html>");

            builder.Append("<head>");
            builder.Append("<title>Print Preview</title>");

            builder.Append("<style type=\"text/css\">");
            builder.Append(".table{font-family: tahoma;font-size:12px;background: #f8f8f9;border:solid 1px #e8eaec;border-collapse:collapse;empty-cells:show;width:100%}");
            builder.Append(".label{padding: 5px 15px 5px 7px;color: #616a76;font-weight: bold;border-bottom:solid 1px #e8eaec;border-right:solid 1px #e8eaec;width:30%;}");
            builder.Append(".body{padding: 5px 7px 5px 7px;color: #000000;text-align:left;border-bottom:solid 1px #e8eaec;}");
            builder.Append("</style>");

            builder.Append("</head>");

            builder.Append("<body>");

            var fields = GetFields(item);

            builder.Append("<table class=\"table\">");

            // Change to English culture
            var oldCulture = Thread.CurrentThread.CurrentUICulture.LCID;
            var flag = false;
            if (oldCulture != 1033)
            {
                flag = true;
                Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(1033);
            }

            foreach (var field in fields)
            {
                builder.Append("<tr>");

                builder.AppendFormat("<td class=\"label\">{0}</td>", field.Title);
                builder.AppendFormat("<td class=\"body\">[{0}]</td>", field.Title);

                builder.Append("</tr>");
            }

            if (flag)
            {
                Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(oldCulture);
            }

            builder.Append("</table>");

            builder.Append("</body>");
            builder.Append("</html>");

            return builder.ToString();
        }
    }
}