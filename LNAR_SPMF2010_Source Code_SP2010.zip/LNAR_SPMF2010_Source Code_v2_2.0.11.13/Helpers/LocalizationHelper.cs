﻿using System.Reflection;
using System.Resources;
using System.Threading;
using System.Web;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    internal static class LocalizationHelper
    {
        private static ResourceManager manager;

        private static ResourceManager Manager
        {
            get
            {
                if (manager == null)
                {
                    var assembly =
                        Assembly.Load(
                            "DeutscheBank.SharePoint.LNAR.Framework.intl, Version=2.0.0.0, Culture=neutral, PublicKeyToken=3f1921ddc5421e3a");
                    manager = new ResourceManager("DeutscheBank.SharePoint.LNAR.Framework", assembly);
                }
                return manager;
            }
        }

        public static string GetString(string key)
        {
            return Manager.GetString(key);
        }
        
        public static string GetString(string resource, string key)
        {
            return HttpContext.GetGlobalResourceObject(resource, key) as string;
        }

        public static string GetStringFromCoreResource(string key)
        {
            return SPUtility.GetLocalizedString("$Resources: " + key, "core",
                                                (uint) Thread.CurrentThread.CurrentUICulture.LCID);
        }
    }
}