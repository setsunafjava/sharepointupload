﻿using System;
using System.Collections.Specialized;
using System.Linq;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using DeutscheBank.SharePoint.LNAR.Framework.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public static class ArchiveHelper
    {
        public static void Archive(SPWeb currentWeb, Guid listId, Guid archiveListId, string  archiveByField, object archiveByValue)
        {
            if (archiveByValue is DateTime)
            {
                var iso8601DateTime = SPUtility.CreateISO8601DateTimeFromSystemDateTime((DateTime) archiveByValue);
                var whereCondition =
                    string.Format("<Lt><FieldRef Name='{0}' /><Value IncludeTimeValue='FALSE' Type='DateTime'>{1}</Value></Lt>", archiveByField, iso8601DateTime);
                Archive(currentWeb, listId, archiveListId, whereCondition);
            }
            else
            {
                var whereCondition = string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Text'><![CDATA[{1}]]></Value></Eq>", archiveByField, archiveByValue);
                Archive(currentWeb, listId, archiveListId, whereCondition);
            }
        }

        public static void Restore(SPWeb currentWeb, Guid archiveListId, Guid listId, string restoreByField, object restoreByValue)
        {
            if (restoreByValue is DateTime)
            {
                var iso8601DateTime = SPUtility.CreateISO8601DateTimeFromSystemDateTime((DateTime)restoreByValue);
                var whereCondition =
                    string.Format("<Gt><FieldRef Name='{0}' /><Value IncludeTimeValue='FALSE' Type='DateTime'>{1}</Value></Gt>", restoreByField, iso8601DateTime);
                Archive(currentWeb, archiveListId, listId, whereCondition);
            }
            else
            {
                var whereCondition = string.Format("<Eq><FieldRef Name='{0}' /><Value Type='Text'><![CDATA[{1}]]></Value></Eq>", restoreByField, restoreByValue);
                Archive(currentWeb, archiveListId, listId, whereCondition);
            }
        }

        public static void Archive(SPWeb currentWeb, Guid listId, Guid archiveListId, string whereCondition)
        {
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(currentWeb.Site.ID))
                {
                    using (var web = site.OpenWeb(currentWeb.ID))
                    {
                        var list = web.Lists[listId];
                        var archiveList = web.Lists[archiveListId];

                        var allowUnsafeUpdates = SecurityHelper.SetAllowUnsafeUpdates(web);

                        var copier = GetCopier(list);

                        if (string.IsNullOrEmpty(whereCondition))
                        {
                            whereCondition = "<Where></Where>";
                        }
                        else if (!whereCondition.StartsWith("<Where>", StringComparison.InvariantCultureIgnoreCase))
                        {
                            // Ensure caml begin with <Where>
                            whereCondition = string.Format("<Where>{0}</Where>", whereCondition);
                        }

                        var query = new SPQuery
                        {
                            Query = whereCondition,
                            QueryThrottleMode = SPQueryThrottleOption.Override,
                            RowLimit = 1000,
                        };

                        if (list.BaseTemplate == SPListTemplateType.GenericList)
                        {
                            query.ViewAttributes = "Scope='Recursive'";
                        }

                        SPListItemCollection items;
                        do
                        {
                            items = list.GetItems(query);
                            if (items ==null || items.Count>0) break;
                            copier.CopyItems(web, list, archiveList, items);
                            query.ListItemCollectionPosition = items.ListItemCollectionPosition;
                        } 
                        while (items.ListItemCollectionPosition != null);

                        SecurityHelper.RollbackAllowUnsafeUpdates(web, allowUnsafeUpdates);
                    }
                }
            });
        }

        private static ListItemCopier GetCopier(SPList list)
        {
            switch (list.BaseTemplate)
            {
                case SPListTemplateType.DiscussionBoard:
                    return new DiscussionBoardCopier();
                default:
                    return new ListItemCopier();
            }
        }

        public static void CreateArchiveWebPage(SPWeb web)
        {
            WebPageHelper.CreateDefaultWebPage(web, "ArchiveList.aspx", true);
            WebPartHelper.AddWebPart(web, "ArchiveList.aspx", new ArchiveListWebPart {Title = "ArchiveListWebPart"}, "Main", 0);

            // Create "Archive role definition"
            SecurityHelper.CreatePermissionLevel(web, FrameworkConstants.ArchiveRoleDefinition, "Can archive list items.", SPBasePermissions.ViewListItems | SPBasePermissions.ViewPages | SPBasePermissions.Open);
        }

        public static void CreateArchiveWebPage(SPWeb web, bool supportAgent)
        {
            CreateArchiveWebPage(web);

            if (supportAgent)
            {
                WebPageHelper.CreateDefaultWebPage(web, "ArchiveListByAgent.aspx", true);
                WebPartHelper.AddWebPart(web, "ArchiveListByAgent.aspx", new ArchiveListByAgentWebPart { Title = "ArchiveListByAgentWebPart" }, "Main", 0);    
            }
        }

        public static Guid CreateArchiveList(SPWeb web1, Guid listId, string name)
        {
            var archiveListId = Guid.Empty;

            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(web1.Site.ID))
                {
                    using (var web = site.OpenWeb(web1.ID))
                    {
                        var allowUnsafeUpdates = SecurityHelper.SetAllowUnsafeUpdates(web);

                        var list = web.Lists[listId];
                        var templateId = Guid.NewGuid().ToString("N");
                        list.SaveAsTemplate(templateId + ".stp", templateId, string.Empty, false);

                        var templates = web.Site.GetCustomListTemplates(web);
                        var template = templates[templateId];

                        archiveListId = web.Lists.Add(name, string.Empty, template);
                        LinkArchiveLists(web, listId, archiveListId);

                        var archiveList = web.Lists[archiveListId];

                        var archiveOption = GetArchiveListOption(list) ?? new ArchiveListOption();

                        if (archiveList.BaseTemplate == SPListTemplateType.GenericList)
                        {
                            var views = (from view in archiveList.Views.Cast<SPView>() select view.ID).ToList();
                            foreach (var view in views)
                            {
                                archiveList.Views.Delete(view);
                            }

                            // Create default view
                            SPView defaultView;
                            try
                            {
                                defaultView = archiveList.Views.Add("AllItems", archiveOption.ViewFields,
                                                      "<Where></Where><OrderBy><FieldRef Name='ID' Ascending='FALSE' /></OrderBy>",
                                                      100, true, true,
                                                      SPViewCollection.SPViewType.Html, false);
                            }
                            catch
                            {
                                // When column not exist
                                defaultView = archiveList.Views.Add("AllItems", new StringCollection { "LinkTitleNoMenu" },
                                                      "<Where></Where><OrderBy><FieldRef Name='ID' Ascending='FALSE' /></OrderBy>",
                                                      100, true, true,
                                                      SPViewCollection.SPViewType.Html, false);
                            }
                            defaultView.Title = "All Items";
                            defaultView.Update();    
                        }

                        switch (archiveOption.NewFormOption)
                        {
                            case ArchiveFormMode.ShowDeniedMessage:
                                WebPartHelper.HideDefaultWebPartOnNewPage(web, archiveList);
                                WebPartHelper.AddWebPartToNewPage(web, archiveList, new ArchiveEditWebPart { Title = "ArchiveEditWebPart" });
                                break;
                            case ArchiveFormMode.ShowStandardForm:
                                WebPartHelper.ShowDefaultWebPartOnNewPage(web, archiveList);
                                break;
                            case ArchiveFormMode.ShowCustomForm:
                                var containerWebPart = new ContainerWebPart
                                                           {
                                                               Title = "ContainerWebPart",
                                                               UserControlPath = archiveOption.NewFormUserControlPath
                                                           };
                                WebPartHelper.AddWebPartToNewPage(web, archiveList, containerWebPart);
                                break;
                            default:
                                throw new ArgumentOutOfRangeException();
                        }

                        switch (archiveOption.DisplayFormOption)
                        {
                            case ArchiveFormMode.ShowDeniedMessage:
                                WebPartHelper.HideDefaultWebPartOnDisplayPage(web, archiveList);
                                WebPartHelper.AddWebPartToDisplayPage(web, archiveList, new ArchiveEditWebPart { Title = "ArchiveEditWebPart" });
                                break;
                            case ArchiveFormMode.ShowStandardForm:
                                WebPartHelper.ShowDefaultWebPartOnDisplayPage(web, archiveList);
                                break;
                            case ArchiveFormMode.ShowCustomForm:
                                var containerWebPart = new ContainerWebPart
                                {
                                    Title = "ContainerWebPart",
                                    UserControlPath = archiveOption.DisplayFormUserControlPath
                                };
                                WebPartHelper.AddWebPartToDisplayPage(web, archiveList, containerWebPart);
                                break;
                            default:
                                throw new ArgumentOutOfRangeException();
                        }

                        switch (archiveOption.EditFormOption)
                        {
                            case ArchiveFormMode.ShowDeniedMessage:
                                WebPartHelper.HideDefaultWebPartOnEditPage(web, archiveList);
                                WebPartHelper.AddWebPartToEditPage(web, archiveList, new ArchiveEditWebPart { Title = "ArchiveEditWebPart" });
                                break;
                            case ArchiveFormMode.ShowStandardForm:
                                WebPartHelper.ShowDefaultWebPartOnEditPage(web, archiveList);
                                break;
                            case ArchiveFormMode.ShowCustomForm:
                                var containerWebPart = new ContainerWebPart
                                {
                                    Title = "ContainerWebPart",
                                    UserControlPath = archiveOption.EditFormUserControlPath
                                };
                                WebPartHelper.AddWebPartToEditPage(web, archiveList, containerWebPart);
                                break;
                            default:
                                throw new ArgumentOutOfRangeException();
                        }

                        // Restore default form
                        //WebPartHelper.ShowDefaultWebPartOnDisplayPage(web, archiveList);
                        //WebPartHelper.ReplaceWebPartForArchiveList(web, archiveList);

                        // check this has break permission from parent web
                        if (list.HasUniqueRoleAssignments)
                        {
                            var roleAssignmentCol = list.RoleAssignments;

                            archiveList.BreakRoleInheritance(false);
                            foreach (SPRoleAssignment spRoleAssignment in roleAssignmentCol)
                            {
                                archiveList.RoleAssignments.Add(spRoleAssignment);
                            }
                        }

                        // Remove template
                        var allowUnsafeUpdates2 = SecurityHelper.SetAllowUnsafeUpdates(web.Site.RootWeb);
                        var listTemplate = (SPDocumentLibrary) web.Site.RootWeb.Lists["List Template Gallery"];
                        var file = listTemplate.RootFolder.Files[templateId + ".stp"];
                        file.Delete();
                        SecurityHelper.RollbackAllowUnsafeUpdates(web.Site.RootWeb, allowUnsafeUpdates2);

                        // Add restore button
                        if (archiveOption.ShowRestoreButton)
                        {
                            ListHelper.ShowRestoreButton(web, archiveList);    
                        }
                       
                        // Add restore items button
                        if (archiveOption.ShowRestoreItemsButton)
                        {
                            ListHelper.ShowRestoreItemsButton(web, archiveList);
                        }

                        SecurityHelper.RollbackAllowUnsafeUpdates(web, allowUnsafeUpdates);
                    }
                }
            });

            return archiveListId;
        }

        internal static void LinkArchiveLists(SPWeb web, Guid sourceListId, Guid targetListId)
        {
            var archiveKey = GetArchiveKeyForList(sourceListId);
            
            if (web.Properties.ContainsKey(archiveKey))
            {
                var values = Convert.ToString(web.Properties[archiveKey]).Split(new[] { ";#" }, StringSplitOptions.RemoveEmptyEntries).ToList();
                values.Add(targetListId.ToString());
                web.Properties[archiveKey] = string.Join(";#", values.ToArray());
            }
            else
            {
                web.Properties.Add(archiveKey, targetListId.ToString());
            }
            web.Properties.Update();
        }

        public static Guid[] GetArchiveLists(SPWeb web, Guid listId)
        {
            var archiveKey = GetArchiveKeyForList(listId);
            if (web.Properties.ContainsKey(archiveKey))
            {
                var value = web.Properties[archiveKey];
                return Convert.ToString(value).Split(new [] {";#"}, StringSplitOptions.RemoveEmptyEntries)
                    .Select(item => new Guid(item)).ToArray();
            }
            return null;
        }

        /// <summary>
        /// Get parent of archive list
        /// </summary>
        /// <param name="web"></param>
        /// <param name="listId"></param>
        /// <returns></returns>
        public static Guid GetParentOfArchiveList(SPWeb web, Guid listId)
        {
            foreach (var key in web.Properties.Keys)
            {
                if (key.ToString().StartsWith("8780537A9ECD11DFAE861441DFD72085-", StringComparison.InvariantCultureIgnoreCase))
                {
                    var value = web.Properties[key.ToString()];
                    var ids = value.Split(new [] {";#"}, StringSplitOptions.RemoveEmptyEntries).Select(id => new Guid(id)).ToList();
                    if (ids.Contains(listId))
                    {
                        return new Guid(key.ToString().ToUpperInvariant().Replace("8780537A9ECD11DFAE861441DFD72085-", ""));
                    }
                }
            }
            return Guid.Empty;
        }

        private static string GetArchiveKeyForList(Guid listId)
        {
            const string archiveKeyPrefix = "8780537A9ECD11DFAE861441DFD72085-";
            return string.Concat(archiveKeyPrefix, listId.ToString("N").ToUpperInvariant());
        }

        /// <summary>
        /// Save archive list option
        /// </summary>
        /// <param name="list"></param>
        /// <param name="option"></param>
        public static void SaveArchiveOption(SPList list, ArchiveListOption option)
        {
            if (option.NewFormOption == ArchiveFormMode.ShowCustomForm && string.IsNullOrEmpty(option.NewFormUserControlPath))
            {
                throw new ArgumentException("NewFormUserControlPath is required when NewFormOption is ShowCustomForm.");
            }

            if (option.DisplayFormOption == ArchiveFormMode.ShowCustomForm && string.IsNullOrEmpty(option.DisplayFormUserControlPath))
            {
                throw new ArgumentException("DisplayFormUserControlPath is required when DisplayFormOption is ShowCustomForm.");
            }

            if (option.EditFormOption == ArchiveFormMode.ShowCustomForm && string.IsNullOrEmpty(option.EditFormUserControlPath))
            {
                throw new ArgumentException("EditFormUserControlPath is required when EditFormOption is ShowCustomForm.");
            }

            var key = GetArchiveOptionKeyForList(list.ID);
            var value = Utils.SerializeBase64(option);

            var web = list.ParentWeb;

            if (web.Properties.ContainsKey(key))
            {
                web.Properties[key] = value;
            }
            else
            {
                web.Properties.Add(key, value);
            }
            web.Properties.Update();
        }

        public static ArchiveListOption GetArchiveListOption(SPList list)
        {
            try
            {
                var key = GetArchiveOptionKeyForList(list.ID);
                var web = list.ParentWeb;
                if (web.Properties.ContainsKey(key))
                {
                    var value = web.Properties[key];
                    return Utils.DeserializeBase64<ArchiveListOption>(value);
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        private static string GetArchiveOptionKeyForList(Guid listId)
        {
            const string archiveKeyPrefix = "9B79DA5CFC4911DFAACF32EEDED72085-";
            return string.Concat(archiveKeyPrefix, listId.ToString("N").ToUpperInvariant());
        }
    }

    [Serializable]
    public class ArchiveListOption
    {
        public ArchiveListOption()
        {
            NewFormOption = ArchiveFormMode.ShowDeniedMessage;
            DisplayFormOption = ArchiveFormMode.ShowStandardForm;
            EditFormOption = ArchiveFormMode.ShowDeniedMessage;
            ViewFields = new StringCollection {"LinkTitleNoMenu"};
            ShowRestoreButton = true;
            ShowRestoreItemsButton = true;
            AllowCreateNewArchiveList = true;
        }

        public ArchiveFormMode NewFormOption { get; set; }

        public string NewFormUserControlPath { get; set; }

        public ArchiveFormMode DisplayFormOption { get; set; }

        public string DisplayFormUserControlPath { get; set; }

        public ArchiveFormMode EditFormOption { get; set; }

        public string EditFormUserControlPath { get; set; }

        public bool ShowRestoreButton { get; set; }
        
        public bool ShowRestoreItemsButton { get; set; }

        public bool AllowCreateNewArchiveList { get; set; }

        /// <summary>
        /// A collection that contains the internal names of the view fields.
        /// </summary>
        public StringCollection ViewFields { get; set; }
    }

    public enum ArchiveFormMode
    {
        ShowDeniedMessage,
        ShowStandardForm,
        ShowCustomForm,
    }
}