﻿using DeutscheBank.SharePoint.LNAR.Framework.WebParts;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public static class PostProcessHelper
    {
        public static void CreatePostProcessWebPage(SPWeb web)
        {
            CreateCitusDataSource(web);
            WebPageHelper.CreateDefaultWebPage(web, "PostProcess.aspx", true);
            WebPartHelper.AddWebPart(web, "PostProcess.aspx", new PostProcessWebPart { Title = "PostProcessWebPart" },
                                     "Main", 0);
        }

        private static void CreateCitusDataSource(SPWeb web)
        {
            //Create permission level to access post process page
            SecurityHelper.CreatePermissionLevel(web, "CitusPostProcess", "Can post process list.",
                                                 SPBasePermissions.ViewListItems | SPBasePermissions.ViewPages |
                                                 SPBasePermissions.Open);

            // Create document library
            SPList list = web.Lists.TryGetList("DeutscheBankSharePointLNARCitus");

            if (list != null)
            {
                list.Delete();
            }

            var helper = new ListHelper(web)
            {
                Title = "DeutscheBankSharePointLNARCitus",
                ListTemplateType = SPListTemplateType.DocumentLibrary
            };

            list = helper.Apply();

            list.Hidden = true;
            list.Update();

            // Create Async Status List
            list = web.Lists.TryGetList("DeutscheBankSharePointLNARAsyncStatus");

            if (list != null)
            {
                list.Delete();
            }

            helper = new ListHelper(web)
            {
                Title = "DeutscheBankSharePointLNARAsyncStatus"
            };

            list = helper.Apply();

            list.Hidden = true;
            list.Update();

            // Create history list
            list = web.Lists.TryGetList("DeutscheBankSharePointLNARCitusHistory");

            if (list != null)
            {
                list.Delete();
            }

            helper = new ListHelper(web)
            {
                Title = "DeutscheBankSharePointLNARCitusHistory"
            };

            list = helper.Apply();

            list.Hidden = true;
            list.Update();

        }
    }
}