﻿using System.Linq;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Navigation;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    /// <summary>
    ///   A helper support customize Quick Launch
    /// </summary>
    public static class QuickLaunchHelper
    {
        /// <summary>
        ///   Add a heading link
        /// </summary>
        /// <param name = "web"></param>
        /// <param name = "title"></param>
        /// <param name = "url"></param>
        public static SPNavigationNode AddHeading(SPWeb web, string title, string url)
        {
            var quickLaunchNodes = web.Navigation.QuickLaunch;
            var objMenuItem = new SPNavigationNode(title, url, false);
            return quickLaunchNodes.AddAsLast(objMenuItem);
        }

        public static SPNavigationNode GetHeading(SPWeb web, string title)
        {
            return
                web.Navigation.QuickLaunch.Cast<SPNavigationNode>().Where(note => note.Title == title).FirstOrDefault();
        }

        /// <summary>
        ///   Add a link
        /// </summary>
        /// <param name = "parent">Heading node</param>
        /// <param name = "title"></param>
        /// <param name = "url"></param>
        public static void AddNavigationLink(SPNavigationNode parent, string title, string url)
        {
            var node = new SPNavigationNode(title, url);
            parent.Children.AddAsLast(node);
        }
    }
}