﻿using System;
using System.Data;
using System.Text;
using DeutscheBank.SharePoint.LNAR.Framework.WebParts;
using Microsoft.SharePoint;
using System.Collections.Generic;
using System.Xml;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using System.Globalization;
using System.Collections.ObjectModel;
namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public class AuditHelper: IDisposable
    {
        #region for query
        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public uint? RowLimit { get; set; }

        private DataTable table;

        #endregion
        
        #region Parse Data

        /// <summary>
        /// Parse data from raw event data 
        /// </summary>
        /// <param name="rawData"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        private static string ParseData(string rawData, IEnumerable<string> key)
        {
            foreach (string s in key)
            {
                if (rawData.IndexOf(string.Format(CultureInfo.InvariantCulture, "<{0}>", s),StringComparison.OrdinalIgnoreCase) != -1)
                {
                    int startIndex = rawData.IndexOf(string.Format(CultureInfo.InvariantCulture, "<{0}>", s), StringComparison.OrdinalIgnoreCase);
                    int endIndex = rawData.LastIndexOf(string.Format(CultureInfo.InvariantCulture, "</{0}>", s), StringComparison.OrdinalIgnoreCase);
                    return rawData.Substring(startIndex + s.Length + 2, endIndex - startIndex - s.Length - 2);
                }
            }
            return "1";
        }

        private static string ParseAuditMask(string mask)
        {
            var tmp = Convert.ToInt64(mask, CultureInfo.InvariantCulture);
            string result;
            string bitstring = null;
            for (int i = 15; i >= 0; i--)
            {
                result = ((tmp >> i) & 1) == 1 ? "1" : "0";
                bitstring += result;
            }
            result = string.Empty;
            switch (bitstring)
            {
                case "1111111111111111":
                    return LocalizationHelper.GetString("AuditViewerMessage_MS013");
                case "0000000000000000":
                    return LocalizationHelper.GetString("AuditViewerMessage_MS014");
                default:
                    {
                        for (int i = 15; i > 0; i--)
                        {
                            if (bitstring != null)
                                if (bitstring[i] == '1')
                                    result += string.Format(CultureInfo.InvariantCulture,"{0};", Enum.GetName(typeof(SPAuditMaskType), (1 << (15 - i))));
                        }
                        return result;
                    }
            }
        }

        /// <summary>
        /// return the Login Name of relate principal obj
        /// </summary>
        /// <param name="principalId"></param>
        /// <param name="web"></param>
        /// <returns></returns>
        private static string GetPrincipal(int principalId, SPWeb web)
        {
            try
            {
                return string.Format(CultureInfo.InvariantCulture,"{0} [Group]", web.Groups.GetByID(principalId).LoginName);
            }
            catch (SPException)
            {
                try
                {
                    return string.Format(CultureInfo.InvariantCulture,"{0} ", web.AllUsers.GetByID(principalId).LoginName);
                }
                catch (SPException)
                {
                    return string.Format(CultureInfo.InvariantCulture,"Principal ID {0}", principalId);
                }
            }
        }

        private static string GetPrincipal(string principal, SPWeb web)
        {
            int value;
            if (int.TryParse(principal, out value))
            {
                try
                {
                    return string.Format(CultureInfo.InvariantCulture,"{0} [Group]", web.Groups.GetByID(value).LoginName);
                }
                catch (SPException)
                {
                    try
                    {
                        return string.Format(CultureInfo.InvariantCulture,"{0} ", web.AllUsers.GetByID(value).LoginName);
                    }
                    catch (SPException)
                    {
                        return string.Format(CultureInfo.InvariantCulture,"Principal ID {0}", value);
                    }
                }
            }
            return principal;
        }

        /// <summary>
        /// return object relate to event
        /// </summary>
        /// <param name="entry"></param>
        /// <param name="web"></param>
        /// <returns></returns>
        private static string Victim(SPAuditEntry entry, SPWeb web)
        {
            try
            {
                string eventData = entry.EventData;

                switch (entry.Event)
                {
                    case SPAuditEventType.SecGroupCreate:
                        return GetPrincipal((ParseData(eventData, new[] { "groupid" })), web).Trim();
                    case SPAuditEventType.SecGroupMemberAdd:
                        return string.Format(CultureInfo.InvariantCulture, "{0}", GetPrincipal(ParseData(eventData, new[] { "username", "user", "userid" }), web)).Trim();
                    case SPAuditEventType.SecGroupDelete:
                        return GetPrincipal((ParseData(eventData, new[] { "groupid" })), web).Trim();
                    case SPAuditEventType.SecGroupMemberDel:
                        return GetPrincipal((ParseData(eventData, new[] { "username", "user", "userid" })), web).Trim();
                    case SPAuditEventType.SecRoleBindUpdate:
                        return GetPrincipal((ParseData(eventData, new[] { "principalid", "username", "user", "userid" })), web).Trim();
                    case SPAuditEventType.AuditMaskChange:
                        return TryGetScope(web, entry);
                    default:
                        return entry.DocLocation;
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// return name of 
        /// </summary>
        /// <param name="permissionId"></param>
        /// <param name="web"></param>
        /// <returns></returns>
        private static string GetPermission(int permissionId, SPWeb web)
        {
            try
            {
                return web.RoleDefinitions.GetById(permissionId).Name;
            }
            catch (Exception)
            {
                if (permissionId == -1)
                    return LocalizationHelper.GetString("AuditViewerMessage_MS014");
                return string.Format(CultureInfo.InvariantCulture,LocalizationHelper.GetString("AuditViewerMessage_MS011"), permissionId);
            }
        }

        /// <summary>
        /// Parse xml data to friendly information
        /// </summary>
        /// <param name="entry"></param>
        /// <param name="web"></param>
        /// <returns></returns>
        private static string GetFriendLyEvent(SPAuditEntry entry, SPWeb web)
        {
            string eventData = entry.EventData;
            switch (entry.Event)
            {
                case SPAuditEventType.SecGroupMemberAdd:
                    return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS003"), GetPrincipal((ParseData(eventData, new[] { "username", "user", "userid" })), web), GetPrincipal(Convert.ToInt32(ParseData(eventData, new[] { "groupid" }), CultureInfo.InvariantCulture), web));
                case SPAuditEventType.SecGroupMemberDel:
                    return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS005"), GetPrincipal((ParseData(eventData, new[] { "username", "user", "userid" })), web), GetPrincipal(Convert.ToInt32(ParseData(eventData, new[] { "groupid" }), CultureInfo.InvariantCulture), web));

                case SPAuditEventType.SecGroupCreate:
                    return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS001"), GetPrincipal((ParseData(eventData, new[] { "groupid" })), web));
                case SPAuditEventType.SecGroupDelete:
                    return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS002"), GetPrincipal((ParseData(eventData, new[] { "groupid" })), web));
                case SPAuditEventType.SecRoleBindUpdate:
                    var roleId = Convert.ToInt32(ParseData(eventData, new[] {"roleid"}));
                    if (roleId != -1)
                    {
                        
                    }
                    {
                        if (Convert.ToInt32(ParseData(eventData, new[] {"roleid"}), CultureInfo.InvariantCulture) != -1)
                            return string.Format(LocalizationHelper.GetString("AuditViewerMessage_MS004"),
                                                 GetPermission(Convert.ToInt32(ParseData(eventData, new[] {"roleid"})),
                                                               web),
                                                 GetPrincipal(
                                                     Convert.ToInt32(ParseData(eventData, new[] {"principalid"})), web),
                                                 ParseData(eventData, new[] {"operation"}),
                                                 TryGetScope(web, entry));
                        else
                            return string.Format(LocalizationHelper.GetString("AuditViewerMessage_MS017"),
                                                 GetPrincipal(
                                                     Convert.ToInt32(ParseData(eventData, new[] {"principalid"})), web),
                                                 TryGetScope(web, entry));
                    }
                case SPAuditEventType.SecRoleDefCreate:
                    return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS006"), ParseData(eventData, new[] { "name" }), ParseBasePermissions(Convert.ToInt32(ParseData(eventData, new[] { "id" }), CultureInfo.InvariantCulture), web));
                case SPAuditEventType.SecRoleDefModify:
                    return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS008"), ParseData(eventData, new[] { "name" }), ParseBasePermissions(Convert.ToInt32(ParseData(eventData, new[] { "id" }), CultureInfo.InvariantCulture), web));

                case SPAuditEventType.AuditMaskChange:
                    return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS007"), ParseAuditMask((ParseData(eventData, new[] { "NewAuditMask" }))));

                case SPAuditEventType.SecRoleBindInherit:
                    return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS009"), ParseData(eventData, new[] { "url" }));
                case SPAuditEventType.SecRoleBindBreakInherit:
                    return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS010"), ParseData(eventData, new[] { "url" }));
                default:
                    return eventData;
            }
        }
        #endregion

        private static IEnumerable<SPAuditEventType> CreateReportType(int type)
        {
            var list = new List<SPAuditEventType>();
            switch (type)
            {
                // personal security changed profile
                case 1:
                    {
                        list.Add(SPAuditEventType.SecGroupMemberAdd);
                        list.Add(SPAuditEventType.SecGroupMemberDel);
                        break;
                    }
                // action security changed [actor]
                case 2:
                    {
                        list.Add(SPAuditEventType.SecGroupMemberAdd);
                        list.Add(SPAuditEventType.SecGroupMemberDel);

                        list.Add(SPAuditEventType.SecGroupCreate);
                        list.Add(SPAuditEventType.SecGroupDelete);
                        list.Add(SPAuditEventType.SecRoleBindUpdate);
                        list.Add(SPAuditEventType.SecRoleDefBreakInherit);
                        list.Add(SPAuditEventType.SecRoleDefCreate);
                        list.Add(SPAuditEventType.SecRoleDefDelete);
                        list.Add(SPAuditEventType.SecRoleDefModify);
                        break;
                    }

                // security in Web
                case 3:
                    {
                        list.Add(SPAuditEventType.SecGroupMemberAdd);
                        list.Add(SPAuditEventType.SecGroupMemberDel);

                        list.Add(SPAuditEventType.SecGroupCreate);
                        list.Add(SPAuditEventType.SecGroupDelete);

                        list.Add(SPAuditEventType.SecRoleBindUpdate);
                        list.Add(SPAuditEventType.SecRoleDefBreakInherit);
                        list.Add(SPAuditEventType.SecRoleBindInherit);
                        list.Add(SPAuditEventType.SecRoleBindBreakInherit);

                        list.Add(SPAuditEventType.SecRoleDefCreate);
                        list.Add(SPAuditEventType.SecRoleDefDelete);
                        list.Add(SPAuditEventType.SecRoleDefModify);

                        list.Add(SPAuditEventType.AuditMaskChange);
                        break;
                    }
                case 4:
                    {
                        list.Add(SPAuditEventType.View);
                        list.Add(SPAuditEventType.Update);
                        list.Add(SPAuditEventType.Delete);
                        list.Add(SPAuditEventType.CheckIn);
                        list.Add(SPAuditEventType.CheckOut);
                        break;
                    }

                case 9:
                    {
                        list.Add(SPAuditEventType.View);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
            return list;
        }

        #region Query methods

        public DataTable GetUserAccess(SPWeb spWeb, SPUser requestUser, DateTime lastAccessDate)
        {
            table = new DataTable { Locale = CultureInfo.InvariantCulture };
            // schema of data table
            table.Columns.Add("User Name", typeof (string));
            table.Columns.Add("AccessTime", typeof (DateTime));
            var userNameCols = new Collection<int>();
            if (requestUser == null)
            {
                foreach (SPUser user in spWeb.AllUsers)
                {
                    userNameCols.Add(user.ID);
                }
            }
            else
            {
                userNameCols.Add(requestUser.ID);
            }

            var siteId = spWeb.Site.ID;
            var webId = spWeb.ID;

            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        var auditQuery = new SPAuditQuery(site);
                        auditQuery.AddEventRestriction(SPAuditEventType.View);
                        if (lastAccessDate != DateTime.MinValue)
                        {
                            auditQuery.SetRangeEnd(lastAccessDate);
                        }
                        foreach (int userId in userNameCols)
                        {
                            var username = web.AllUsers.GetByID(userId).Name;
                            auditQuery.RestrictToUser(userId);
                            var auditCollection = site.Audit.GetEntries(auditQuery);
                            foreach (SPAuditEntry entry in auditCollection)
                            {
                                table.Rows.Add(username, entry.Occurred);
                            }
                        }
                    }
                }
            });
           return table;
        }

        public DataTable GetUserAccessCount(SPWeb spWeb, SPUser requestUser, DateTime lastAccessDate)
        {
            table = new DataTable { Locale = CultureInfo.InvariantCulture };
            // schema of data table
            table.Columns.Add("User Name", typeof(string));
            table.Columns.Add("AccessCount", typeof(int));
            var userNameCols = new Collection<int>();
            if (requestUser == null)
            {
                foreach (SPUser user in spWeb.AllUsers)
                {
                    userNameCols.Add(user.ID);
                }
            }
            else
            {
                userNameCols.Add(requestUser.ID);
            }

            var siteId = spWeb.Site.ID;
            var webId = spWeb.ID;

            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        var auditQuery = new SPAuditQuery(site);
                        auditQuery.AddEventRestriction(SPAuditEventType.View);
                        if (lastAccessDate != DateTime.MinValue)
                        {
                            auditQuery.SetRangeEnd(lastAccessDate);
                        }

                        foreach (int userId in userNameCols)
                        {
                            var username = web.AllUsers.GetByID(userId).Name;
                            auditQuery.RestrictToUser(userId);
                            var auditCollection = site.Audit.GetEntries(auditQuery);
                            table.Rows.Add(username, auditCollection.Count);
                        }
                    }
                }
            });
            return table;
        }

        public DataTable GetAuditUserByUser(SPWeb spWeb, Collection<string> userNameCols, int selectedReport)
        {
           table = new DataTable {Locale = CultureInfo.InvariantCulture};
            // schema of data table
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS001"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS002"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS003"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS004"), typeof(DateTime));

            var siteId = spWeb.Site.ID;
            var webId = spWeb.ID;

            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        int i;
                        var auditQuery = new SPAuditQuery(site);

                        if (StartDate.HasValue)
                        {
                            auditQuery.SetRangeStart((DateTime)StartDate);
                        }

                        if (EndDate.HasValue)
                        {
                            auditQuery.SetRangeEnd(((DateTime)EndDate).AddDays(1) );
                        }

                        if (selectedReport != 0)
                        {
                            foreach (SPAuditEventType eventType in CreateReportType(selectedReport))
                            {
                                auditQuery.AddEventRestriction(eventType);
                            }
                            var auditCollection = site.Audit.GetEntries(auditQuery);
                            for (i = 0; i < auditCollection.Count; i++)
                            {
                                foreach (var usernameCol in userNameCols)
                                {
                                    var victim = Victim(auditCollection[i], web);
                                    if (usernameCol.Trim() == victim)
                                    {
                                        table.Rows.Add(victim, GetFriendLyEvent(auditCollection[i], web), web.AllUsers.GetByID(auditCollection[i].UserId).Email, auditCollection[i].Occurred);
                                    }
                                }
                            }
                        }
                        else
                        {
                            var auditCollection = site.Audit.GetEntries();
                            for (i = 0; i < auditCollection.Count; i++)
                            {

                                foreach (var usernameCol in userNameCols)
                                {
                                    var victim = Victim(auditCollection[i], web);
                                    if (usernameCol.Trim() == victim)
                                    {
                                        table.Rows.Add(victim, auditCollection[i].EventData, web.AllUsers.GetByID(auditCollection[i].UserId).Email, auditCollection[i].Occurred);
                                    }
                                }
                            }
                        }
                    }

                }
            });

            if (table.Rows.Count == 0)
            {
                return GetEmtyQuery();
            }
            return table;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="spWeb"></param>
        /// <param name="userIdCollection"></param>
        /// <param name="selectedReport"></param>
        /// <returns></returns>
        public DataTable GetAuditActorData(SPWeb spWeb, Collection<int> userIdCollection, int selectedReport)
        {
            table = new DataTable {Locale = CultureInfo.InvariantCulture};
            // schema of data table
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS005"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS002"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS003"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS004"), typeof(DateTime));

            var siteId = spWeb.Site.ID;
            var webId = spWeb.ID;
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        int i;
                        var auditQuery = new SPAuditQuery(site);
                        foreach (var userId in userIdCollection)
                        {
                            auditQuery.RestrictToUser(userId);
                            if (StartDate.HasValue)
                            {
                                auditQuery.SetRangeStart((DateTime)StartDate);
                            }

                            if (EndDate.HasValue)
                            {
                                auditQuery.SetRangeEnd(((DateTime)EndDate).AddDays(1));
                            }

                            if (RowLimit.HasValue)
                            {
                                auditQuery.RowLimit = (uint)RowLimit;
                            }
                            if (selectedReport != 0)
                            {
                                foreach (var eventType in CreateReportType(selectedReport))
                                {
                                    auditQuery.AddEventRestriction(eventType);
                                }

                                var auditCollection = web.Audit.GetEntries(auditQuery);

                                for (i = 0; i < auditCollection.Count; i++)
                                {
                                    table.Rows.Add(Victim(auditCollection[i], web), GetFriendLyEvent(auditCollection[i], web), TryGetUser(web,auditCollection[i].UserId,UserProperty.Email), auditCollection[i].Occurred);
                                }
                            }
                            else
                            {
                                var auditCollection = web.Audit.GetEntries(auditQuery);

                                for (i = 0; i < auditCollection.Count; i++)
                                {
                                    table.Rows.Add(Victim(auditCollection[i], web), auditCollection[i].EventData, TryGetUser(web, auditCollection[i].UserId, UserProperty.Email), auditCollection[i].Occurred);
                                }
                            }
                        }
                    }
                }
            });

            if (table.Rows.Count == 0)
            {
                return GetEmtyQuery();
            }
            return table;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="spWeb"></param>
        /// <param name="spListCollection"></param>
        /// <param name="selectedReport"></param>
        /// <returns></returns>
        public DataTable GetAuditListData(SPWeb spWeb, Collection <Guid> spListCollection, int selectedReport)
        {
             table = new DataTable {Locale = CultureInfo.InvariantCulture};
            // schema of data table
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS006"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS002"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS003"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS004"), typeof(DateTime));

            var siteId = spWeb.Site.ID;
            var webId = spWeb.ID;
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        int i;
                        var auditQuery = new SPAuditQuery(site);
                        foreach (var listGuid in spListCollection)
                        {
                            SPList splist = web.Lists[listGuid];
                            auditQuery.RestrictToList(splist);

                            if (StartDate.HasValue)
                            {
                                auditQuery.SetRangeStart((DateTime)StartDate);
                            }

                            if (EndDate.HasValue)
                            {
                                auditQuery.SetRangeEnd(((DateTime)EndDate).AddDays(1));
                            }

                            if (RowLimit.HasValue)
                            {
                                auditQuery.RowLimit = (uint)RowLimit;
                            }
                            if (selectedReport != 0)
                            {
                                foreach (SPAuditEventType eventType in CreateReportType(selectedReport))
                                {
                                    auditQuery.AddEventRestriction(eventType);
                                }

                                var auditCollection = web.Audit.GetEntries(auditQuery);
                                for (i = 0; i < auditCollection.Count; i++)
                                {
                                    table.Rows.Add(Victim(auditCollection[i], web), GetFriendLyEvent(auditCollection[i], web), GetPrincipal(auditCollection[i].UserId, web), auditCollection[i].Occurred);
                                }
                            }
                            else
                            {
                                var auditCollection = web.Audit.GetEntries(auditQuery);

                                for (i = 0; i < auditCollection.Count; i++)
                                {
                                    table.Rows.Add(Victim(auditCollection[i], web), auditCollection[i].EventData, web.AllUsers.GetByID(auditCollection[i].UserId).Email, auditCollection[i].Occurred);
                                }
                            }
                        }
                    }
                }
            });

            if (table.Rows.Count == 0)
            {
                return GetEmtyQuery();
            }
            return table;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="spWeb"></param>
        /// <param name="selectedReport"></param>
        /// <returns></returns>
        public DataTable GetAllWebAudit(SPWeb spWeb, int selectedReport)
        {
            table = new DataTable {Locale = CultureInfo.InvariantCulture};
            // schema of data table
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS007"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS002"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS003"), typeof(string));
            table.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS004"), typeof(DateTime));

            var accessReport = new DataTable();
            accessReport.Columns.Add("User Name", typeof(string));
            accessReport.Columns.Add("Last Access", typeof(DateTime));
            accessReport.Columns.Add("Total Access", typeof(int));
            var siteId = spWeb.Site.ID;
            var webId = spWeb.ID;
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        var auditQuery = new SPAuditQuery(site);
                        if (StartDate.HasValue)
                        {
                            auditQuery.SetRangeStart((DateTime)StartDate);
                        }

                        if (EndDate.HasValue)
                        {
                            auditQuery.SetRangeEnd(((DateTime)EndDate).AddDays(1));
                        }
                        if (selectedReport != 0)
                        {
                            if (selectedReport == 9)
                            {
                               table = new DataTable();
                               table.Columns.Add("User Name", typeof(string));
                               table.Columns.Add("Last Access", typeof(DateTime));
                               table.Columns.Add("Total Access", typeof(int));

                                foreach (SPUser user in web.AllUsers)
                                {

                                    var auditQuery1 = new SPAuditQuery(site);
                                    {
                                        auditQuery1.AddEventRestriction(SPAuditEventType.View);
                                        auditQuery1.RestrictToUser(user.ID);
                                       
                                        var auditCollection = web.Audit.GetEntries(auditQuery1);

                                        if (auditCollection.Count > 0)
                                        {
                                            table.Rows.Add(user.Name,
                                                    SPContext.Current.RegionalSettings.TimeZone.UTCToLocalTime(auditCollection[auditCollection.Count - 1].Occurred),
                                                                    auditCollection.Count);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                foreach (SPAuditEventType eventType in CreateReportType(selectedReport))
                                {
                                    auditQuery.AddEventRestriction(eventType);
                                }

                                var auditCollection = web.Audit.GetEntries(auditQuery);

                                for (int i = 0; i < auditCollection.Count; i++)
                                {
                                    table.Rows.Add(Victim(auditCollection[i], web), GetFriendLyEvent(auditCollection[i], web), TryGetUser(web, auditCollection[i].UserId, UserProperty.Email), spWeb.RegionalSettings.TimeZone.UTCToLocalTime(auditCollection[i].Occurred));
                                }
                            }
                        }
                        else
                        {
                            var auditCollection = web.Audit.GetEntries(auditQuery);

                            for (int i = 0; i < auditCollection.Count; i++)
                            {
                                table.Rows.Add(Victim(auditCollection[i], web), auditCollection[i].EventData, TryGetUser(web, auditCollection[i].UserId, UserProperty.Email), spWeb.RegionalSettings.TimeZone.UTCToLocalTime(auditCollection[i].Occurred));
                            }
                        }
                    }
                }
            });

            if (table.Rows.Count == 0)
            {
                return GetEmtyQuery();
            }
            
            return table;
        }

        #endregion

        #region Configuration

        /// <summary>
        /// Delete Audit Data
        /// </summary>
        /// <param name="site"></param>
        /// <param name="dateTime"></param>
        public static void DeleteSiteAudit(SPSite site, DateTime dateTime)
        {
            site.Audit.DeleteEntries(dateTime);
        }

        public static int GetAuditStatus(SPWeb spWeb, object value)
        {
            var siteId = spWeb.Site.ID;
            var webId = spWeb.ID;
            int tmp = -2;
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        if (value is SPSite)
                        {
                            tmp = (int)site.Audit.AuditFlags;
                        }

                        if (value is SPWeb)
                        {
                            tmp = (int)web.Audit.AuditFlags;
                        }

                        if (value is SPList)
                        {
                            var target = (SPList)value;
                            tmp = (int)target.Audit.AuditFlags;
                        }

                        if (value is SPListItem)
                        {
                            var target = (SPListItem)value;
                            tmp = (int)target.Audit.AuditFlags;
                        }
                    }
                }
            });
            return tmp;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="spWeb"></param>
        /// <param name="value"></param>
        /// <param name="mask"></param>
        public static void ModifyConfigAudit(SPWeb spWeb, object value, int mask)
        {
            var siteId = spWeb.Site.ID;
            var webId = spWeb.ID;
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (var site = new SPSite(siteId))
                {
                    using (var web = site.OpenWeb(webId))
                    {
                        if (value is SPWeb)
                        {
                            var target = (SPWeb)value;
                            var allowUnsafeUpdates = SecurityHelper.SetAllowUnsafeUpdates(target);
                            target.Audit.AuditFlags =
                                (SPAuditMaskType) SetMaskForWeb((int) target.Audit.AuditFlags, mask);
                            
                            target.Audit.Update();
                            SecurityHelper.RollbackAllowUnsafeUpdates(target, allowUnsafeUpdates);
                        }

                        if (value is SPList)
                        {
                            var target = (SPList)value;
                            var allowUnsafeUpdates = SecurityHelper.SetAllowUnsafeUpdates(web);
                            target.Audit.AuditFlags = (SPAuditMaskType)mask;
                            target.Audit.Update();
                            SecurityHelper.RollbackAllowUnsafeUpdates(web, allowUnsafeUpdates);
                        }

                        if (value is SPListItem)
                        {
                            var target = (SPListItem)value;
                            var allowUnsafeUpdates = SecurityHelper.SetAllowUnsafeUpdates(web);
                            target.Audit.AuditFlags = (SPAuditMaskType)mask;
                            target.Audit.Update();
                            SecurityHelper.RollbackAllowUnsafeUpdates(web, allowUnsafeUpdates);
                        }

                        if (value is SPFolder)
                        {
                            var target = (SPFolder)value;
                            var allowUnsafeUpdates = SecurityHelper.SetAllowUnsafeUpdates(web);
                            target.Audit.AuditFlags = (SPAuditMaskType)mask;
                            target.Audit.Update();
                            SecurityHelper.RollbackAllowUnsafeUpdates(web, allowUnsafeUpdates);
                        }

                        if (value is SPSite)
                        {
                            var target = (SPSite)value;
                            var allowUnsafeUpdates = SetAllowUnsafeUpdates(target);
                           // target.Audit.AuditFlags = mask == 0 ? SPAuditMaskType.SecurityChange : (SPAuditMaskType)mask;
                            target.Audit.AuditFlags =
                               (SPAuditMaskType)SetMaskForWeb((int)target.Audit.AuditFlags, mask);
                            target.Audit.Update();
                            RollbackAllowUnsafeUpdates(target, allowUnsafeUpdates);
                        }
                    }
                }
            });
        }

        private static int SetMaskForWeb (int oldMask, int newMask)
        {
            return (oldMask & 256) == 256 ? newMask | 256 : newMask;
        }

        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="web"></param>
        public static void CreateAuditLogPages(SPWeb web)
        {
            WebPageHelper.CreateDefaultWebPage(web, "AuditSetting.aspx", true);
            WebPartHelper.AddWebPart(web, "AuditSetting.aspx", new AuditSettingsWebPart { Title = "AuditSettingsWebPart" }, "Main", 0);
            WebPageHelper.CreateDefaultWebPage(web, "AuditLogViewer.aspx", true);
            WebPartHelper.AddWebPart(web, "AuditLogViewer.aspx", new AuditViewerWebPart { Title = "Audit Log Viewer" }, "Main", 0);
            SecurityHelper.CreatePermissionLevel(web, FrameworkConstants.AuditRoleDefinition, "Can use Audit feature", SPBasePermissions.ViewListItems | SPBasePermissions.ViewPages | SPBasePermissions.Open);
            var listHelper = new ListHelper(web)
            {
                Title = FrameworkConstants.AuditList,
                Description = string.Empty,
                ListTemplateType = SPListTemplateType.DocumentLibrary,
            };
            listHelper.Apply();
        }

        internal static bool SetAllowUnsafeUpdates(SPSite site)
        {
            if (!site.AllowUnsafeUpdates)
            {
                site.AllowUnsafeUpdates = true;
                return true;
            }
            return false;
        }

        internal static void RollbackAllowUnsafeUpdates(SPSite site, bool status)
        {
            if (status)
            {
                site.AllowUnsafeUpdates = false;
            }
        }

        private static string TryGetScope(SPWeb web, SPAuditEntry entry)
        {
            try
            {
                return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS011"), web.Lists[entry.ItemId].Title);
            }
            catch (Exception)
            {
                try
                {
                    string webTitle;
                    using (var newWeb = web.Site.OpenWeb(entry.ItemId))
                    {
                        webTitle = newWeb.Title;
                    }
                    return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS015"), webTitle);
                }
                catch (Exception)
                {
                    try
                    {
                        string hostName;
                        int port;
                        using (var site = new SPSite(entry.ItemId))
                        {
                            hostName = site.HostName;
                            port = site.Port;
                        }
                        return string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS016"), hostName, port);
                    }
                    catch (Exception)
                    {
                        return entry.Event == SPAuditEventType.AuditMaskChange
                                   ? string.Empty
                                   : string.Format(CultureInfo.InvariantCulture, LocalizationHelper.GetString("AuditViewerMessage_MS012"), ParseData(entry.EventData, new[] { "scope" }));
                    }
                }
            }
        }

        private static string ParseBasePermissions(int permission, SPWeb web)
        {
            try 
            {
                var builder = new StringBuilder();
                var roleDefinition = web.RoleDefinitions.GetById(permission);
                var roleInXml = new XmlDocument();
                roleInXml.LoadXml(roleDefinition.Xml);

                XmlNode nodes = roleInXml.DocumentElement;
                if (nodes != null) builder.Append(nodes.Attributes["BasePermissions"].Value);
                return builder.ToString();
            }
            catch(Exception)
            {
                return string.Empty;
            }
        }

        internal static DataTable GetEmtyQuery()
        {
            var emptytable = new DataTable {Locale = CultureInfo.InvariantCulture};
            emptytable.Columns.Add(LocalizationHelper.GetString("AuditViewerTable_MS008"), typeof(string));
            emptytable.Rows.Add(LocalizationHelper.GetString("AuditViewerTable_MS009"));
            return emptytable;
        }

        private void Dispose(bool disposing)
        {
            if (disposing)
                table.Dispose();
        }

        public void Dispose()
        {  
            Dispose(true);

            GC.SuppressFinalize(this);
        }

        public static string TryGetUser(SPWeb web, int userId, UserProperty property)
        {
            try
            {
                switch (property)
                {
                    case UserProperty.UserName :
                        return web.AllUsers.GetByID(userId).LoginName;
                    case UserProperty.Email :
                        return web.AllUsers.GetByID(userId).Email;
                    default:
                        return web.AllUsers.GetByID(userId).Name;                       
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }         
        }
    }

    public enum UserProperty
    {
        UserName,
        Email,
        FullName,
    }
}
