﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using DeutscheBank.SharePoint.LNAR.Framework.WebParts;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public class SendItemHelper
    {
        public static void CreateSendItemPage(SPWeb web)
        {
            WebPageHelper.CreateDefaultWebPage(web, "SendItem.aspx", true);
            WebPartHelper.AddWebPart(web, "SendItem.aspx", new SendItemWebPart {Title = @"SendItemWebPart"}, "Main", 0);
        }

        public static bool SendItemWithTemplatePath(SPWeb web, IEnumerable<SPListItem> items, string templatePath, string from, string to, string subject, string body)
        {
            if (items == null || items.Count() == 0)
            {
                throw new ArgumentNullException("items");
            }

            if (string.IsNullOrEmpty(templatePath))
            {
                throw new ArgumentNullException("templatePath");
            }

            // Get template
            var htmlTemplate = TemplateHelper.GetTemplateFromFile(web, templatePath);

            return SendItemWithTemplate(web, items, htmlTemplate, from, to, subject, body);
        }

        public static bool SendItemWithTemplate(SPWeb web, IEnumerable<SPListItem> items, string htmlTemplate, string from, string to, string subject, string body)
        {
            var mailMessage = new MailMessage();

            if (!string.IsNullOrEmpty(from))
            {
                mailMessage.From = new MailAddress(from);
            }

            foreach (var email in to.Split(new[] { "; ", ";" }, StringSplitOptions.RemoveEmptyEntries))
            {
                mailMessage.To.Add(email);
            }

            mailMessage.SubjectEncoding = Encoding.UTF8;
            mailMessage.Subject = subject;

            mailMessage.BodyEncoding = Encoding.UTF8;
            mailMessage.IsBodyHtml = true;
            mailMessage.Body = body;

            // Attchments
            foreach (var item in items)
            {
                var html = TemplateHelper.TransformHtml(item, htmlTemplate);
                var bytes = Encoding.UTF8.GetBytes(html);
                var ms = new MemoryStream(bytes);
                var name = string.IsNullOrEmpty(item.Title) ? string.Format("{0}.html", item.ID) : string.Format("{0}.html", item.Title);
                var attachment = new Attachment(ms, name, "text/html");
                mailMessage.Attachments.Add(attachment);
            }

            return MailHelper.SendEmail(web, mailMessage);
        }

        public static bool SendItemWithDefaultTemplate(SPWeb web, IEnumerable<SPListItem> items, string from, string to, string subject, string body)
        {
            if (items == null || items.Count() == 0)
            {
                throw new ArgumentNullException("items");
            }

            var htmlTemplate = TemplateHelper.BuildDefaultTemplate(items.First());

            return SendItemWithTemplate(web, items, htmlTemplate, from, to, subject, body);
        }
    }
}