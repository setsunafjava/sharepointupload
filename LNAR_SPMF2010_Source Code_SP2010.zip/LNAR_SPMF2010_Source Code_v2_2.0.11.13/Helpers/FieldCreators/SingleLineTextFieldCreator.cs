﻿using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public class SingleLineTextFieldCreator : BaseFieldCreator
    {
        public SingleLineTextFieldCreator(string name) : base(name)
        {
            MaxLength = 255;
        }

        /// <summary>
        /// Gets or sets the maximum number of characters that can be typed in the field. 
        /// </summary>
        public int MaxLength { get; set; }

        internal override void CreateField(SPList list)
        {
            var name = list.Fields.Add(Name, SPFieldType.Text, Required);
            var field = (SPFieldText) list.Fields.GetFieldByInternalName(name);
            field.Description = Description;
            field.MaxLength = MaxLength;
            field.DefaultValue = DefaultValue;

            if (EnforceUniqueValues)
            {
                field.Indexed = true;
                field.EnforceUniqueValues = true;    
            }
            field.ValidationFormula = ValidationFormula;
            field.ValidationMessage = ValidationMessage;
            field.Update();
        }
    }
}