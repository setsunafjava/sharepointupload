﻿using System;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public class UserFieldCreator : BaseFieldCreator
    {
        public UserFieldCreator(string name) : base(name)
        {
        }

        public override string ValidationFormula
        {
            get { throw new NotSupportedException(); }
            set { throw new NotSupportedException(); }
        }

        public SPFieldUserSelectionMode SelectionMode { get; set; }
        public bool AllowMultipleValues { get; set; }
        public int SelectionGroup { get; set; }

        internal override void CreateField(SPList list)
        {
            if (AllowMultipleValues)
            {
                list.Fields.AddFieldAsXml(string.Format("<Field Type=\"UserMulti\" DisplayName=\"{0}\" List=\"UserInfo\" ShowField=\"ImnName\" Required=\"{1}\" UserSelectionMode=\"{2}\" UserSelectionScope=\"{3}\" Mult=\"TRUE\" Sortable=\"FALSE\" />", Name, Required.ToString().ToUpperInvariant(), SelectionMode, SelectionGroup), false, SPAddFieldOptions.Default);
            }
            else
            {
                var name = list.Fields.Add(Name, SPFieldType.User, Required);
                var field = (SPFieldUser) list.Fields.GetFieldByInternalName(name);
                field.Description = Description;
                field.SelectionMode = SelectionMode;
                if (SelectionGroup > 0)
                {
                    field.SelectionGroup = SelectionGroup;
                }

                if (EnforceUniqueValues)
                {
                    field.Indexed = true;
                    field.EnforceUniqueValues = true;
                }

                field.Update();
            }
        }
    }
}