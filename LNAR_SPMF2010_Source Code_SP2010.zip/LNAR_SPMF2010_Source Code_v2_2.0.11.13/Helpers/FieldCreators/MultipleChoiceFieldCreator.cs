﻿using System;
using System.Collections.Specialized;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public class MultipleChoiceFieldCreator : BaseFieldCreator
    {
        public MultipleChoiceFieldCreator(string name) : base(name)
        {
            Choices = new StringCollection();
        }

        /// <summary>
        /// Gets or sets a Boolean value that determines whether a text box for typing an alternative value is provided for the multichoice field. 
        /// </summary>
        public bool FillInChoice { get; set; }

        [Obsolete("Use FillInChoice")]
        public bool AllowFillIn { get; set; }

        public StringCollection Choices { get; private set; }

        public override bool EnforceUniqueValues
        {
            get { throw new NotSupportedException(); }
            set { throw new NotSupportedException(); }
        }

        public override string ValidationFormula
        {
            get { throw new NotSupportedException(); }
            set { throw new NotSupportedException(); }
        }

        internal override void CreateField(SPList list)
        {
            var name = list.Fields.Add(Name, SPFieldType.MultiChoice, Required);
            var field = (SPFieldMultiChoice) list.Fields.GetFieldByInternalName(name);
            field.Description = Description;
            foreach (var choice in Choices)
            {
                field.Choices.Add(choice);
            }

            field.FillInChoice = FillInChoice;
            field.DefaultValue = DefaultValue;
            field.Update();
        }
    }
}