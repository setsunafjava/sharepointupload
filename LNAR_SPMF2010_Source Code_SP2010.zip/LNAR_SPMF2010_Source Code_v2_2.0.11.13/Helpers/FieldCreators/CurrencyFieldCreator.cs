﻿using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public class CurrencyFieldCreator : NumberFieldCreator
    {
        public CurrencyFieldCreator(string name) : base(name)
        {
        }

        /// <summary>
        /// Gets or sets the currency symbol that is used to format the field's value, and also the position of the currency symbol (for example, whether before or after numeric values).
        /// </summary>
        public int CurrencyLocaleId { get; set; }
        
        internal override void CreateField(SPList list)
        {
            var name = list.Fields.Add(Name, SPFieldType.Currency, Required);
            var field = (SPFieldCurrency) list.Fields.GetFieldByInternalName(name);
            field.Description = Description;
            field.MinimumValue = MinimumValue;
            field.MaximumValue = MaximumValue;
            field.DisplayFormat = DisplayFormat;
            field.DefaultValue = DefaultValue;
            field.CurrencyLocaleId = CurrencyLocaleId;
            if (EnforceUniqueValues)
            {
                field.Indexed = true;
                field.EnforceUniqueValues = true;
            }
            field.ValidationFormula = ValidationFormula;
            field.ValidationMessage = ValidationMessage;
            field.Update();
        }
    }
}