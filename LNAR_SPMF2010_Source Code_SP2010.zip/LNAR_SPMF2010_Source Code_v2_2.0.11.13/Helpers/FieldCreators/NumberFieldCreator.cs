﻿using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public class NumberFieldCreator : BaseFieldCreator
    {
        public NumberFieldCreator(string name) : base(name)
        {
            MinimumValue = double.MinValue;
            MaximumValue = double.MaxValue;
        }

        /// <summary>
        /// Gets or sets the number of decimal places to use when displaying the field. 
        /// </summary>
        public SPNumberFormatTypes DisplayFormat { get; set; }

        /// <summary>
        /// Gets or sets a maximum value for the field. 
        /// </summary>
        public double MaximumValue { get; set; }

        /// <summary>
        /// Gets or sets a minimum value for the field. 
        /// </summary>
        public double MinimumValue { get; set; }

        /// <summary>
        /// Gets or sets a Boolean value that specifies whether to render the field as a percentage. 
        /// </summary>
        public virtual bool ShowAsPercentage { get; set; }

        internal override void CreateField(SPList list)
        {
            var name = list.Fields.Add(Name, SPFieldType.Number, Required);
            var field = (SPFieldNumber) list.Fields.GetFieldByInternalName(name);
            field.Description = Description;
            field.MinimumValue = MinimumValue;
            field.MaximumValue = MaximumValue;
            field.DisplayFormat = DisplayFormat;
            field.DefaultValue = DefaultValue;
            field.ShowAsPercentage = ShowAsPercentage;

            if (EnforceUniqueValues)
            {
                field.Indexed = true;
                field.EnforceUniqueValues = true;
            }
            field.ValidationFormula = ValidationFormula;
            field.ValidationMessage = ValidationMessage;
            field.Update();
        }
    }
}