﻿using System;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public class UrlFieldCreator : BaseFieldCreator
    {
        public UrlFieldCreator(string name) : base(name)
        {
        }

        public override bool EnforceUniqueValues
        {
            get { throw new NotSupportedException(); }
            set { throw new NotSupportedException(); }
        }

        public override string ValidationFormula
        {
            get { throw new NotSupportedException(); }
            set { throw new NotSupportedException(); }
        }

        public SPUrlFieldFormatType DisplayFormat { get; set; }

        internal override void CreateField(SPList list)
        {
            var name = list.Fields.Add(Name, SPFieldType.URL, Required);
            var field = (SPFieldUrl) list.Fields.GetFieldByInternalName(name);
            field.Description = Description;
            field.DisplayFormat = DisplayFormat;
            field.Update();
        }
    }
}