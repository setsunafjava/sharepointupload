﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    /// <summary>
    ///   A helper support create a new list instance
    /// </summary>
    public class ListHelper
    {
        private readonly List<BaseFieldCreator> creators;
        private readonly SPWeb web;
        private string archivedListName;

        public ListHelper(SPWeb web)
        {
            this.web = web;
            creators = new List<BaseFieldCreator>();
            ListTemplateType = SPListTemplateType.GenericList;
            Views = new List<ViewCreator>();
            EnableAttachments = true;
            ShowRestoreButtonInArchivedList = true;
            ShowRestoreItemsButtonInArchivedList = true;
        }

        public string Title { get; set; }

        public string Description { get; set; }

        public SPListTemplateType ListTemplateType { get; set; }

        public bool OnQuickLaunch { get; set; }

        /// <summary>
        /// Indicates whether throttling for this list is disable.
        /// </summary>
        public bool DisableListThrottling { get; set; }
        
        /// <summary>
        /// Indicates whether throttling for this archive list is disable.
        /// </summary>
        public bool DisableArchivedListThrottling { get; set; }

        /// <summary>
        ///   Enabled archives for this list
        /// </summary>
        public bool CreateArchivedList { get; set; }

        /// <summary>
        /// Show restore button in archived list, default is True.
        /// </summary>
        public bool ShowRestoreButtonInArchivedList { get; set; }

        /// <summary>
        /// Show restore items button in archived list, default is True.
        /// </summary>
        public bool ShowRestoreItemsButtonInArchivedList { get; set; }

        /// <summary>
        ///   Archive list name, default is "Archived [List Name]"
        /// </summary>
        public string ArchivedListName
        {
            get
            {
                if (string.IsNullOrEmpty(archivedListName))
                {
                    return "Archived " + Title;
                }
                return archivedListName;
            }
            set { archivedListName = value; }
        }

        public bool ShowArchivedListOnQuickLaunch { get; set; }

        /// <summary>
        /// Gets or sets a Boolean value that specifies whether attachments can be added to items in the list.
        /// </summary>
        public bool EnableAttachments { get; set; }

        public IList<ViewCreator> Views { get; private set; }

        /// <summary>
        /// Create a list with fields
        /// </summary>
        /// <returns></returns>
        public SPList Apply()
        {
            var list = CreateList(Title, Description, ListTemplateType, OnQuickLaunch, DisableListThrottling);

            if (!EnableAttachments)
            {
                list.EnableAttachments = false;
            }

            list.Update();

            // Create views
            foreach (var viewCreator in Views)
            {
                viewCreator.Apply(list);
            }

            if (CreateArchivedList)
            {
                var archivedList = CreateList(ArchivedListName, string.Empty, ListTemplateType, ShowArchivedListOnQuickLaunch, DisableArchivedListThrottling);
                ArchiveHelper.LinkArchiveLists(web, list.ID, archivedList.ID);

                // Show restore button
                if (ShowRestoreButtonInArchivedList)
                {
                    ShowRestoreButton(web, archivedList);
                }

                if (ShowRestoreItemsButtonInArchivedList)
                {
                    ShowRestoreItemsButton(web, archivedList);
                }
            }
            return list;
        }

        private SPList CreateList(string title, string description, SPListTemplateType listTemplateType, bool onQuickLaunch, bool disableListThrottling)
        {
            var list = web.Lists.TryGetList(title);

            if (list == null)
            {
                var id = web.Lists.Add(title, description, listTemplateType);
                list = web.Lists[id];

                try
                {
                    list.OnQuickLaunch = onQuickLaunch;

                    foreach (var creator in creators)
                    {
                        creator.CreateField(list);
                    }

                    if (disableListThrottling)
                    {
                        list.EnableThrottling = false;
                    }

                    list.Update();

                    return list;
                }
                catch (Exception ex)
                {
                    if (id != Guid.Empty)
                    {
                        web.Lists[id].Delete();
                    }

                    throw new ArgumentException(
                        string.Format("Cannot create a list '{0}' because: {1}", title, ex.Message), ex);
                }
            }
            
            return list;
        }

        public void AddField(BaseFieldCreator creator)
        {
            creators.Add(creator);
        }

        /// <summary>
        /// Indicates whether throttling for this list is disable.
        /// </summary>
        public static void DisableListThreshold(SPList list)
        {
            list.EnableThrottling = false;
            list.Update();
        }

        /// <summary>
        /// Indicates whether field will indexed.
        /// </summary>
        /// <param name="field"></param>
        public static void CreateIndexedField(SPField field)
        {
            if (!field.Indexed)
            {
                field.Indexed = true;
                field.Update();
            }
        }

        /// <summary>
        /// Indicates whether field will indexed.
        /// </summary>
        /// <param name="list"></param>
        /// <param name="fieldName"></param>
        public static void CreateIndexedField(SPList list, string fieldName)
        {
            var field = list.Fields[fieldName];
            CreateIndexedField(field);
        }

        /// <summary>
        /// Add a archive button for a list
        /// </summary>
        /// <param name="web"></param>
        /// <param name="list">The archive button will show in standard view.</param>
        public static void ShowArchiveButton(SPWeb web, SPList list)
        {
            const string name = "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.ArchiveListOnStandardView";
            var btnCustomRibbon = list.UserCustomActions.FirstOrDefault(c => c.Name == name) ??
                                  list.UserCustomActions.Add();

            var title = LocalizationHelper.GetString("ListDataView_MS002");

            const string commandUIExtension = @"<CommandUIExtension>
                      <CommandUIDefinitions>
                        <CommandUIDefinition
                          Location=""Ribbon.List.Settings.Controls._children"">
                          <Button
                            Id=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.ArchiveListOnStandardView""
                            Sequence=""40""
                            Command=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Commands.ArchiveListOnStandardView""
                            LabelText=""{0}""
                            Image32by32=""/_layouts/{1}/images/formatmap32x32.png""
                             Image32by32Top = ""-160""
                           Image32by32Left = ""-224""
                            TemplateAlias=""o1"" />
                        </CommandUIDefinition>
                      </CommandUIDefinitions>
                      <CommandUIHandlers>
                        <CommandUIHandler Command=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Commands.ArchiveListOnStandardView"" CommandAction=""javascript:window.location = '../../ArchiveList.aspx?ListId={2}';"" />
                      </CommandUIHandlers>
                    </CommandUIExtension>";

            btnCustomRibbon.CommandUIExtension = string.Format(commandUIExtension, title, Thread.CurrentThread.CurrentUICulture.LCID, list.ID);
            btnCustomRibbon.Name = name;
            btnCustomRibbon.Title = title;
            btnCustomRibbon.Location = "CommandUI.Ribbon";
            btnCustomRibbon.Update();
            list.Update();
        }

        /// <summary>
        /// Hide archive button for a list
        /// </summary>
        /// <param name="web"></param>
        /// <param name="list"></param>
        public static void HideArchiveButton(SPWeb web, SPList list)
        {
            const string name = "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.ArchiveListOnStandardView";
            var btnCustomRibbon = list.UserCustomActions.FirstOrDefault(c => c.Name == name);
            if (btnCustomRibbon != null)
            {
                btnCustomRibbon.Delete();
                list.Update();
            }
        }

        public static void ShowRestoreButton(SPWeb web, SPList list)
        {
            const string name = "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.RestoreListOnStandardView";
            var allowUnsafeUpdates = SecurityHelper.SetAllowUnsafeUpdates(web);
            var btnCustomRibbon = list.UserCustomActions.FirstOrDefault(c => c.Name == name) ??
                                  list.UserCustomActions.Add();

            var title = LocalizationHelper.GetString("ListDataView_MS005");

            const string commandUIExtension = @"<CommandUIExtension>
                      <CommandUIDefinitions>
                        <CommandUIDefinition
                          Location=""Ribbon.List.Settings.Controls._children"">
                          <Button
                            Id=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.RestoreListOnStandardView""
                            Sequence=""41""
                            Command=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Commands.RestoreListOnStandardView""
                            LabelText=""{0}""
                            Image32by32=""/_layouts/{1}/images/formatmap32x32.png""
                             Image32by32Top = ""-160""
                           Image32by32Left = ""-224""
                            TemplateAlias=""o1"" />
                        </CommandUIDefinition>
                      </CommandUIDefinitions>
                      <CommandUIHandlers>
                        <CommandUIHandler Command=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Commands.RestoreListOnStandardView"" CommandAction=""javascript:window.location = '../../ArchiveList.aspx?ListId={2}&amp;IsRestore=True';"" />
                      </CommandUIHandlers>
                    </CommandUIExtension>";

            btnCustomRibbon.CommandUIExtension = string.Format(commandUIExtension, title, Thread.CurrentThread.CurrentUICulture.LCID, list.ID);
            btnCustomRibbon.Name = name;
            btnCustomRibbon.Title = title;
            btnCustomRibbon.Location = "CommandUI.Ribbon";
            btnCustomRibbon.Update();
            list.Update();

            SecurityHelper.RollbackAllowUnsafeUpdates(web, allowUnsafeUpdates);
        }

        /// <summary>
        /// Hide restore button for a list
        /// </summary>
        /// <param name="web"></param>
        /// <param name="list"></param>
        public static void HideRestoreButton(SPWeb web, SPList list)
        {
            const string name = "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.RestoreListOnStandardView";
            var btnCustomRibbon = list.UserCustomActions.FirstOrDefault(c => c.Name == name);
            if (btnCustomRibbon != null)
            {
                btnCustomRibbon.Delete();
                list.Update();
            }
        }

        /// <summary>
        /// Hide restore items button for a list
        /// </summary>
        /// <param name="web"></param>
        /// <param name="list"></param>
        public static void HideRestoreItemsButton(SPWeb web, SPList list)
        {
            const string name = "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.RestoreListItemsOnStandardView";
            var btnCustomRibbon = list.UserCustomActions.FirstOrDefault(c => c.Name == name);
            if (btnCustomRibbon != null)
            {
                btnCustomRibbon.Delete();
                list.Update();
            }
        }

        /// <summary>
        /// Add a archive items button for a list
        /// </summary>
        /// <param name="web"></param>
        /// <param name="list">The archive button will show in standard view.</param>
        public static void ShowArchiveItemsButton(SPWeb web, SPList list)
        {
            const string name = "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.ArchiveListItemsOnStandardView";
            var btnCustomRibbon = list.UserCustomActions.FirstOrDefault(c => c.Name == name) ??
                                  list.UserCustomActions.Add();

            var title = LocalizationHelper.GetString("ListDataView_MS006");

            const string commandUIExtension = @"<CommandUIExtension>
                      <CommandUIDefinitions>
                        <CommandUIDefinition
                          Location=""Ribbon.ListItem.Actions.Controls._children"">
                          <Button
                            Id=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.ArchiveListItemsOnStandardView""
                            Sequence=""40""
                            Command=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Commands.ArchiveListItemsOnStandardView""
                            LabelText=""{0}""
                            Image32by32=""/_layouts/{1}/images/formatmap32x32.png""
                             Image32by32Top = ""-160""
                           Image32by32Left = ""-224""
                            TemplateAlias=""o1"" />
                        </CommandUIDefinition>
                      </CommandUIDefinitions>
                      <CommandUIHandlers>
                        <CommandUIHandler Command=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Commands.ArchiveListItemsOnStandardView"" CommandAction=""javascript:var ctx = SP.ClientContext.get_current();var items = SP.ListOperation.Selection.getSelectedItems(ctx);var ids = [];for (k in items){{ids.push(items[k].id);}}window.location = '../../ArchiveList.aspx?ListId={2}&amp;Items=' + ids.join(',');"" EnabledScript=""javascript:function enableArchiveListItems(){{var ctx = SP.ClientContext.get_current(); return SP.ListOperation.Selection.getSelectedItems(ctx).length > 0;}} enableArchiveListItems();"" />
                      </CommandUIHandlers>
                    </CommandUIExtension>";

            btnCustomRibbon.CommandUIExtension = string.Format(commandUIExtension, title, Thread.CurrentThread.CurrentUICulture.LCID, list.ID);
            btnCustomRibbon.Name = name;
            btnCustomRibbon.Title = title;
            btnCustomRibbon.Location = "CommandUI.Ribbon";
            btnCustomRibbon.Update();
            list.Update();
        }

        public static void ShowRestoreItemsButton(SPWeb web, SPList list)
        {
            const string name = "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.RestoreListItemsOnStandardView";
            var btnCustomRibbon = list.UserCustomActions.FirstOrDefault(c => c.Name == name) ??
                                  list.UserCustomActions.Add();

            var title = LocalizationHelper.GetString("ListDataView_MS007");

            const string commandUIExtension = @"<CommandUIExtension>
                      <CommandUIDefinitions>
                        <CommandUIDefinition
                          Location=""Ribbon.ListItem.Actions.Controls._children"">
                          <Button
                            Id=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.RestoreListItemsOnStandardView""
                            Sequence=""40""
                            Command=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Commands.RestoreListItemsOnStandardView""
                            LabelText=""{0}""
                            Image32by32=""/_layouts/{1}/images/formatmap32x32.png""
                             Image32by32Top = ""-160""
                           Image32by32Left = ""-224""
                            TemplateAlias=""o1"" />
                        </CommandUIDefinition>
                      </CommandUIDefinitions>
                      <CommandUIHandlers>
                        <CommandUIHandler Command=""DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Commands.RestoreListItemsOnStandardView"" CommandAction=""javascript:var ctx = SP.ClientContext.get_current();var items = SP.ListOperation.Selection.getSelectedItems(ctx);var ids = [];for (k in items){{ids.push(items[k].id);}}window.location = '../../ArchiveList.aspx?ListId={2}&amp;IsRestore=True&amp;Items=' + ids.join(',');"" EnabledScript=""javascript:function enableRestoreListItems(){{var ctx = SP.ClientContext.get_current(); return SP.ListOperation.Selection.getSelectedItems(ctx).length > 0;}} enableRestoreListItems();"" />
                      </CommandUIHandlers>
                    </CommandUIExtension>";

            btnCustomRibbon.CommandUIExtension = string.Format(commandUIExtension, title, Thread.CurrentThread.CurrentUICulture.LCID, list.ID);
            btnCustomRibbon.Name = name;
            btnCustomRibbon.Title = title;
            btnCustomRibbon.Location = "CommandUI.Ribbon";
            btnCustomRibbon.Update();
            list.Update();
        }
        
        /// <summary>
        /// Hide archive items button for a list
        /// </summary>
        /// <param name="web"></param>
        /// <param name="list"></param>
        public static void HideArchiveItemsButton(SPWeb web, SPList list)
        {
            const string name = "DeutscheBank.SharePoint.LNAR.Framework.Ribbon.Controls.ArchiveListItemsOnStandardView";
            var btnCustomRibbon = list.UserCustomActions.FirstOrDefault(c => c.Name == name);
            if (btnCustomRibbon != null)
            {
                btnCustomRibbon.Delete();
                list.Update();
            }
        }

        /// <summary>
        /// Delete user custom action item button for a list
        /// </summary>
        /// <param name="list"></param>
        /// <param name="actionId"></param>
        public static void DeleteUserCustomAction(SPList list, string actionId)
        {
            var btnCustomRibbon = list.UserCustomActions.FirstOrDefault(c => c.Name == actionId);
            if (btnCustomRibbon != null)
            {
                btnCustomRibbon.Delete();
                list.Update();
            }
        }
    }
}