﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DeutscheBank.SharePoint.LNAR.Framework.WebParts;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public class PrintPreviewHelper
    {
        /// <summary>
        /// Print <see cref="SPListItem"/> collection to html with default template.
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        public static string Printer(IEnumerable<SPListItem> items)
        {
            if (items == null || items.Count() == 0)
            {
                throw new ArgumentNullException("items");
            }

            var htmlTemplate = TemplateHelper.BuildDefaultTemplate(items.First());

            return Printer(items, htmlTemplate);
        }

        /// <summary>
        /// Print <see cref="SPListItem"/> collection to html.
        /// </summary>
        /// <param name="web"></param>
        /// <param name="items"></param>
        /// <param name="templatePath"></param>
        /// <returns></returns>
        public static string Printer(SPWeb web, IEnumerable<SPListItem> items, string templatePath)
        {
            if (items == null || items.Count() == 0)
            {
                throw new ArgumentNullException("items");
            }

            if (string.IsNullOrEmpty(templatePath))
            {
                throw new ArgumentNullException("templatePath");
            }

            // Get template
            var htmlTemplate = TemplateHelper.GetTemplateFromFile(web, templatePath);

            return Printer(items, htmlTemplate);
        }

        /// <summary>
        /// Print <see cref="SPListItem"/> collection to html with custom template.
        /// </summary>
        /// <param name="items"></param>
        /// <param name="htmlTemplate"></param>
        /// <returns></returns>
        public static string Printer(IEnumerable<SPListItem> items, string htmlTemplate)
        {
            // Extract head tag from html template
            var headTemplate = TemplateHelper.ExtractHtmlHead(htmlTemplate);

            // Extract body from html template
            var bodyTemplate = TemplateHelper.ExtractHtmlBody(htmlTemplate);

            // Transform template
            var bodyBuilder = new StringBuilder();

            bodyBuilder.AppendLine("<div style=\"text-align:right;margin-bottom:10px;\" class=\"print-button\">");
            bodyBuilder.AppendLine(
                "<input type='button' id='btnPrinter' value='Print' style=\"padding: 5px;\" onclick='btnPrint_Click()' />");
            bodyBuilder.AppendLine("</div>");

            var index = 1;
            foreach (var item in items)
            {
                bodyBuilder.Append(TemplateHelper.TransformHtml(item, bodyTemplate));
                if (index < items.Count())
                {
                    // This code block to break page when print
                    bodyBuilder.AppendLine("<p class=\"page-break\">&nbsp;</p>");
                }
                index++;
            }

            var htmlBuilder = new StringBuilder();

            htmlBuilder.Append("<html>");

            // Head
            htmlBuilder.Append("<head>");

            var title = TemplateHelper.ExtractHtmlTitle(headTemplate);
            if (string.IsNullOrEmpty(title))
            {
                htmlBuilder.Append("<title>Print Preview</title>");
            }

            htmlBuilder.Append(headTemplate);

            // Print button style and script
            htmlBuilder.AppendLine("<script type='text/javascript'>");
            htmlBuilder.AppendLine("function btnPrint_Click(){");
            htmlBuilder.AppendLine("window.print();");
            htmlBuilder.AppendLine("}");
            htmlBuilder.AppendLine("</script>");

            htmlBuilder.Append("<style type=\"text/css\" media=\"print\">");
            htmlBuilder.Append(".print-button{display:none;}");
            htmlBuilder.Append(".page-break{page-break-before:always;}");
            htmlBuilder.Append("</style>");

            htmlBuilder.Append("</head>");

            // Body
            htmlBuilder.Append("<body>");
            htmlBuilder.Append(bodyBuilder.ToString());
            htmlBuilder.Append("</body>");

            htmlBuilder.Append("</html>");

            return htmlBuilder.ToString();
        }

        public static void CreatePrintPreviewPage(SPWeb web)
        {
            WebPageHelper.CreateDefaultWebPage(web, "PrintPreview.aspx", true);
            WebPartHelper.AddWebPart(web, "PrintPreview.aspx", new PrintPreviewWebPart { Title = @"PrintPreviewWebPart" }, "Main", 0);
        }
    }
}
