﻿using System;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    public static class WebPageHelper
    {
        public static void CreateWebPage(SPWeb web, string fileName, byte[] fileContent)
        {
            web.RootFolder.Files.Add(fileName, fileContent);
        }

        public static void CreateDefaultWebPage(SPWeb web, string fileName, bool overwrite)
        {
            CreateDefaultWebPage(web, fileName, overwrite, "Microsoft.SharePoint.WebPartPages.WebPartPage, Microsoft.SharePoint, Version=14.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c");
        }

        public static void CreateDefaultWebPage(SPWeb web, string fileName, bool overwrite, string inherits)
        {
            var exists = web.RootFolder.Files.Cast<SPFile>().Any(file => file.Name.Equals(fileName, StringComparison.OrdinalIgnoreCase));

            if (exists && !overwrite)
            {
                return;
            }

            if (exists)
            {
                var file = web.RootFolder.Files[fileName];
                file.Delete();
            }
            
            var fileContent = BuildDefaultPageContent(inherits);
            var fileData = Encoding.UTF8.GetBytes(fileContent);
            CreateWebPage(web, fileName, fileData);
        }

        private static string BuildDefaultPageContent(string inherits)
        {
            var sb = new StringBuilder();
            sb.AppendLine(string.Format("<%@ Page language=\"C#\" MasterPageFile=\"~masterurl/default.master\" Inherits=\"{0}\" meta:webpartpageexpansion=\"full\" %>", inherits));
            sb.AppendLine("<%@ Register Tagprefix=\"SharePoint\" Namespace=\"Microsoft.SharePoint.WebControls\" Assembly=\"Microsoft.SharePoint, Version=14.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c\" %>");
            sb.AppendLine("<%@ Register Tagprefix=\"Utilities\" Namespace=\"Microsoft.SharePoint.Utilities\" Assembly=\"Microsoft.SharePoint, Version=14.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c\" %>");
            sb.AppendLine("<%@ Import Namespace=\"Microsoft.SharePoint\" %>");
            sb.AppendLine("<%@ Assembly Name=\"Microsoft.Web.CommandUI, Version=14.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c\" %>");
            sb.AppendLine("<%@ Register Tagprefix=\"WebPartPages\" Namespace=\"Microsoft.SharePoint.WebPartPages\" Assembly=\"Microsoft.SharePoint, Version=14.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c\" %>");

            sb.AppendLine("<asp:Content ID=\"PlaceHolderPageTitle\" ContentPlaceHolderId=\"PlaceHolderPageTitle\" runat=\"server\"></asp:Content>");
            sb.AppendLine("<asp:Content ID=\"PlaceHolderPageTitleInTitleArea\" ContentPlaceHolderId=\"PlaceHolderPageTitleInTitleArea\" runat=\"server\"></asp:Content>");
            sb.AppendLine("<asp:Content ID=\"PlaceHolderPageDescription\" ContentPlaceHolderId=\"PlaceHolderPageDescription\" runat=\"server\"></asp:Content>");
            sb.AppendLine("<asp:Content ID=\"PlaceHolderMain\" ContentPlaceHolderId=\"PlaceHolderMain\" runat=\"server\">");
            sb.AppendLine("<SharePoint:ScriptLink Name=\"SP.UI.Dialog.js\" runat=\"server\" OnDemand=\"true\" Localizable=\"false\" />");
            sb.AppendLine("<SharePoint:ScriptLink Name=\"SP.Ribbon.js\" runat=\"server\" OnDemand=\"true\" Localizable=\"false\" />");
            //Open table
            sb.AppendLine("<table cellpadding=\"4\" cellspacing=\"0\" border=\"0\" width=\"100%\">");
            //Open row
            sb.AppendLine("<tr>");
            //Open column
            sb.AppendLine("<td id=\"invisibleIfEmpty\" name=\"_invisibleIfEmpty\" valign=\"top\" width=\"100%\">");
            //Apply contents
            sb.AppendLine("<WebPartPages:WebPartZone runat=\"server\" Title=\"loc:Main\" ID=\"Main\" FrameType=\"TitleBarOnly\"><ZoneTemplate></ZoneTemplate></WebPartPages:WebPartZone>");
            //Close column
            sb.AppendLine("</td>");
            //Close row
            sb.AppendLine("</tr>");
            //Close table
            sb.AppendLine("</table>");
            sb.AppendLine("</asp:Content>");

            return sb.ToString();
        }

        /// <summary>
        /// Delete a page in root web by file name
        /// </summary>
        /// <param name="web"></param>
        /// <param name="fileName">A file name like Default.aspx</param>
        public static void DeleteWebPage(SPWeb web, string fileName)
        {
            var exists = web.RootFolder.Files.Cast<SPFile>().Any(file => file.Name.Equals(fileName, StringComparison.InvariantCultureIgnoreCase));
            if (exists)
            {
                web.RootFolder.Files.Delete(fileName);
            }
        }
    }
}
