﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DeutscheBank.SharePoint.DSpace.Diagnostics;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using Microsoft.SharePoint;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    internal class ListItemCopier
    {
        protected virtual IEnumerable<SPField> GetFieldsToCopy(SPList list)
        {
            const string fieldGroup = "_Hidden";
            var fields =
                list.Fields.Cast<SPField>().Where(field =>
                                                  !field.Hidden && (!field.ReadOnlyField || field is SPFieldCalculated) &&
                                                  field.Group != fieldGroup && !(field is SPFieldAttachments)).ToList();

            // Add other fields

            //// Created By
            fields.Add(list.Fields.GetFieldByInternalName("Author"));

            // Modified By
            fields.Add(list.Fields.GetFieldByInternalName("Editor"));

            // Created
            fields.Add(list.Fields.GetFieldByInternalName("Created"));

            // Modified
            fields.Add(list.Fields.GetFieldByInternalName("Modified"));

            return fields;
        }

        public virtual void CopyItems(SPWeb web, SPList list, SPList archiveList, SPListItemCollection items)
        {
            var fields = GetFieldsToCopy(list);
            var ids = new List<int>();
            var isThrottling = false;
            bool hasInnerException = false;
            if (list.Folders.Count > 0)
            {
                var archiveListRootFolderUrl = archiveList.RootFolder.Url;
                var currentUrl = archiveListRootFolderUrl;
                foreach (SPListItem item in items)
                {
                    if (item.FileSystemObjectType != SPFileSystemObjectType.Folder)
                    {
                        var split = item.Url.Split(new[] {"/"}, StringSplitOptions.RemoveEmptyEntries);
                        var url = string.Format("{0}/{1}", archiveListRootFolderUrl,
                                                string.Join("/", split, 2, split.Length - 3));
                        if (url.EndsWith("/"))
                        {
                            url = url.Trim('/');
                        }

                        if (!string.Equals(currentUrl, url, StringComparison.InvariantCultureIgnoreCase))
                        {
                            CreateFolderStructure(web, archiveList, url);
                        }

                        isThrottling = CopyListItem(item, web, archiveList, fields, url, isThrottling, ref hasInnerException);
                        ids.Add(item.ID);

                        currentUrl = url;
                    }
                }
            }
            else
            {
                foreach (SPListItem item in items)
                {
                    isThrottling = CopyListItem(item, web, archiveList, fields, null, isThrottling, ref hasInnerException);
                    ids.Add(item.ID);
                }
            }

            if (ids.Count == 0)
            {
                return;
            }

            // Log when is throttling 
            if (isThrottling)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Cannot keep unique permission in all listitems");
            }

            if (hasInnerException)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "An exception has occur during copy process, cause of some fields nolonger exist");
            }

            // Remove source items
            var listId = list.ID.ToString();

            var batch = new StringBuilder();
            batch.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            batch.Append("<ows:Batch OnError=\"Continue\">");

            foreach (var id in ids)
            {
                batch.Append("<Method>");
                batch.AppendFormat("<SetList Scope=\"Request\">{0}</SetList>", listId);
                batch.Append("<SetVar Name=\"Cmd\">Delete</SetVar>");
                batch.AppendFormat("<SetVar Name=\"ID\">{0}</SetVar>", id);
                batch.Append("</Method>");
            }

            batch.Append("</ows:Batch>");

            web.ProcessBatchData(batch.ToString());
        }

        private static void CreateFolderStructure(SPWeb web, SPList list, string url)
        {
            var folder = web.GetFolder(url);
            if (folder != null && folder.Exists)
            {
                return;
            }

            var split = url.Split('/');
            for (var i = 2; i < split.Length; i++)
            {
                var subFolder = web.GetFolder(string.Join("/", split, 0, i + 1));
                if (subFolder != null && subFolder.Exists)
                {
                    continue;
                }

                var item = list.AddItem(string.Join("/", split, 0, i), SPFileSystemObjectType.Folder);
                item[SPBuiltInFieldId.Title] = split[i];
                item[SPBuiltInFieldId.FileLeafRef] = split[i];
                item.SystemUpdate();
            }
        }

        private static bool CopyListItem(SPListItem item, SPWeb web, SPList archiveList, IEnumerable<SPField> fields,
                                         string folderUrl, bool isThrottling, ref bool hasInnerException)
        {
            var newItem = string.IsNullOrEmpty(folderUrl)
                              ? archiveList.AddItem()
                              : archiveList.AddItem(folderUrl, SPFileSystemObjectType.File);
            
            foreach (var field in fields)
            {
                try
                {
                    
                    newItem[field.InternalName] = item[field.InternalName];
                }
                catch (ArgumentException)
                {
                    hasInnerException = false;
                }
            }

            // Copy attachments
            foreach (string attachment in item.Attachments)
            {
                var file = web.GetFile(item.Attachments.UrlPrefix + attachment);
                newItem.Attachments.Add(attachment, file.OpenBinary());
            }
            newItem.SystemUpdate();


            // Item permission
            if (!isThrottling)
            {
                try
                {
                    if (item.HasUniqueRoleAssignments)
                    {
                        newItem.BreakRoleInheritance(false);

                        // Copy role assignments
                        foreach (SPRoleAssignment roleAssignment in item.RoleAssignments)
                        {
                            newItem.RoleAssignments.Add(roleAssignment);
                        }

                        // Save new item
                        newItem.SystemUpdate();
                    }
                }
                catch (SPException)
                {
                    isThrottling = true;
                }
                catch (Exception exception)
                {
                    Trace.LogException(FrameworkConstants.FrameworkTraceId, exception);
                }
            }

            return isThrottling;
        }
    }
}