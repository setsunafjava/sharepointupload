﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DeutscheBank.SharePoint.DSpace.Diagnostics;
using DeutscheBank.SharePoint.LNAR.Framework.Common;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DeutscheBank.SharePoint.LNAR.Framework.Helpers
{
    internal class DiscussionBoardCopier : ListItemCopier
    {
        protected override IEnumerable<SPField> GetFieldsToCopy(SPList list)
        {
            const string fieldGroup = "_Hidden";
            var fields =
                list.Fields.Cast<SPField>().Where(field =>
                                                  !field.Hidden && (!field.ReadOnlyField || field is SPFieldCalculated) &&
                                                  field.Group != fieldGroup &&
                                                  !(field is SPFieldAttachments)).ToList();

           

            // Created By
            fields.Add(list.Fields.GetFieldByInternalName("Author"));

            // Created
            fields.Add(list.Fields.GetFieldByInternalName("Created"));

            // Modified
            fields.Add(list.Fields.GetFieldByInternalName("Modified"));

            return fields;
        }

        public override void CopyItems(SPWeb web, SPList list, SPList archiveList, SPListItemCollection items)
        {
            var fields = GetFieldsToCopy(list);
            var ids = new List<int>();
            var isThrottling = false;
        
          
            bool hasInnerException = false;
            foreach (SPListItem item in items)
            {
                isThrottling = CopyDiscussionItem(web, list, archiveList, item, fields, isThrottling, ref hasInnerException);
                ids.Add(item.ID);
            }

            // Log
            if (isThrottling)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "Cannot keep unique permission in all listitems");
                
            }

            if (hasInnerException)
            {
                Trace.LogMessage(FrameworkConstants.FrameworkTraceId, TraceSeverity.Medium, "An exception has occur during copy process, cause of some fields nolonger exist");
            }

           
            var listId = list.ID.ToString();

            // Delete TopicItem
            var batch = new StringBuilder();
            batch.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            batch.Append("<ows:Batch OnError=\"Continue\">");

            foreach (var id in ids)
            {
                batch.Append("<Method>");
                batch.AppendFormat("<SetList Scope=\"Request\">{0}</SetList>", listId);
                batch.Append("<SetVar Name=\"Cmd\">Delete</SetVar>");
                batch.AppendFormat("<SetVar Name=\"ID\">{0}</SetVar>", id);
                batch.Append("</Method>");
            }

            batch.Append("</ows:Batch>");

            web.ProcessBatchData(batch.ToString());
        }

        private static bool CopyDiscussionItem(SPWeb web, SPList list, SPList archiveList, SPListItem item,
                                               IEnumerable<SPField> fields, bool isThrottling, ref bool hasInnerException)
        {
            var newItem = SPUtility.CreateNewDiscussion(archiveList, item.Title);
            var replyIds = new List<int>();
            foreach (var field in fields)
            {
                try
                {
                    newItem[field.InternalName] = item[field.InternalName];
                }
                catch (ArgumentException)
                {
                    hasInnerException = true;
                }
            }

            // Copy attachments
            foreach (string attachment in item.Attachments)
            {
                var file = web.GetFile(item.Attachments.UrlPrefix + attachment);
                newItem.Attachments.Add(attachment, file.OpenBinary());
            }

            // Save new discussion
            newItem[SPBuiltInFieldId.Editor] = item[SPBuiltInFieldId.Editor];
            newItem.SystemUpdate();

            var query = new SPQuery {Folder = item.Folder,QueryThrottleMode = SPQueryThrottleOption.Override};
            var items = list.GetItems(query);
            foreach (SPListItem reply in items)
            {
                isThrottling = CopyDiscussionReplyItem(web, newItem, reply, fields, ref hasInnerException);
                replyIds.Add(reply.ID);
            }

            // Update system info
            newItem[SPBuiltInFieldId.ThreadIndex] = item[SPBuiltInFieldId.ThreadIndex];
            newItem[SPBuiltInFieldId.DiscussionLastUpdated] = item[SPBuiltInFieldId.DiscussionLastUpdated];
            newItem.SystemUpdate();

            if (!isThrottling)
            {
                try
                {
                    if (item.HasUniqueRoleAssignments)
                    {
                        newItem.BreakRoleInheritance(false);

                        // copy unique assignments
                        foreach (SPRoleAssignment roleAssignment in item.RoleAssignments)
                        {
                            newItem.RoleAssignments.Add(roleAssignment);
                        }

                        // Save new item
                        newItem.SystemUpdate();
                    }
                }
                catch (SPException)
                {
                    isThrottling = true;
                }
                catch (Exception exception)
                {
                    Trace.LogException(FrameworkConstants.FrameworkTraceId, exception);
                }
            }

            // Delete ReplyItems first.

            var batchRp = new StringBuilder();
            batchRp.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            batchRp.Append("<ows:Batch OnError=\"Continue\">");
            var listId = list.ID.ToString();
            foreach (var id in replyIds)
            {
                batchRp.Append("<Method>");
                batchRp.AppendFormat("<SetList Scope=\"Request\">{0}</SetList>", listId);
                batchRp.Append("<SetVar Name=\"Cmd\">Delete</SetVar>");
                batchRp.AppendFormat("<SetVar Name=\"ID\">{0}</SetVar>", id);
                batchRp.Append("</Method>");
            }

            batchRp.Append("</ows:Batch>");

            web.ProcessBatchData(batchRp.ToString());

            return isThrottling;
        }

        private static bool CopyDiscussionReplyItem(SPWeb web, SPListItem parentItem, SPListItem item,
                                                    IEnumerable<SPField> fields, ref bool hasInnerException)
        {
            var replyItem = SPUtility.CreateNewDiscussionReply(parentItem);
            var isThrottling = false;
            foreach (var field in fields)
            {
                try
                {
                    replyItem[field.InternalName] = item[field.InternalName];
                }
                catch (ArgumentException)
                {
                    hasInnerException = true;
                }
            }

            // Update ThreadIndex
            replyItem[SPBuiltInFieldId.ThreadIndex] = item[SPBuiltInFieldId.ThreadIndex];

            // Update editor
            replyItem[SPBuiltInFieldId.Editor] = item[SPBuiltInFieldId.Editor];


            // Copy attachments
            foreach (string attachment in item.Attachments)
            {
                var file = web.GetFile(item.Attachments.UrlPrefix + attachment);
                replyItem.Attachments.Add(attachment, file.OpenBinary());
            }

            // Save new item
            replyItem.SystemUpdate();

            try
            {
                if (item.HasUniqueRoleAssignments)
                {
                    //// copy unique assignments
                    var roleAssignmentCol = item.RoleAssignments;
                    replyItem.BreakRoleInheritance(false);
                    foreach (SPRoleAssignment spRoleAssignment in roleAssignmentCol)
                    {
                        replyItem.RoleAssignments.Add(spRoleAssignment);
                    }


                    // Update ThreadIndex
                    replyItem[SPBuiltInFieldId.ThreadIndex] = item[SPBuiltInFieldId.ThreadIndex];

                    // Update editor
                    replyItem[SPBuiltInFieldId.Editor] = item[SPBuiltInFieldId.Editor];
                    replyItem.SystemUpdate();
                }
            }

            catch (SPException)
            {
                isThrottling = true;
            }
            catch (Exception exception)
            {
                Trace.LogException(FrameworkConstants.FrameworkTraceId, exception);
            }

            return isThrottling;
        }

       
    }
}